#!/usr/bin/env python3
"""
Pipeline for IMU_oneseg_ws — start everything together:

  • udp_optitrack_publisher
  • MyActuator random_data_collection  (/motor)
  • data_collection                    (CSV)

Motor mode / COM / gains / IMU_WARMUP_S / TAU / LOOP live in
  MyActuator_motor_imu/random_data_collection.py
Motor + CSV run at 400 Hz; OptiTrack stays ~100 Hz and is interpolated
into every CSV row (see data_collection.py).
Edit MAX_ROWS_DEFAULT below for how many CSV rows to save (Mode 1).

CSV files are written under ``out_dir`` (default = IMU_oneseg_ws root)::

  /root/DataCollection/IMU_oneseg_ws/data_YYYYMMDD_HHMMSS.csv
  /root/DataCollection/IMU_oneseg_ws/data_collection_log_YYYYMMDD_HHMMSS.txt

Stop condition:
  data_collection reaches max_rows → exits → launch Shutdown →
  motor soft-releases (return home + ramp t_ff → 0).
  Motor Mode-1 keeps regenerating κ ramp/hold until that Shutdown;
  Modes 2 / 3 finish one pass then soft-release themselves.
"""

import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, OpaqueFunction, Shutdown
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _find_ws_root(start: str) -> str:
    here = os.path.abspath(os.path.dirname(start))
    marker = 'optitrack_roles.py'
    for env in ('IMU_ONESEG_WS',):
        raw = os.environ.get(env, '').strip()
        if raw and os.path.isfile(os.path.join(raw, marker)):
            return os.path.abspath(raw)
    for _ in range(12):
        if os.path.isfile(os.path.join(here, marker)):
            return here
        parent = os.path.dirname(here)
        if parent == here:
            break
        here = parent
    raise RuntimeError(
        'Could not find IMU_oneseg_ws root (optitrack_roles.py). '
        'Set IMU_ONESEG_WS=/root/DataCollection/IMU_oneseg_ws'
    )


WS_ROOT = _find_ws_root(__file__)

# ── Edit this for Mode-1 CSV length (also passed to the motor node).
# Warmup is IMU_WARMUP_S in random_data_collection.py — do not re-define max
# rows there. When this many rows are written, data_collection exits → launch
# Shutdown → motor soft-releases and the pipeline stops.
MAX_ROWS_DEFAULT = 2_000_000

# Fixed OptiTrack body count for CSV columns (base + tip). Use 0 only when
# Motive is live and you want auto-detect — with 0 the CSV waits for the first
# OptiTrack frame before any rows are written.
NUM_RIGID_BODIES_DEFAULT = 5  # RB1 base … RB5 tip


def _p(context, name: str, default: str) -> str:
    try:
        v = LaunchConfiguration(name).perform(context)
        return v.strip() if v.strip() else default
    except Exception:
        return default


def _nodes(context, *args, **kwargs):
    out_dir = os.path.abspath(_p(context, 'out_dir', WS_ROOT))
    max_rows = int(float(_p(context, 'max_rows', str(MAX_ROWS_DEFAULT))))
    rate_hz = float(_p(context, 'rate_hz', '400.0'))
    require_both = _p(context, 'require_both', 'false').strip().lower() in (
        '1', 'true', 'yes', 'on',
    )
    num_rigid_bodies = int(
        float(_p(context, 'num_rigid_bodies', str(NUM_RIGID_BODIES_DEFAULT)))
    )
    if num_rigid_bodies < 0:
        num_rigid_bodies = 0
    progress_log_period_sec = float(_p(context, 'progress_log_period_sec', '1.0'))
    exit_on_max_rows = _p(context, 'exit_on_max_rows', 'true').strip().lower() in (
        '1', 'true', 'yes', 'on',
    )
    optitrack_interp = _p(context, 'optitrack_interp', 'true').strip().lower() in (
        '1', 'true', 'yes', 'on',
    )

    os.makedirs(out_dir, exist_ok=True)

    motor_node = Node(
        package='MyActuator_motor_imu',
        executable='random_data_collection',
        name='myactuator_random_datacollection',
        output='screen',
        parameters=[{
            'topic_name': '/motor',
            'data_collection_max_rows': max_rows,
            # Mode 1: keep regenerating until CSV max_rows / Shutdown.
            # Modes 2/3 ignore this and run one pass (see random_data_collection).
            'loop': True,
        }],
    )

    data_collector_node = Node(
        package='data_collection',
        executable='data_collection',
        name='data_collection',
        output='screen',
        on_exit=[Shutdown(reason='data_collection completed (max_rows reached)')],
        parameters=[{
            'rate_hz': rate_hz,
            'out_dir': out_dir,
            'max_rows': max_rows,
            'require_both': require_both,
            'num_rigid_bodies': num_rigid_bodies,
            'progress_log_period_sec': progress_log_period_sec,
            'exit_on_max_rows': exit_on_max_rows,
            'optitrack_interp': optitrack_interp,
        }],
    )

    optitrack_node = Node(
        package='optitrack_streaming',
        executable='udp_optitrack_publisher',
        name='udp_optitrack_publisher',
        output='screen',
    )

    auto_note = (
        'auto (CSV waits for first OptiTrack frame)'
        if num_rigid_bodies == 0
        else f'fixed={num_rigid_bodies}'
    )
    return [
        LogInfo(
            msg=(
                f'[pipeline_imu_one] CSV out_dir={out_dir} | '
                f'OptiTrack + motor + CSV @ {rate_hz:g} Hz; '
                f'max_rows={max_rows:,}, num_rigid_bodies={auto_note}, '
                f'require_both={require_both}, optitrack_interp={optitrack_interp} '
                f'(with fixed bodies, motors write even if OptiTrack is quiet)'
            )
        ),
        optitrack_node,
        motor_node,
        data_collector_node,
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'out_dir',
            default_value=WS_ROOT,
            description=(
                'Directory for data_YYYYMMDD_HHMMSS.csv and '
                'data_collection_log_*.txt (default: IMU_oneseg_ws root).'
            ),
        ),
        DeclareLaunchArgument(
            'max_rows',
            default_value=str(MAX_ROWS_DEFAULT),
            description='CSV rows to save (edit MAX_ROWS_DEFAULT in this file).',
        ),
        DeclareLaunchArgument(
            'rate_hz',
            default_value='400.0',
            description='CSV write rate (match motor PUBLISH_HZ=400). '
            'OptiTrack stays ~100 Hz; poses are interpolated to fill gaps.',
        ),
        DeclareLaunchArgument(
            'require_both',
            default_value='false',
            description='If true, wait for motor+OptiTrack before CSV. '
            'If false (default), start on /motor; missing OptiTrack → warn + NaN poses.',
        ),
        DeclareLaunchArgument(
            'num_rigid_bodies',
            default_value=str(NUM_RIGID_BODIES_DEFAULT),
            description=(
                'Fixed OptiTrack body count for CSV columns (default 2 = base+tip). '
                '0 = auto-detect from first OptiTrack message (CSV stays empty until then).'
            ),
        ),
        DeclareLaunchArgument(
            'optitrack_interp',
            default_value='true',
            description='Upsample OptiTrack (~100 Hz) to rate_hz with xyz lerp + quat geodesic.',
        ),
        DeclareLaunchArgument('progress_log_period_sec', default_value='1.0'),
        DeclareLaunchArgument('exit_on_max_rows', default_value='true'),
        OpaqueFunction(function=_nodes),
    ])
