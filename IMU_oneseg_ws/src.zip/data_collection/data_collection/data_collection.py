#!/usr/bin/env python3
# Licensed under the Apache License, Version 2.0
#
# CSV row (MyActuator 3-motor + 3 IMUs @ 400 Hz; OptiTrack ~100 Hz upsampled):
#   time_stamp, wall_time_s, kappa1, kappa2;
#   target_enc01..03, real_enc01..03, trq01..03 (rad / Nm);
#   quat1_w..z (tip), quat2_w..z (mid), quat3_w..z (base);
#   id1..idN, x1..z1, qx1..qw1, …; opti_timestamp.
#
# /motor (Float64MultiArray, 24 floats):
#   target×3, real×3, trq×3, kappa1, kappa2,
#   quat×12 (IMU1 tip, IMU2 mid, IMU3 base — each wxyz),
#   seq_time_s
#
# Motor/IMU @ rate_hz (default 400). OptiTrack ~100 Hz upsampled:
#   xyz  → linear lerp; quat → SO(3) geodesic (nlerp fast-path).
# Keep writing until rows == max_rows; if motor seq_time stalls, time_stamp
# falls back to wall_time so the CSV never freezes early.

import csv
import math
import os
import sys
from collections import deque
from datetime import datetime

import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray, Float64MultiArray

NUM_MOTORS = 3
N_IMU = 3
N_QUAT = N_IMU * 4  # 12
IDX_TARGET = 0
IDX_REAL = NUM_MOTORS
IDX_TRQ = 2 * NUM_MOTORS
IDX_KAPPA1 = 3 * NUM_MOTORS
IDX_KAPPA2 = IDX_KAPPA1 + 1
IDX_QUAT = IDX_KAPPA2 + 1
IDX_SEQ_TIME = IDX_QUAT + N_QUAT
EXPECTED_MOTOR_LEN = IDX_SEQ_TIME + 1  # 24

DEFAULT_NUM_RIGID_BODIES = 5  # RB1 base … RB5 tip; launch may override (0 = auto)
DEFAULT_MAX_ROWS = 2_000_000
# When auto (0) and require_both=False: open CSV on first /motor with this many
# OptiTrack columns (NaN until Motive streams) so motor rows are not dropped.
AUTO_FALLBACK_RIGID_BODIES = 5


def _find_ws_root() -> str:
    """Locate IMU_oneseg_ws root (where optitrack_roles.py lives)."""
    marker = 'optitrack_roles.py'
    for env in ('IMU_ONESEG_WS',):
        raw = os.environ.get(env, '').strip()
        if raw and os.path.isfile(os.path.join(raw, marker)):
            return os.path.abspath(raw)
    here = os.path.abspath(os.path.dirname(__file__))
    for _ in range(12):
        if os.path.isfile(os.path.join(here, marker)):
            return here
        parent = os.path.dirname(here)
        if parent == here:
            break
        here = parent
    raise ModuleNotFoundError(
        f'Could not find {marker} (workspace root). '
        'Set IMU_ONESEG_WS=/root/DataCollection/IMU_oneseg_ws'
    )


_WS = _find_ws_root()
if _WS not in sys.path:
    sys.path.insert(0, _WS)
from optitrack_roles import base_tip_layout_label, lock_roles_by_y_sort, role_count_for_bodies  # noqa: E402


class DataCollector(Node):
    def __init__(self):
        super().__init__('data_collection')

        self.declare_parameter('rate_hz', 400.0)
        self.declare_parameter('out_dir', '.')
        self.declare_parameter('flush_every', 400)
        self.declare_parameter('use_motor_seq_time', True)
        self.declare_parameter('require_both', False)
        self.declare_parameter('warn_period_sec', 0.5)
        self.declare_parameter('max_rows', DEFAULT_MAX_ROWS)
        self.declare_parameter('motor_topic', '/motor')
        self.declare_parameter('optitrack_topic', '/optitrack/rigid_body_array')
        self.declare_parameter('num_rigid_bodies', DEFAULT_NUM_RIGID_BODIES)
        self.declare_parameter('progress_log_period_sec', 1.0)
        self.declare_parameter('exit_on_max_rows', True)
        self.declare_parameter('optitrack_interp', True)
        self.declare_parameter('optitrack_history_sec', 2.0)

        self.rate_hz = float(self.get_parameter('rate_hz').value)
        out_dir = self.get_parameter('out_dir').get_parameter_value().string_value or '.'
        self.flush_every = max(1, int(self.get_parameter('flush_every').value))
        self._use_motor_seq_time = self._read_bool_param('use_motor_seq_time', True)
        self.require_both = self._read_bool_param('require_both', False)
        self.warn_period_sec = float(self.get_parameter('warn_period_sec').value)
        self.max_rows = max(1, int(self.get_parameter('max_rows').value))
        self.progress_log_period_sec = max(
            0.05, float(self.get_parameter('progress_log_period_sec').value)
        )
        self._exit_on_max_rows = self._read_bool_param('exit_on_max_rows', True)
        self._optitrack_interp = self._read_bool_param('optitrack_interp', True)
        self._opti_hist_sec = max(
            0.2, float(self.get_parameter('optitrack_history_sec').value)
        )
        self.motor_topic = (
            self.get_parameter('motor_topic').get_parameter_value().string_value or '/motor'
        )
        self.optitrack_topic = (
            self.get_parameter('optitrack_topic').get_parameter_value().string_value
            or '/optitrack/rigid_body_array'
        )
        _nrb = int(self.get_parameter('num_rigid_bodies').value)
        self._optitrack_auto = _nrb <= 0
        if self._optitrack_auto:
            self.num_rigid_bodies = 0
            self._expected_opt_len = 0
        else:
            self.num_rigid_bodies = max(1, _nrb)
            self._expected_opt_len = 8 * self.num_rigid_bodies + 1

        self._opt_layout_locked = not self._optitrack_auto

        os.makedirs(out_dir, exist_ok=True)
        out_dir = os.path.abspath(out_dir)
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.filename = os.path.join(out_dir, f'data_{ts}.csv')
        self.log_filename = os.path.join(out_dir, f'data_collection_log_{ts}.txt')

        with open(self.log_filename, 'w') as log_file:
            log_file.write('Data Collection Debug Log (MyActuator + 3 IMU + OptiTrack)\n')
            log_file.write(f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            log_file.write(f'CSV file: {self.filename}\n')
            log_file.write(f'out_dir: {out_dir}\n')
            log_file.write('=' * 60 + '\n\n')

        self._fh = None
        self._writer = None
        if not self._optitrack_auto:
            self._open_csv_with_header()

        self.latest_motor = None
        self.latest_optitrack = None
        self._latest_opti_recv_time_ns = None
        self._opti_hist: deque = deque()
        self.rows = 0
        self._saw_motor = False
        self._saw_opti = False
        self._last_row_time_ns = None
        self._last_warn_ns = 0
        self._collection_stopped = False
        self._data_collection_started = False
        self._collection_start_time_ns = None
        self._motor_seq_t0 = None
        self._last_seq_aligned = None
        self._last_progress_log_ns = None
        self._stage = 'waiting_streams'
        self._role_track_ids = None
        self._opti_interp_rows = 0
        self._opti_measured_rows = 0

        def log_debug(message):
            t = datetime.now().strftime('%H:%M:%S.%f')[:-3]
            with open(self.log_filename, 'a') as log_file:
                log_file.write(f'[{t}] {message}\n')
            self.get_logger().info(message)

        self._log_debug = log_debug

        sub_qos = 100
        self.create_subscription(
            Float64MultiArray, self.motor_topic, self._on_motor, sub_qos
        )
        self.create_subscription(
            Float32MultiArray, self.optitrack_topic, self._on_opt, sub_qos
        )

        self._log_debug(
            f'Subscribed {self.motor_topic} (Float64MultiArray, len={EXPECTED_MOTOR_LEN})'
        )
        self._log_debug(f'Subscribed {self.optitrack_topic} (Float32MultiArray)')
        self._log_debug(f'CSV path: {self.filename}')

        self.create_timer(1.0 / self.rate_hz, self._tick)

        opt_desc = (
            'auto (first OptiTrack msg; motor-only fallback opens CSV early)'
            if self._optitrack_auto
            else f'{self.num_rigid_bodies} (fixed), opt_floats={self._expected_opt_len}'
        )
        self.get_logger().info(
            f'Logging CSV @ {self.rate_hz:.1f} Hz → {self.filename} '
            f'(flush_every={self.flush_every}, require_both={self.require_both}, '
            f'optitrack_bodies={opt_desc}, '
            f'optitrack_interp={self._optitrack_interp}, '
            f'target_rows={self.max_rows:,})'
        )
        if self._optitrack_interp:
            self.get_logger().info(
                'OptiTrack upsample ON — xyz linear lerp; quat SO(3) geodesic; '
                'Y-sort roles (XZ plane, Y=backbone).'
            )
        if not self.require_both:
            self.get_logger().info(
                'require_both=False — collection starts on /motor alone; '
                'missing OptiTrack → warn + NaN pose columns.'
            )

    def _build_csv_header(self):
        header = [
            'time_stamp',
            'wall_time_s',
            'kappa1',
            'kappa2',
            'target_enc01',
            'target_enc02',
            'target_enc03',
            'real_enc01',
            'real_enc02',
            'real_enc03',
            'trq01',
            'trq02',
            'trq03',
            # IMU1 tip, IMU2 mid, IMU3 base
            'quat1_w',
            'quat1_x',
            'quat1_y',
            'quat1_z',
            'quat2_w',
            'quat2_x',
            'quat2_y',
            'quat2_z',
            'quat3_w',
            'quat3_x',
            'quat3_y',
            'quat3_z',
        ]
        for i in range(1, self.num_rigid_bodies + 1):
            header += [
                f'id{i}',
                f'x{i}',
                f'y{i}',
                f'z{i}',
                f'qx{i}',
                f'qy{i}',
                f'qz{i}',
                f'qw{i}',
            ]
        header += ['opti_timestamp']
        return header

    def _open_csv_with_header(self):
        if self._fh is not None:
            return
        if self.num_rigid_bodies < 1:
            self.get_logger().error('Cannot open CSV: num_rigid_bodies not set')
            return
        header = self._build_csv_header()
        try:
            self._fh = open(self.filename, 'w', newline='')
            self._writer = csv.writer(self._fh)
            self._writer.writerow(header)
            self._fh.flush()
            os.fsync(self._fh.fileno())
            self.get_logger().info(
                f'CSV header written: {self.filename} '
                f'({self.num_rigid_bodies} rigid bodies)'
            )
        except OSError as e:
            self.get_logger().error(f'Failed to initialize CSV: {e}')
            self._fh = None
            self._writer = None

    @staticmethod
    def _infer_rigid_bodies_from_opt_len(n: int):
        if n < 9:
            return None
        if (n - 1) % 8 != 0:
            return None
        nb = (n - 1) // 8
        return (nb, n)

    def _read_bool_param(self, name: str, default: bool) -> bool:
        v = self.get_parameter(name).value
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            s = v.strip().lower()
            if s in ('0', 'false', 'no', 'off', ''):
                return False
            if s in ('1', 'true', 'yes', 'on'):
                return True
            return default
        return bool(v) if v is not None else default

    def _on_motor(self, msg: Float64MultiArray):
        if not self._saw_motor:
            self._saw_motor = True
            self._log_debug(f'first {self.motor_topic} sample: len={len(msg.data)}')
            # Auto OptiTrack + motor-only: open CSV immediately so rows are not
            # dropped while waiting for Motive (matches require_both=False intent).
            if (
                self._optitrack_auto
                and not self.require_both
                and self._fh is None
                and not self._opt_layout_locked
            ):
                self.num_rigid_bodies = max(1, int(AUTO_FALLBACK_RIGID_BODIES))
                self._expected_opt_len = 8 * self.num_rigid_bodies + 1
                self._opt_layout_locked = True
                self._open_csv_with_header()
                if self._fh is not None:
                    self.get_logger().warn(
                        f'OptiTrack auto: opened CSV with {self.num_rigid_bodies} '
                        f'pose columns before first OptiTrack frame '
                        f'(NaN until Motive streams). Path: {self.filename}'
                    )
                else:
                    self._opt_layout_locked = False
                    self.num_rigid_bodies = 0
                    self._expected_opt_len = 0
            self._check_data_collection_ready()
        self.latest_motor = list(msg.data)

    def _on_opt(self, msg: Float32MultiArray):
        n = len(msg.data)

        if self._optitrack_auto and not self._opt_layout_locked:
            inferred = self._infer_rigid_bodies_from_opt_len(n)
            if inferred is None:
                self.get_logger().warn(
                    f'OptiTrack msg len={n} is not 8*N+1; skipping until valid frame'
                )
                return
            self.num_rigid_bodies, self._expected_opt_len = inferred
            self._opt_layout_locked = True
            self._open_csv_with_header()
            if self._fh is None:
                self._opt_layout_locked = False
                self.num_rigid_bodies = 0
                self._expected_opt_len = 0
                return

        if not self._saw_opti:
            if self._fh is None:
                return
            self._saw_opti = True
            self._try_lock_optitrack_roles(list(msg.data))
            role_note = (
                f'roles y-sorted (XZ base plane, Y=backbone)→'
                f'{base_tip_layout_label(len(self._role_track_ids))} '
                f'tracks={self._role_track_ids}'
                if self._role_track_ids
                else 'roles not locked yet'
            )
            self._log_debug(
                f'first {self.optitrack_topic} sample: len={n}, '
                f'{self.num_rigid_bodies} rigid bodies, {role_note}'
            )
            self._check_data_collection_ready()

        self.latest_optitrack = list(msg.data)
        self._latest_opti_recv_time_ns = self.get_clock().now().nanoseconds
        self._push_opti_hist(
            self._latest_opti_recv_time_ns * 1e-9, list(msg.data)
        )

    def _check_data_collection_ready(self):
        if self._data_collection_started:
            return
        if self._fh is None or self._writer is None:
            return
        if self.require_both:
            if not (self._saw_motor and self._saw_opti):
                return
            note = 'motor + OptiTrack'
        else:
            if not self._saw_motor:
                return
            note = (
                'motor + OptiTrack'
                if self._saw_opti
                else 'motor only (OptiTrack missing → NaN pose cols)'
            )
        self._data_collection_started = True
        self._collection_start_time_ns = self.get_clock().now().nanoseconds
        self._stage = 'collecting'
        self._log_debug(f'Data collection STARTED ({note}). stage=collecting')
        if not self._saw_opti:
            self.get_logger().warn(
                f'OptiTrack not active yet ({self.optitrack_topic}) — '
                f'logging motor/κ with NaN id1..id{self.num_rigid_bodies} columns. '
                f'CSV: {self.filename}'
            )

    @staticmethod
    def _cell(v, fmt='{:.8f}'):
        try:
            x = float(v)
        except (TypeError, ValueError):
            return 'nan'
        return fmt.format(x) if math.isfinite(x) else 'nan'

    def _motor_row(self, mot):
        m = list(mot or [])
        if len(m) < EXPECTED_MOTOR_LEN:
            m = m + [float('nan')] * (EXPECTED_MOTOR_LEN - len(m))
        else:
            m = m[:EXPECTED_MOTOR_LEN]

        out = []
        for i in range(NUM_MOTORS):
            out.append(self._cell(m[IDX_TARGET + i]))
        for i in range(NUM_MOTORS):
            out.append(self._cell(m[IDX_REAL + i]))
        for i in range(NUM_MOTORS):
            out.append(self._cell(m[IDX_TRQ + i], '{:.4f}'))
        for i in range(N_QUAT):
            out.append(self._cell(m[IDX_QUAT + i], '{:.6f}'))
        return out

    @staticmethod
    def _kappa_cells(mot) -> tuple[str, str]:
        m = list(mot or [])
        if len(m) > IDX_KAPPA2:
            k1, k2 = float(m[IDX_KAPPA1]), float(m[IDX_KAPPA2])
            if math.isfinite(k1) and math.isfinite(k2):
                return f'{k1:.4f}', f'{k2:.4f}'
        return 'nan', 'nan'

    def _time_stamps(self, mot, wall_time_s: float) -> tuple[str, str]:
        """Prefer motor seq_time; if it stalls/regresses, use wall_time so CSV keeps advancing."""
        seq_time = float('nan')
        if mot is not None and len(mot) > IDX_SEQ_TIME:
            try:
                seq_time = float(mot[IDX_SEQ_TIME])
            except (TypeError, ValueError):
                pass

        if self._use_motor_seq_time and mot is not None and math.isfinite(seq_time):
            if self._motor_seq_t0 is None:
                self._motor_seq_t0 = seq_time
            aligned = seq_time - self._motor_seq_t0
            # Stall / freeze (twoseg bug: traj ended but rows not at max yet).
            if (
                self._last_seq_aligned is not None
                and aligned <= self._last_seq_aligned + 1e-9
            ):
                return f'{wall_time_s:.3f}', f'{wall_time_s:.3f}'
            self._last_seq_aligned = aligned
            return f'{aligned:.3f}', f'{wall_time_s:.3f}'

        nominal = self.rows / max(self.rate_hz, 1e-9)
        return f'{nominal:.3f}', f'{wall_time_s:.3f}'

    @staticmethod
    def _flat_to_bodies(flat: list, n_bodies: int) -> np.ndarray | None:
        need = 8 * n_bodies
        if len(flat) < need:
            return None
        rows = []
        for i in range(n_bodies):
            chunk = flat[i * 8 : (i + 1) * 8]
            if len(chunk) < 8:
                return None
            rows.append([float(v) for v in chunk[:8]])
        return np.asarray(rows, dtype=np.float64)

    def _try_lock_optitrack_roles(self, flat: list) -> None:
        if self._role_track_ids is not None or self.num_rigid_bodies < 2:
            return
        bodies = self._flat_to_bodies(flat, self.num_rigid_bodies)
        if bodies is None:
            return
        n_roles = role_count_for_bodies(self.num_rigid_bodies)
        try:
            self._role_track_ids = lock_roles_by_y_sort(bodies, n_roles=n_roles)
        except ValueError:
            return

    def _bodies_in_role_order(self, body_flat: list) -> list:
        n = self.num_rigid_bodies
        slots = [body_flat[i * 8 : (i + 1) * 8] for i in range(n)]
        if self._role_track_ids is None:
            return body_flat[: 8 * n]
        by_tid: dict[int, list] = {}
        for chunk in slots:
            if len(chunk) < 8:
                continue
            try:
                tid = int(round(float(chunk[0])))
            except (TypeError, ValueError):
                continue
            by_tid[tid] = list(chunk[:8])
        ordered: list = []
        for tid in self._role_track_ids:
            c = by_tid.get(tid)
            ordered.extend(c if c is not None else [float('nan')] * 8)
        for i in range(len(self._role_track_ids), n):
            chunk = slots[i]
            ordered.extend(
                list(chunk[:8]) if len(chunk) >= 8 else [float('nan')] * 8
            )
        return ordered[: 8 * n]

    def _push_opti_hist(self, t_s: float, flat: list) -> None:
        """Keep a short OptiTrack history for upsample / fit."""
        self._opti_hist.append((float(t_s), list(flat)))
        cutoff = float(t_s) - self._opti_hist_sec
        while self._opti_hist and self._opti_hist[0][0] < cutoff:
            self._opti_hist.popleft()

    @staticmethod
    def _quat_mul_xyzw(a, b) -> tuple[float, float, float, float]:
        """Hamilton product; OptiTrack order (qx, qy, qz, qw)."""
        ax, ay, az, aw = a
        bx, by, bz, bw = b
        return (
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
            aw * bw - ax * bx - ay * by - az * bz,
        )

    @staticmethod
    def _quat_conj_xyzw(q) -> tuple[float, float, float, float]:
        x, y, z, w = q
        return (-x, -y, -z, w)

    @staticmethod
    def _quat_normalize_xyzw(q) -> tuple[float, float, float, float]:
        x, y, z, w = q
        n = math.sqrt(x * x + y * y + z * z + w * w)
        if n < 1e-12:
            return (0.0, 0.0, 0.0, 1.0)
        inv = 1.0 / n
        return (x * inv, y * inv, z * inv, w * inv)

    @classmethod
    def _quat_log_xyzw(cls, q) -> tuple[float, float, float]:
        """
        Quaternion logarithm → ℝ³ rotation vector u with ‖u‖ = θ/2.
        For unit q = (sin(θ/2)·n̂, cos(θ/2)).
        """
        x, y, z, w = cls._quat_normalize_xyzw(q)
        w = max(-1.0, min(1.0, w))
        vnorm = math.sqrt(x * x + y * y + z * z)
        if vnorm < 1e-12:
            return (0.0, 0.0, 0.0)
        # atan2 is stable near ±1; scale = (θ/2) / ‖v‖
        scale = math.atan2(vnorm, w) / vnorm
        return (x * scale, y * scale, z * scale)

    @staticmethod
    def _quat_exp_xyzw(u) -> tuple[float, float, float, float]:
        """exp: ℝ³ rotation vector (‖u‖=θ/2) → unit quaternion xyzw."""
        x, y, z = u
        half = math.sqrt(x * x + y * y + z * z)
        if half < 1e-12:
            return (0.0, 0.0, 0.0, 1.0)
        s = math.sin(half) / half
        return (x * s, y * s, z * s, math.cos(half))

    @classmethod
    def _quat_interp_xyzw(cls, q0, q1, alpha: float) -> tuple[float, float, float, float]:
        """
        Unit-quaternion interpolation on SO(3) (not component-wise lerp).

        Geodesic:  q(α) = q0 ⊗ exp(α · log(q0⁻¹ ⊗ q1))
        — constant angular rate along the short arc (handles q ∼ −q).

        Fast path when the relative angle is tiny (typical between consecutive
        ~100 Hz OptiTrack frames): **nlerp** = normalize((1−α)q0 + α q1).
        Same path to first order; only mul/add/sqrt — cheap at 400 Hz × N bodies.
        """
        a = 0.0 if alpha < 0.0 else (1.0 if alpha > 1.0 else float(alpha))
        qa = cls._quat_normalize_xyzw(tuple(float(v) for v in q0))
        qb = cls._quat_normalize_xyzw(tuple(float(v) for v in q1))
        # Double-cover: pick the short hemisphere.
        dot = qa[0] * qb[0] + qa[1] * qb[1] + qa[2] * qb[2] + qa[3] * qb[3]
        if dot < 0.0:
            qb = (-qb[0], -qb[1], -qb[2], -qb[3])
            dot = -dot

        # Small-angle / near-identical: nlerp (‖Δθ‖ ≲ ~3°).
        if dot > 0.9995:
            x = (1.0 - a) * qa[0] + a * qb[0]
            y = (1.0 - a) * qa[1] + a * qb[1]
            z = (1.0 - a) * qa[2] + a * qb[2]
            w = (1.0 - a) * qa[3] + a * qb[3]
            return cls._quat_normalize_xyzw((x, y, z, w))

        # Full geodesic via relative log / scaled exp (no acos of |dot|).
        q_rel = cls._quat_mul_xyzw(cls._quat_conj_xyzw(qa), qb)
        ux, uy, uz = cls._quat_log_xyzw(q_rel)
        q_delta = cls._quat_exp_xyzw((ux * a, uy * a, uz * a))
        return cls._quat_normalize_xyzw(cls._quat_mul_xyzw(qa, q_delta))

    @staticmethod
    def _opti_bodies_by_id(flat: list, n_bodies: int) -> dict[int, list[float]]:
        """Map track id → [id,x,y,z,qx,qy,qz,qw] (last wins if duplicate)."""
        by_id: dict[int, list[float]] = {}
        for i in range(n_bodies):
            chunk = flat[i * 8 : (i + 1) * 8]
            if len(chunk) < 8:
                continue
            try:
                tid = int(round(float(chunk[0])))
                vals = [float(v) for v in chunk[:8]]
            except (TypeError, ValueError):
                continue
            if all(math.isfinite(v) for v in vals[1:]):
                by_id[tid] = vals
            elif tid not in by_id:
                by_id[tid] = vals
        return by_id

    def _lerp_opti_flat(self, flat0: list, flat1: list, alpha: float) -> list[float]:
        """
        Upsample one OptiTrack frame between two measured samples.

        • Match rigid bodies by **track id** (not slot index).
        • Position (x,y,z): linear lerp in ℝ³.
        • Orientation: SO(3) geodesic / nlerp (`_quat_interp_xyzw`) — never
          raw component-wise quat lerp (that leaves the unit sphere).
        """
        n = self.num_rigid_bodies
        need = 8 * n
        a = 0.0 if alpha < 0.0 else (1.0 if alpha > 1.0 else float(alpha))
        f0 = list(flat0) + [float('nan')] * max(0, need - len(flat0))
        f1 = list(flat1) + [float('nan')] * max(0, need - len(flat1))
        by0 = self._opti_bodies_by_id(f0, n)
        by1 = self._opti_bodies_by_id(f1, n)

        # Preserve stream / role column order from the earlier frame.
        order: list[int] = []
        for i in range(n):
            chunk = f0[i * 8 : (i + 1) * 8]
            if len(chunk) < 8:
                order.append(-1 - i)  # placeholder slot
                continue
            try:
                order.append(int(round(float(chunk[0]))))
            except (TypeError, ValueError):
                order.append(-1 - i)

        out: list[float] = []
        for slot, tid in enumerate(order):
            c0 = by0.get(tid) if tid >= 0 else None
            c1 = by1.get(tid) if tid >= 0 else None
            # Fall back to same slot index if id missing (legacy / nan ids).
            if c0 is None and len(f0) >= (slot + 1) * 8:
                c0 = [float(v) for v in f0[slot * 8 : (slot + 1) * 8]]
            if c1 is None and len(f1) >= (slot + 1) * 8:
                c1 = [float(v) for v in f1[slot * 8 : (slot + 1) * 8]]

            if c0 is None and c1 is None:
                out.extend([float('nan')] * 8)
                continue
            if c0 is None:
                out.extend(c1[:8])
                continue
            if c1 is None:
                out.extend(c0[:8])
                continue

            # id: nearest measured sample
            out.append(float(c0[0] if a <= 0.5 else c1[0]))

            # xyz — linear in world frame
            for k in range(1, 4):
                v0, v1 = c0[k], c1[k]
                if math.isfinite(v0) and math.isfinite(v1):
                    out.append((1.0 - a) * v0 + a * v1)
                elif math.isfinite(v0):
                    out.append(v0)
                elif math.isfinite(v1):
                    out.append(v1)
                else:
                    out.append(float('nan'))

            # quat — geodesic on SO(3)
            q0 = c0[4:8]
            q1 = c1[4:8]
            if all(math.isfinite(v) for v in q0) and all(math.isfinite(v) for v in q1):
                out.extend(self._quat_interp_xyzw(q0, q1, a))
            elif all(math.isfinite(v) for v in q0):
                out.extend(q0)
            elif all(math.isfinite(v) for v in q1):
                out.extend(q1)
            else:
                out.extend([float('nan')] * 4)

        ts_src = flat0 if a <= 0.5 else flat1
        if len(ts_src) > need:
            try:
                out.append(float(ts_src[need]))
            except (TypeError, ValueError):
                pass
        return out

    def _interp_opti_at(self, t_s: float) -> tuple[list[float] | None, bool]:
        """
        Return (flat_opti, was_interpolated).

        was_interpolated=True when the pose is fitted between two OptiTrack
        samples (or held at an endpoint); False when t falls on a measured sample.
        """
        if not self._opti_hist:
            return None, False
        if len(self._opti_hist) == 1:
            return list(self._opti_hist[0][1]), False

        # Exact / near-exact hit on a measured sample.
        for t_i, flat_i in self._opti_hist:
            if abs(t_i - t_s) <= 1e-4:
                return list(flat_i), False

        if t_s <= self._opti_hist[0][0]:
            return list(self._opti_hist[0][1]), True
        if t_s >= self._opti_hist[-1][0]:
            return list(self._opti_hist[-1][1]), True

        # Bracket: last sample with t <= query, first with t >= query.
        lo_t, lo_f = self._opti_hist[0]
        hi_t, hi_f = self._opti_hist[-1]
        for t_i, flat_i in self._opti_hist:
            if t_i <= t_s:
                lo_t, lo_f = t_i, flat_i
            if t_i >= t_s:
                hi_t, hi_f = t_i, flat_i
                break
        dt = hi_t - lo_t
        if dt <= 1e-12:
            return list(lo_f), False
        alpha = (t_s - lo_t) / dt
        return self._lerp_opti_flat(lo_f, hi_f, alpha), True


    def _optitrack_cells(self, opt, stamp_s: float | None = None):
        o = list(opt or [])
        n_body_floats = 8 * self.num_rigid_bodies
        if len(o) < n_body_floats:
            body = o + [float('nan')] * (n_body_floats - len(o))
        else:
            body = o[:n_body_floats]
        self._try_lock_optitrack_roles(body)
        body = self._bodies_in_role_order(body)

        body_cells = []
        for i in range(self.num_rigid_bodies):
            chunk = body[i * 8 : (i + 1) * 8]
            if len(chunk) < 8:
                chunk = chunk + [float('nan')] * (8 - len(chunk))
            try:
                id_val = float(chunk[0])
                body_cells.append(
                    str(int(round(id_val))) if math.isfinite(id_val) else 'nan'
                )
            except (TypeError, ValueError):
                body_cells.append('nan')
            for v in chunk[1:]:
                body_cells.append(self._cell(v, '{:.6f}'))

        if stamp_s is not None and math.isfinite(stamp_s):
            body_cells.append(f'{stamp_s:.6f}')
        elif self._latest_opti_recv_time_ns is not None:
            ts = self._latest_opti_recv_time_ns * 1e-9
            body_cells.append(f'{ts:.6f}')
        else:
            body_cells.append('')
        return body_cells

    def _optitrack_cells_at(self, query_t_s: float):
        """Pose columns at query time — interpolate when enabled."""
        if not self._optitrack_interp:
            return self._optitrack_cells(
                self.latest_optitrack if self.latest_optitrack else []
            )

        flat, was_interp = self._interp_opti_at(query_t_s)
        if flat is None:
            return self._optitrack_cells([])
        if was_interp:
            self._opti_interp_rows += 1
        else:
            self._opti_measured_rows += 1
        return self._optitrack_cells(flat, stamp_s=query_t_s)

    def _tick(self):
        if self._collection_stopped:
            return
        if not self._data_collection_started:
            self._warn_if_stuck()
            return
        if self.rows >= self.max_rows:
            if not self._collection_stopped:
                self._collection_stopped = True
                self._stage = 'complete'
                self.get_logger().info(
                    f'stage=complete progress=100.00% '
                    f'rows={self.rows:,}/{self.max_rows:,} (target reached) — '
                    f'stopping CSV; launch Shutdown → motor soft-release'
                )
                if self._fh:
                    try:
                        self._fh.flush()
                        os.fsync(self._fh.fileno())
                    except OSError:
                        pass
                if self._exit_on_max_rows:
                    self.get_logger().info(
                        'exit_on_max_rows=True → rclpy.shutdown() '
                        '(pipeline soft-releases motors)'
                    )
                    rclpy.shutdown()
            return

        mot = self.latest_motor
        opt = self.latest_optitrack

        if self.require_both:
            if mot is None or (opt is None and not self._opti_hist):
                self._warn_if_stuck()
                return
        else:
            if mot is None:
                return

        now_ns = self.get_clock().now().nanoseconds
        t0 = self._collection_start_time_ns or now_ns
        wall_time_s = (now_ns - t0) * 1e-9

        time_stamp, wall_cell = self._time_stamps(mot, wall_time_s)
        k1_cell, k2_cell = self._kappa_cells(mot)
        motor_cells = self._motor_row(mot if mot is not None else [])
        opt_cells = self._optitrack_cells_at(now_ns * 1e-9)

        row = [time_stamp, wall_cell, k1_cell, k2_cell] + motor_cells + opt_cells

        if self._fh is None or self._writer is None:
            return

        try:
            self._writer.writerow(row)
            self.rows += 1
            self._last_row_time_ns = now_ns
            if self.rows % self.flush_every == 0:
                self._fh.flush()
                os.fsync(self._fh.fileno())
        except OSError as e:
            self._log_debug(f'CSV write error: {e}')

        self._maybe_log_progress(now_ns)

    def _maybe_log_progress(self, now_ns: int):
        period_ns = int(self.progress_log_period_sec * 1e9)
        if self._last_progress_log_ns is None:
            self._last_progress_log_ns = now_ns
            pct = 100.0 * self.rows / max(self.max_rows, 1)
            self.get_logger().info(
                f'stage=collecting progress={pct:.2f}% '
                f'rows={self.rows:,}/{self.max_rows:,} '
                f'(opti_fit={self._opti_interp_rows:,} '
                f'opti_meas={self._opti_measured_rows:,})'
            )
            return
        if (now_ns - self._last_progress_log_ns) < period_ns:
            return
        self._last_progress_log_ns = now_ns
        pct = 100.0 * self.rows / max(self.max_rows, 1)
        self.get_logger().info(
            f'stage=collecting progress={pct:.2f}% '
            f'rows={self.rows:,}/{self.max_rows:,} '
            f'(opti_fit={self._opti_interp_rows:,} '
            f'opti_meas={self._opti_measured_rows:,})'
        )

    def _warn_if_stuck(self):
        now_ns = self.get_clock().now().nanoseconds
        if (now_ns - self._last_warn_ns) < int(self.warn_period_sec * 1e9):
            return
        if not self._data_collection_started:
            missing = []
            if not self._saw_motor:
                missing.append(self.motor_topic)
            if self._fh is None:
                if self._optitrack_auto and not self._opt_layout_locked:
                    missing.append(
                        f'{self.optitrack_topic} (CSV header needs valid 8×N+1 layout)'
                    )
                else:
                    missing.append('CSV file not open')
            elif self.require_both and not self._saw_opti:
                missing.append(self.optitrack_topic)
            if missing:
                self._stage = 'waiting_streams'
                self.get_logger().warn(
                    f'stage=waiting_streams — waiting for: {", ".join(missing)} '
                    f'(planned CSV: {self.filename})'
                )
        self._last_warn_ns = now_ns

    def destroy_node(self):
        try:
            if self._fh:
                self._fh.flush()
                os.fsync(self._fh.fileno())
                self._fh.close()
                self._log_debug(
                    f'Closed CSV. rows={self.rows} file={self.filename} '
                    f'opti_fit={self._opti_interp_rows} '
                    f'opti_meas={self._opti_measured_rows}'
                )
            else:
                self._log_debug(
                    f'CSV never opened (0 rows). planned={self.filename} '
                    f'(likely waiting for OptiTrack layout with num_rigid_bodies=0)'
                )
        except OSError as e:
            self._log_debug(f'Error closing CSV: {e}')
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = DataCollector()
    try:
        node._log_debug('data_collection node started')
        rclpy.spin(node)
    except KeyboardInterrupt:
        node._log_debug('Keyboard interrupt')
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
