from setuptools import find_packages, setup
from pathlib import Path
from glob import glob

package_name = 'MyActuator_motor_imu'
pkg_dir = Path(__file__).resolve().parent / package_name
icra_root = pkg_dir / 'ICRA-OneSeg-pkg'


def _icra_package_data() -> list[str]:
    """Ship ICRA-OneSeg-pkg next to the ROS Python module for sys.path imports."""
    if not icra_root.is_dir():
        return []
    out: list[str] = []
    for path in icra_root.rglob('*'):
        if path.is_file():
            out.append(str(path.relative_to(pkg_dir)))
    return out


setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    package_data={
        package_name: _icra_package_data()
        + ['zero_motors.py', 'mpc_tip_control.py', 'mpc_log_recorder.py'],
    },
    include_package_data=True,
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=False,
    maintainer='root',
    maintainer_email='root@todo.todo',
    description='MyActuator 3-motor + 3-IMU one-seg PCC data collection (ICRA-OneSeg-pkg)',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'random_data_collection = MyActuator_motor_imu.random_data_collection:main',
            'mpc_tip_control = MyActuator_motor_imu.mpc_tip_control:main',
            'mpc_log_recorder = MyActuator_motor_imu.mpc_log_recorder:main',
        ],
    },
)
