#!/usr/bin/env python3
"""
Async MPC CSV recorder — off the control loop.

Subscribes to:
  • ``/mpc_log_header`` (std_msgs/String, transient_local) — JSON column list
  • ``/mpc_log`` (std_msgs/Float64MultiArray) — one packed row per control tick

Writes ``mpc_log_YYYYMMDD_HHMMSS.csv`` in a **background thread** so disk flush
never stalls ``mpc_tip_control`` (same split as data-collection side logging).

  ros2 run MyActuator_motor_imu mpc_log_recorder --ros-args -p log_dir:=/path
  # usually started by mpc_tip_control.launch.py
"""
from __future__ import annotations

import atexit
import csv
import json
import queue
import signal
import threading
import time
from datetime import datetime
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from std_msgs.msg import Float64MultiArray, String

_LATCHED = QoSProfile(
    depth=1,
    reliability=ReliabilityPolicy.RELIABLE,
    durability=DurabilityPolicy.TRANSIENT_LOCAL,
    history=HistoryPolicy.KEEP_LAST,
)


class MpcLogRecorder(Node):
    def __init__(self) -> None:
        super().__init__("mpc_log_recorder")
        self.declare_parameter("log_dir", str(Path.cwd()))
        self.declare_parameter("flush_every", 400)  # rows between disk flushes
        self.declare_parameter("topic_log", "/mpc_log")
        self.declare_parameter("topic_header", "/mpc_log_header")
        self.declare_parameter("queue_size", 8000)

        log_dir = Path(
            self.get_parameter("log_dir").get_parameter_value().string_value
        ).expanduser()
        log_dir.mkdir(parents=True, exist_ok=True)
        self._flush_every = max(
            1, int(self.get_parameter("flush_every").get_parameter_value().integer_value)
        )
        qsize = max(
            64, int(self.get_parameter("queue_size").get_parameter_value().integer_value)
        )
        topic_log = (
            self.get_parameter("topic_log").get_parameter_value().string_value
            or "/mpc_log"
        )
        topic_hdr = (
            self.get_parameter("topic_header").get_parameter_value().string_value
            or "/mpc_log_header"
        )

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._csv_path = log_dir / f"mpc_log_{ts}.csv"
        self._columns: list[str] | None = None
        self._q: queue.Queue[list[float] | None] = queue.Queue(maxsize=qsize)
        self._drop_count = 0
        self._row_count = 0
        self._stop = threading.Event()
        self._writer = threading.Thread(
            target=self._writer_loop, name="mpc_csv_writer", daemon=True
        )
        self._writer.start()
        atexit.register(self._shutdown_writer)

        self.create_subscription(String, topic_hdr, self._on_header, _LATCHED)
        self.create_subscription(Float64MultiArray, topic_log, self._on_row, 50)
        self.get_logger().info(
            f"Recording /mpc_log → {self._csv_path}  "
            f"(flush_every={self._flush_every}, queue={qsize})"
        )

    def _on_header(self, msg: String) -> None:
        if self._columns is not None:
            return
        try:
            payload = json.loads(msg.data)
            cols = payload.get("columns") if isinstance(payload, dict) else payload
            if not isinstance(cols, list) or not cols:
                raise ValueError("empty columns")
            self._columns = [str(c) for c in cols]
            self.get_logger().info(
                f"Header OK ({len(self._columns)} cols) — writing {self._csv_path.name}"
            )
        except Exception as exc:
            self.get_logger().error(f"Bad /mpc_log_header: {exc}")

    def _on_row(self, msg: Float64MultiArray) -> None:
        # Non-blocking enqueue — never stall the DDS callback / control pub path
        try:
            self._q.put_nowait(list(msg.data))
        except queue.Full:
            self._drop_count += 1
            if self._drop_count % 400 == 1:
                self.get_logger().warn(
                    f"/mpc_log queue full — dropped {self._drop_count} rows "
                    "(recorder slower than 400 Hz; increase queue_size or flush_every)"
                )

    def _writer_loop(self) -> None:
        f = None
        w = None
        buf: list[list[float]] = []
        header_wait_logged = False
        try:
            while not self._stop.is_set():
                try:
                    item = self._q.get(timeout=0.25)
                except queue.Empty:
                    if f is not None and buf:
                        w.writerows(buf)
                        buf.clear()
                        f.flush()
                    continue
                if item is None:
                    break
                if self._columns is None:
                    if not header_wait_logged:
                        self.get_logger().info("Waiting for /mpc_log_header…")
                        header_wait_logged = True
                    # Re-queue would risk deadlock; drop until header arrives
                    continue
                if f is None:
                    f = open(self._csv_path, "w", newline="", buffering=1 << 20)
                    w = csv.writer(f)
                    w.writerow(self._columns)
                    f.flush()
                buf.append(item)
                self._row_count += 1
                if len(buf) >= self._flush_every:
                    w.writerows(buf)
                    buf.clear()
                    f.flush()
        finally:
            try:
                if f is not None and w is not None:
                    if buf:
                        w.writerows(buf)
                    f.flush()
                    f.close()
            except Exception:
                pass

    def _shutdown_writer(self) -> None:
        if self._stop.is_set():
            return
        self._stop.set()
        try:
            self._q.put_nowait(None)
        except queue.Full:
            pass
        self._writer.join(timeout=5.0)
        self.get_logger().info(
            f"Recorder stopped. rows={self._row_count} dropped={self._drop_count} "
            f"file={self._csv_path}"
        )


def main(args=None) -> None:
    rclpy.init(args=args)
    node = MpcLogRecorder()

    def _sig(_s, _f):
        node._shutdown_writer()
        if rclpy.ok():
            rclpy.shutdown()

    signal.signal(signal.SIGINT, _sig)
    signal.signal(signal.SIGTERM, _sig)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node._shutdown_writer()
        try:
            node.destroy_node()
        except Exception:
            pass
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
