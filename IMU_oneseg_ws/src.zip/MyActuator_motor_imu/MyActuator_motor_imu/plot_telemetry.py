"""
Live plot: 3 motors + 3 IMUs telemetry from Teensy_3motor_3IMU
=============================================================

Holds motors at ``home_position_saved.txt`` and plots angles, torques, and
all 12 quaternion components.

Run::

  python plot_telemetry.py

Edit COM_PORT below. Close the figure or Ctrl+C to soft-stop.
"""

from __future__ import annotations

import sys
import time
from collections import deque
from pathlib import Path

import numpy as np

try:
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation
except ImportError as exc:
    raise SystemExit("matplotlib required: pip install matplotlib\n" + str(exc)) from exc

# =============================================================================
# USER SETTINGS
# =============================================================================

COM_PORT = "/dev/ttyACM0" if sys.platform != "win32" else "COM4"
SERIAL_BAUD = 2_000_000
COM_FREQ_HZ = 400.0
PLOT_HZ = 25.0
HISTORY_S = 8.0

OPERATION_KP = 7.0
OPERATION_KD = 0.25
T_FF_NM = [1.0, 1.0, 1.0]
SHUTDOWN_T_FF_RAMP_S = 2.0

# Home file from zero_motors.py (None → ./home_position_saved.txt).
HOME_FILE = None

# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
ICRA_PKG_DIR = SCRIPT_DIR / "ICRA-OneSeg-pkg"
if not (ICRA_PKG_DIR / "icra_oneseg").is_dir():
    raise ModuleNotFoundError(
        f"ICRA-OneSeg-pkg not found at {ICRA_PKG_DIR}\n"
        "Expected next to plot_telemetry.py"
    )
if str(ICRA_PKG_DIR) not in sys.path:
    sys.path.insert(0, str(ICRA_PKG_DIR))

from icra_oneseg.RobstrideMotorMessagesClass import MotorMessages  # noqa: E402
from icra_oneseg.home_position_io import (  # noqa: E402
    default_home_position_path,
    load_home_positions_rad,
)
from icra_oneseg.rs05_drive_tuning import apply_drive_tuning  # noqa: E402
from icra_oneseg.soft_t_ff_release import ramp_t_ff_to_zero  # noqa: E402
from icra_oneseg.stack import build_ocm_stream, configure_imu_telemetry, latest_telemetry  # noqa: E402

pi = np.pi
NUM_MOTORS = 3
NUM_IMUS = 3
MOTOR_IDS = [0x10, 0x11, 0x12]
MOTOR_COLORS = ["#1f77b4", "#ff7f0e", "#2ca02c"]
IMU_COLORS = ["#1f77b4", "#d62728", "#2ca02c"]
COMP_STYLES = ["-", "--", "-.", ":"]


def main() -> None:
    home_path = Path(HOME_FILE) if HOME_FILE else default_home_position_path(SCRIPT_DIR)
    home = load_home_positions_rad(home_path, n_motors=NUM_MOTORS, script_dir=SCRIPT_DIR)
    print(f"Home: {home_path}\n  {home}")
    hist_len = max(int(HISTORY_S * COM_FREQ_HZ), 80)

    t_hist: deque[float] = deque(maxlen=hist_len)
    ang_hist = [deque(maxlen=hist_len) for _ in range(NUM_MOTORS)]
    trq_hist = [deque(maxlen=hist_len) for _ in range(NUM_MOTORS)]
    q_hist = [deque(maxlen=hist_len) for _ in range(NUM_IMUS * 4)]

    t_ff = np.asarray(T_FF_NM, dtype=float)
    v_set = np.zeros(NUM_MOTORS, dtype=float)

    ctrl = MotorMessages(
        ComsPort=COM_PORT,
        Coms_Freq=float(COM_FREQ_HZ),
        Motor_ids=MOTOR_IDS,
        InitialAnglesOffsets=[0.0] * NUM_MOTORS,
        minAngles=[-20 * pi] * NUM_MOTORS,
        maxAngles=[20 * pi] * NUM_MOTORS,
        MotorType="RS05",
        baudrate=int(SERIAL_BAUD),
        log_Coms_freq=False,
    )
    ctrl.communicator.verbose = False
    configure_imu_telemetry(ctrl, n_motors=NUM_MOTORS)

    def stream(pos, *, t_ff_use=None):
        return build_ocm_stream(
            ctrl,
            pos,
            t_ff=t_ff if t_ff_use is None else t_ff_use,
            v_set=v_set,
            kp=OPERATION_KP,
            kd=OPERATION_KD,
        )

    print(f"Plot telemetry  COM={COM_PORT}  {COM_FREQ_HZ:g} Hz")

    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
    ax_ang, ax_trq, ax_q = axes
    ang_lines, trq_lines, q_lines = [], [], []
    for i in range(NUM_MOTORS):
        (ln,) = ax_ang.plot([], [], color=MOTOR_COLORS[i], lw=1.2, label=f"M{i + 1}")
        ang_lines.append(ln)
        (ln,) = ax_trq.plot([], [], color=MOTOR_COLORS[i], lw=1.2, label=f"M{i + 1}")
        trq_lines.append(ln)
    ax_ang.set_ylabel("angle [rad]")
    ax_ang.set_title("Motor angles")
    ax_ang.grid(True, alpha=0.3)
    ax_ang.legend(loc="upper right", ncol=3)
    ax_trq.set_ylabel("torque [N·m]")
    ax_trq.set_title("Motor torques")
    ax_trq.grid(True, alpha=0.3)
    ax_trq.legend(loc="upper right", ncol=3)

    for imu_i in range(NUM_IMUS):
        for c_i, c_name in enumerate("wxyz"):
            (ln,) = ax_q.plot(
                [],
                [],
                color=IMU_COLORS[imu_i],
                linestyle=COMP_STYLES[c_i],
                lw=1.1,
                label=f"IMU{imu_i + 1}_{c_name}",
            )
            q_lines.append(ln)
    ax_q.set_xlabel("time [s]")
    ax_q.set_ylabel("quat")
    ax_q.set_ylim(-1.05, 1.05)
    ax_q.set_title("IMU quaternions (Absolute RV)")
    ax_q.grid(True, alpha=0.3)
    ax_q.legend(loc="upper right", ncol=3, fontsize=7)
    status = fig.text(0.01, 0.01, "waiting...", family="monospace", fontsize=9)
    fig.tight_layout(rect=(0, 0.03, 1, 1))

    state = {"t0": None, "last_tick": None, "frames": 0, "running": True}

    try:
        ctrl.StopMotors()
        time.sleep(0.05)
        ctrl.SetControlMode("operation")
        ctrl.ApplyFirmwareVelocityHeadroom()
        apply_drive_tuning(ctrl)
        ctrl.StartMotors()
        time.sleep(0.1)
        ctrl.communicator.set_data_to_send(stream(home))
        ctrl.communicator.start()
        time.sleep(0.4)
        state["t0"] = time.perf_counter()
        state["last_tick"] = state["t0"]
        fig.canvas.mpl_connect("close_event", lambda _e: state.__setitem__("running", False))

        def update(_):
            if not state["running"]:
                plt.close(fig)
                return ang_lines + trq_lines + q_lines

            now = time.perf_counter()
            t = now - state["t0"]
            ctrl.communicator.set_data_to_send(stream(home))
            frame = latest_telemetry(ctrl, n_motors=NUM_MOTORS)
            if frame is not None:
                t_hist.append(t)
                for i in range(NUM_MOTORS):
                    ang_hist[i].append(float(frame.angles_rad[i]))
                    trq_hist[i].append(float(frame.torques_nm[i]))
                flat = frame.quaternions.reshape(-1)
                for i in range(12):
                    q_hist[i].append(float(flat[i]))
                state["frames"] += 1
                status.set_text(
                    f"t={t:7.2f}s  frames={state['frames']}  "
                    f"M1={frame.angles_rad[0]:+.3f}  IMU1_w={flat[0]:+.3f}"
                )
            else:
                status.set_text("waiting for Teensy frame...")

            if t_hist:
                xs = list(t_hist)
                for i, ln in enumerate(ang_lines):
                    ln.set_data(xs, list(ang_hist[i]))
                for i, ln in enumerate(trq_lines):
                    ln.set_data(xs, list(trq_hist[i]))
                for i, ln in enumerate(q_lines):
                    ln.set_data(xs, list(q_hist[i]))
                x0 = max(0.0, xs[-1] - HISTORY_S)
                x1 = max(HISTORY_S, xs[-1])
                for ax in axes:
                    ax.set_xlim(x0, x1)
                ax_ang.relim()
                ax_ang.autoscale_view(scalex=False, scaley=True)
                ax_trq.relim()
                ax_trq.autoscale_view(scalex=False, scaley=True)

            sleep_s = (state["last_tick"] + 1.0 / COM_FREQ_HZ) - time.perf_counter()
            if sleep_s > 0:
                time.sleep(sleep_s)
            state["last_tick"] = max(
                state["last_tick"] + 1.0 / COM_FREQ_HZ, time.perf_counter()
            )
            return ang_lines + trq_lines + q_lines

        _anim = FuncAnimation(
            fig, update, interval=max(1, int(1000.0 / PLOT_HZ)), blit=False, cache_frame_data=False
        )
        plt.show()
    except KeyboardInterrupt:
        print("\nInterrupted.")
    finally:
        state["running"] = False
        try:
            ramp_t_ff_to_zero(
                ctrl,
                home,
                t_ff_start=t_ff,
                duration_s=SHUTDOWN_T_FF_RAMP_S,
                com_freq_hz=COM_FREQ_HZ,
                build_stream=lambda c, pos, t_ff=None: stream(pos, t_ff_use=t_ff),
            )
        except Exception:
            pass
        try:
            ctrl.communicator.running = False
            time.sleep(0.1)
            ctrl.StopMotors()
            ctrl.communicator.stop()
        except Exception:
            pass
        print(f"Stopped. frames={state['frames']}")


if __name__ == "__main__":
    main()
