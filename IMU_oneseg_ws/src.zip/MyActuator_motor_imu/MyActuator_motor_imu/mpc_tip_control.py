#!/usr/bin/env python3
"""
MPC tip tracking — one-seg continuum (ICRA-OneSeg-pkg + NN/OptiTrack Koopman).

Three ``control_handle`` modes (edit tunables in ``main()``)::

  1 — LSTM ŷ → Koopman @ 400 Hz  (pinv)
  2 — MLP  ŷ → Koopman @ 400 Hz  (ridge)
  3 — OptiTrack packed shape → Koopman @ 100 Hz

State z is delay-lifted: ``z=[x(k),x(k-1),…,x(k-d)]``. Tip MPC costs only the
RB5 channels (``pF_RB5_*`` and ``pB_RB5_in_RB1_*``). Control u is Δenc (3),
accumulated then sent as absolute encoder targets (same OCM path as
``random_data_collection.py``).

Hold ``HOLD_S`` at home:
  • first ``IMU_CALIBRATION_S`` (5 s) estimates ``R_imu_in_rb`` from OptiTrack+IMU
    (same mount as NN training; may also load ``R_imu_in_rb.npz``)
  • remaining hold fills LSTM/delay history with IMU features after
    RB-align → IMU3_aligned (imu12 = tip+mid only)
then track ``mpc_ref/tip_ref.csv``.

Real-time compute (handles 1–2 @ 400 Hz → ≤2.5 ms/tick):
  • NN on **CPU** by default (small nets; CUDA H2D/D2H often slower than CPU)
  • **LSTM stateful 1-step** (default): carry hidden state → ~0.2 ms/fwd instead of
    re-running seq100 (~1.5 ms). Bootstraps with one full window once history is full.
  • OSQP: dense q, no polish, capped iters, warm-start (no stdout redirect)
  • Preallocated NN/MPC buffers + ``torch.inference_mode``; MLP optional JIT
  • ``COMPUTE_WARMUP_ITERS`` dummy NN+OSQP solves before the control timer starts
  • Longer ``HOLD_S`` is fine (history fill + settle); edit in ``main()``

When the tip reference is exhausted: ramp to home + soft-release t_ff and exit
(so ``ros2 launch … mpc_tip_control.launch.py`` finishes).
Logging: publishes ``/mpc_log`` each tick; ``mpc_log_recorder`` writes CSV
in another process (no disk I/O in the 400 Hz loop). Optional local CSV via
``WRITE_LOCAL_CSV=True``.

  ros2 launch MyActuator_motor_imu mpc_tip_control.launch.py
"""
from __future__ import annotations

import atexit
import csv
import json
import os
import signal
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import rclpy
import scipy.sparse as sp
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from scipy.spatial.transform import Rotation
from std_msgs.msg import Float32MultiArray, Float64MultiArray, String

try:
    import osqp
except ImportError as _e:  # pragma: no cover
    raise SystemExit(
        "osqp is required for MPC. Install with:  pip install osqp\n" + str(_e)
    ) from _e

# =============================================================================
# Paths: ICRA-OneSeg-pkg + workspace + NN training sources
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
ICRA_PKG_DIR = SCRIPT_DIR / "ICRA-OneSeg-pkg"
if not (ICRA_PKG_DIR / "icra_oneseg").is_dir():
    raise ModuleNotFoundError(f"ICRA-OneSeg-pkg not found at {ICRA_PKG_DIR}")
if str(ICRA_PKG_DIR) not in sys.path:
    sys.path.insert(0, str(ICRA_PKG_DIR))

from icra_oneseg.RobstrideMotorMessagesClass import MotorMessages  # noqa: E402
from icra_oneseg.home_position_io import (  # noqa: E402
    default_home_position_path,
    find_workspace_root,
    load_home_positions_rad,
)
from icra_oneseg.pcc_kinematics import (  # noqa: E402
    KAPPA_LIMIT_DEFAULT,
    PCCParameters,
    kappa_from_rel_enc,
    slack_scale_vec,
    target_abs_enc_from_kappa,
)
from icra_oneseg.rs05_drive_tuning import apply_drive_tuning  # noqa: E402
from icra_oneseg.soft_t_ff_release import ramp_t_ff_to_zero  # noqa: E402
from icra_oneseg.stack import (  # noqa: E402
    IMU_COUNT,
    build_ocm_stream,
    configure_imu_telemetry,
    go_home,
    latest_telemetry,
    total_reply_bytes,
)

_ws = find_workspace_root(SCRIPT_DIR)
if _ws is None:
    raise RuntimeError(
        "Could not find IMU_oneseg_ws (optitrack_roles.py). "
        "Set IMU_ONESEG_WS=/root/DataCollection/IMU_oneseg_ws"
    )
WS_ROOT = Path(_ws)
if str(WS_ROOT) not in sys.path:
    sys.path.insert(0, str(WS_ROOT))
from optitrack_roles import (  # noqa: E402
    base_tip_layout_label,
    lock_roles_by_y_sort,
    role_count_for_bodies,
    tip_role_index,
)

NN_SRC = WS_ROOT / "NN_training" / "Training" / "src"
NN_MODELS = WS_ROOT / "NN_training" / "Training" / "models"
KOOP_MODEL_ROOT = WS_ROOT / "Koopman training" / "Model"
if str(NN_SRC) not in sys.path:
    sys.path.insert(0, str(NN_SRC))

N_MOTORS = 3
N_IMU = IMU_COUNT
N_RB = 5
LOG_HZ = 400.0  # CSV / motor publish (match Koopman train rate — do not raise without re-ID)
# RT I/O: CSV flush / ROS alloc jitter dominates once NN+OSQP ≪ 2.5 ms (MLP case)
CSV_FLUSH_EVERY = 400  # flush ≈1×/s @ 400 Hz (was 40 → disk jitter)
CSV_FILE_BUFFER = 1 << 20  # 1 MiB stdio buffer
LOG_CONSOLE_HZ_DEFAULT = 20.0  # was 100 — logger I/O steals ticks

# /motor layout (same as random_data_collection, for optional side recorders)
IDX_TARGET = 0
IDX_REAL = N_MOTORS
IDX_TRQ = 2 * N_MOTORS
IDX_KAPPA1 = 3 * N_MOTORS
IDX_KAPPA2 = IDX_KAPPA1 + 1
IDX_QUAT = IDX_KAPPA2 + 1
IDX_SEQ_TIME = IDX_QUAT + N_IMU * 4
MOTOR_MSG_LEN = IDX_SEQ_TIME + 1


# =============================================================================
# Dense linear MPC (same structure as Force_OCM mpc_current_control)
# =============================================================================


class DenseKMPC:
    """x₊ = A x + B u,  y = C x; OSQP on Δu with box constraints.

    Tuned for real-time (~400 Hz): dense matvecs, no polish, warm-start,
    no per-solve stdout redirect / sparse rebuilds.
    """

    def __init__(
        self,
        A,
        B,
        C,
        N,
        Q=None,
        R=None,
        P=None,
        u_lb=None,
        u_ub=None,
        verbose=False,
        *,
        max_iter: int = 400,
        eps_abs: float = 1e-4,
        eps_rel: float = 1e-4,
        polish: bool = False,
    ):
        self.A = np.asarray(A, dtype=np.float64)
        self.B = np.asarray(B, dtype=np.float64)
        self.C = np.asarray(C, dtype=np.float64)
        self.n = int(self.A.shape[0])
        self.m = int(self.B.shape[1])
        self.p = int(self.C.shape[0])
        self.verbose = bool(verbose)
        self.N = int(N)
        self._max_iter = int(max_iter)
        self._eps_abs = float(eps_abs)
        self._eps_rel = float(eps_rel)
        self._polish = bool(polish)

        Qs = np.eye(self.p) if Q is None else np.atleast_2d(np.asarray(Q, dtype=np.float64))
        Rs = 1e-3 * np.eye(self.m) if R is None else np.atleast_2d(np.asarray(R, dtype=np.float64))
        Ps = 100.0 * Qs if P is None else np.atleast_2d(np.asarray(P, dtype=np.float64))
        self.Q, self.R, self.P = Qs, Rs, Ps

        Q_blocks = [sp.csc_matrix(Ps if i == self.N - 1 else Qs) for i in range(self.N)]
        self.Qbar = sp.block_diag(Q_blocks, format="csc")
        self.Rbar = sp.block_diag([sp.csc_matrix(Rs)] * self.N, format="csc")

        self.u_lb = u_lb
        self.u_ub = u_ub
        self.osqp_prob = None
        self.last_solution = None
        self._build_propagation()
        self._build_qp()
        # Dense caches for the hot path (avoid sparse rebuild every tick)
        self._Bbar_T_Q = (self.Bbar.T @ self.Qbar.toarray()).astype(np.float64, copy=False)
        self._q_buf = np.empty(self.N * self.m, dtype=np.float64)
        self._r_buf = np.empty(self.N * self.p, dtype=np.float64)
        self._yref_buf = np.empty(self.N * self.p, dtype=np.float64)

    def _build_propagation(self) -> None:
        n, m, N = self.n, self.m, self.N
        A, B = self.A, self.B
        A_pows = [np.eye(n)]
        for _ in range(N):
            A_pows.append(A_pows[-1] @ A)
        self.A_x = np.vstack(A_pows[1:])
        B_u = np.zeros((n * N, m * N))
        for i in range(1, N + 1):
            for j in range(i):
                B_u[(i - 1) * n : i * n, j * m : (j + 1) * m] = A_pows[i - 1 - j] @ B
        self.B_u = B_u
        Cbar = sp.block_diag([sp.csc_matrix(self.C)] * N, format="csc")
        self.Abar = (Cbar @ sp.csc_matrix(self.A_x)).toarray()
        self.Bbar = (Cbar @ sp.csc_matrix(self.B_u)).toarray()

    def _build_qp(self) -> None:
        Bbar = sp.csc_matrix(self.Bbar)
        Qb = self.Qbar.tocsc()
        H = Bbar.T @ Qb @ Bbar + self.Rbar.tocsc()
        self.H = sp.csc_matrix((H + H.T) * 0.5 * 2)
        G_list, h_list = [], []
        if self.u_lb is not None or self.u_ub is not None:
            I_u = sp.eye(self.N * self.m, format="csc")
            if self.u_ub is not None:
                ub = np.broadcast_to(np.asarray(self.u_ub).flatten(), (self.m,))
                G_list.append(I_u)
                h_list.append(np.tile(ub, self.N))
            if self.u_lb is not None:
                lb = np.broadcast_to(np.asarray(self.u_lb).flatten(), (self.m,))
                G_list.append(-I_u)
                h_list.append(-np.tile(lb, self.N))
        if G_list:
            self.G = sp.vstack(G_list, format="csc")
            self.h_raw = np.hstack(h_list)
        else:
            self.G = None
            self.h_raw = None
        # Fixed constraint matrices (bounds constant for box on u)
        if self.G is None:
            self._A_c = sp.csc_matrix((0, self.N * self.m))
            self._l_c = np.array([])
            self._u_c = np.array([])
        else:
            self._A_c = self.G
            self._l_c = -np.inf * np.ones(self.G.shape[0])
            self._u_c = self.h_raw

    def solve(self, x0, ref_traj, warm_start=True):
        x0 = np.asarray(x0, dtype=np.float64).reshape(-1)
        ref_traj = np.asarray(ref_traj, dtype=np.float64)
        if ref_traj.ndim == 2:
            yref = ref_traj.reshape(-1)
        else:
            yref = ref_traj.reshape(-1)
        # r = Abar x0 - yref ; q = 2 Bbarᵀ Q r  (dense, no sparse rebuild)
        np.subtract(self.Abar @ x0, yref, out=self._r_buf)
        np.multiply(2.0, self._Bbar_T_Q @ self._r_buf, out=self._q_buf)
        q = self._q_buf
        if self.osqp_prob is None:
            self.osqp_prob = osqp.OSQP()
            self.osqp_prob.setup(
                P=self.H,
                q=q,
                A=self._A_c,
                l=self._l_c,
                u=self._u_c,
                verbose=False,
                polish=self._polish,
                eps_abs=self._eps_abs,
                eps_rel=self._eps_rel,
                max_iter=self._max_iter,
                warm_start=True,
                adaptive_rho=False,
                check_termination=25,
            )
        else:
            self.osqp_prob.update(q=q)
        if warm_start and self.last_solution is not None:
            self.osqp_prob.warm_start(x=self.last_solution)
        res = self.osqp_prob.solve()
        if res.info.status not in ("solved", "solved inaccurate"):
            return None
        self.last_solution = np.asarray(res.x, dtype=np.float64).copy()
        return self.last_solution.reshape(self.N, self.m)

    def warmup(self, n: int = 50) -> float:
        """Run dummy solves to JIT / allocate OSQP internals. Returns mean ms."""
        z0 = np.zeros(self.n, dtype=np.float64)
        yref = np.zeros((self.N, self.p), dtype=np.float64)
        # First call builds the solver
        self.solve(z0, yref, warm_start=False)
        t0 = time.perf_counter()
        for _ in range(max(1, int(n))):
            self.solve(z0, yref, warm_start=True)
        return 1e3 * (time.perf_counter() - t0) / max(1, int(n))


# =============================================================================
# Helpers
# =============================================================================


def _normalize_quat_wxyz(q: np.ndarray) -> np.ndarray:
    q = np.asarray(q, dtype=np.float64).reshape(-1, 4)
    n = np.linalg.norm(q, axis=-1, keepdims=True)
    out = q / np.clip(n, 1e-12, None)
    out = np.where(out[:, 0:1] < 0.0, -out, out)
    bad = (~np.isfinite(out).all(axis=-1, keepdims=True)) | (n < 1e-12)
    ident = np.zeros_like(out)
    ident[:, 0] = 1.0
    return np.where(bad, ident, out)


def _quat_mul(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    """Hamilton product, wxyz."""
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    return np.array(
        [
            w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
            w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
            w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
            w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
        ],
        dtype=np.float64,
    )


def _imu_in_base_frame(quats_wxyz: np.ndarray) -> np.ndarray:
    """
    Express IMU1..3 relative to IMU3 (robot base IMU → identity).

    Matches NN ``imu_world_to_imu3_base`` / rich ``imu_frame=IMU3_aligned``.
    """
    q = _normalize_quat_wxyz(quats_wxyz)
    q_base = q[2]
    q_base_inv = np.array([q_base[0], -q_base[1], -q_base[2], -q_base[3]])
    out = np.empty_like(q)
    for i in range(q.shape[0]):
        out[i] = _normalize_quat_wxyz(_quat_mul(q_base_inv, q[i]).reshape(1, 4))[0]
    out[2] = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)
    return out


def _R_to_quat_wxyz(R: np.ndarray) -> np.ndarray:
    """(3,3) or (…,3,3) → matching (4,) or (…,4) wxyz."""
    R = np.asarray(R, dtype=np.float64)
    single = R.ndim == 2
    if single:
        R = R.reshape(1, 3, 3)
    lead = R.shape[:-2]
    xyzw = Rotation.from_matrix(R.reshape(-1, 3, 3)).as_quat()  # xyzw
    q = np.column_stack([xyzw[:, 3], xyzw[:, 0], xyzw[:, 1], xyzw[:, 2]])
    q = _normalize_quat_wxyz(q).reshape(lead + (4,))
    return q[0] if single else q


def _quat_wxyz_to_R(q_wxyz: np.ndarray) -> np.ndarray:
    """(4,) or (…,4) wxyz → matching (3,3) or (…,3,3)."""
    q_in = np.asarray(q_wxyz, dtype=np.float64)
    single = q_in.ndim == 1
    q = _normalize_quat_wxyz(q_in.reshape(-1, 4))
    # scipy wants xyzw
    R = Rotation.from_quat(q[:, [1, 2, 3, 0]]).as_matrix()
    if single:
        return R[0]
    return R.reshape(q_in.shape[:-1] + (3, 3))


def _average_rotmats(Rs: np.ndarray) -> np.ndarray:
    """Average (N,3,3) via SVD / orthogonal Procrustes (same as NN training)."""
    Rs = np.asarray(Rs, dtype=np.float64)
    M = Rs.mean(axis=0)
    U, _, Vt = np.linalg.svd(M)
    R = U @ Vt
    if np.linalg.det(R) < 0.0:
        U = U.copy()
        U[:, -1] *= -1.0
        R = U @ Vt
    return R


# IMU index (1-based) → OptiTrack RB id — matches NN training / data_processing
IMU_ON_RB: dict[int, int] = {1: 5, 2: 3, 3: 1}


def _estimate_R_imu_in_rb(
    quat_rb_w: np.ndarray,
    imu_w: np.ndarray,
    *,
    imu_on_rb: dict[int, int] | None = None,
) -> dict[int, np.ndarray]:
    """
    Fixed mount ``R_imu_in_rb`` from a calib window (same as ``calibrate_imu_in_rb``)::

        R_w_imu ≈ R_w_rb @ R_imu_in_rb
        R_imu_in_rb = mean(R_w_rbᵀ @ R_w_imu)
    """
    quat_rb_w = np.asarray(quat_rb_w, dtype=np.float64)
    imu_w = np.asarray(imu_w, dtype=np.float64)
    if quat_rb_w.ndim != 3 or imu_w.ndim != 3:
        raise ValueError("quat_rb_w and imu_w must be (N, *, 4)")
    n = quat_rb_w.shape[0]
    quat_rb_w = _normalize_quat_wxyz(quat_rb_w.reshape(-1, 4)).reshape(n, -1, 4)
    imu_w = _normalize_quat_wxyz(imu_w.reshape(-1, 4)).reshape(n, -1, 4)
    mapping = dict(imu_on_rb or IMU_ON_RB)
    R_rb = _quat_wxyz_to_R(quat_rb_w)
    R_imu = _quat_wxyz_to_R(imu_w)
    n_rb = R_rb.shape[1]
    out: dict[int, np.ndarray] = {}
    for imu_i, rb_nom in sorted(mapping.items()):
        rb_id = int(rb_nom)
        if rb_id < 1 or rb_id > n_rb:
            out[imu_i] = np.eye(3)
            continue
        R_rel = np.einsum(
            "nji,njk->nik",
            R_rb[:, rb_id - 1],
            R_imu[:, imu_i - 1],
        )
        ok = np.isfinite(R_rel).all(axis=(1, 2))
        if not np.any(ok):
            out[imu_i] = np.eye(3)
            continue
        out[imu_i] = _average_rotmats(R_rel[ok])
    return out


def _ideal_imu_world_from_real(
    imu_w_real: np.ndarray,
    R_imu_in_rb: dict[int, np.ndarray] | None,
) -> np.ndarray:
    """``R_ideal = R_real @ R_imu_in_rbᵀ`` (NN ``ideal_imu_world_from_real``)."""
    q = _normalize_quat_wxyz(np.asarray(imu_w_real, dtype=np.float64).reshape(-1, 4))
    if R_imu_in_rb is None:
        return q
    R_real = _quat_wxyz_to_R(q)
    out = np.empty_like(q)
    for i in range(q.shape[0]):
        imu_i = i + 1
        R_m = np.asarray(R_imu_in_rb.get(imu_i, np.eye(3)), dtype=np.float64)
        # R_ideal = R_real @ R_m.T  (same as training einsum nij,kj→nik)
        R_id = R_real[i] @ R_m.T
        out[i] = _R_to_quat_wxyz(R_id)
    return out


def _imu_world_to_rb1(
    imu_w_wxyz: np.ndarray,
    quat_rb1_w_wxyz: np.ndarray,
) -> np.ndarray:
    """Express IMU world quats in RB1: ``R_b = R_w1ᵀ @ R_w_imu``."""
    q_imu = _normalize_quat_wxyz(np.asarray(imu_w_wxyz, dtype=np.float64).reshape(-1, 4))
    q1 = _normalize_quat_wxyz(np.asarray(quat_rb1_w_wxyz, dtype=np.float64).reshape(1, 4))[0]
    R1_T = _quat_wxyz_to_R(q1).T
    R_imu = _quat_wxyz_to_R(q_imu)
    out = np.empty_like(q_imu)
    for i in range(q_imu.shape[0]):
        out[i] = _R_to_quat_wxyz(R1_T @ R_imu[i])
    return out


def _interp_tip_ref(ref_xz: np.ndarray, factor: int) -> np.ndarray:
    """Upsample tip_ref by ``factor`` with linear interpolation (same wall-clock path)."""
    if int(factor) <= 1:
        return np.asarray(ref_xz, dtype=np.float64)
    src = np.asarray(ref_xz, dtype=np.float64)
    n = src.shape[0]
    if n < 2:
        return np.repeat(src, int(factor), axis=0)
    t_src = np.arange(n, dtype=np.float64)
    t_dst = np.linspace(0.0, n - 1, (n - 1) * int(factor) + 1)
    out = np.empty((t_dst.size, 2), dtype=np.float64)
    out[:, 0] = np.interp(t_dst, t_src, src[:, 0])
    out[:, 1] = np.interp(t_dst, t_src, src[:, 1])
    return out


def _tip_channel_indices(feature_names: list[str]) -> list[int]:
    """Indices of pF_RB5_* and pB_RB5_* (xz) in the 16-D shape state."""
    idxs: list[int] = []
    for i, raw in enumerate(feature_names):
        n = str(raw)
        if "RB5" not in n:
            continue
        if n.endswith("_x") or n.endswith("_z") or n.endswith("_px") or n.endswith("_pz"):
            idxs.append(i)
    if len(idxs) < 2:
        # fallback: last half of dual pack tip = channels 6,7,14,15 for e+xz
        idxs = [6, 7, 14, 15]
    return idxs


# =============================================================================
# Node
# =============================================================================


class MPCTipControlNode(Node):
    """Tip MPC with three Koopman / NN control handles (tunables = class attrs)."""

    # ========================================================================
    # Tunables — edit here (or override from main())
    # ========================================================================
    # Tunables live in main() only — class attrs here are defaults overwritten at launch.
    CONTROL_HANDLE = 2  # overwritten by main(); edit main() CONTROL_HANDLE

    COM_PORT = "/dev/ttyACM0"
    SERIAL_BAUD = 2_000_000
    MOTOR_IDS = [0x10, 0x11, 0x12]
    OPERATION_KP = 10.0
    OPERATION_KD = 0.31
    T_FF_NM = [1.0, 1.0, 1.0]
    V_SET_RAD_S = [0.0, 0.0, 0.0]
    BASE_REL_ENC_RAD = [0.0, 0.0, 0.0]  # hold pose = home + base_rel (same as random_data_collection)
    HOME_POSITION_FILE = ""  # empty → workspace home_position_saved.txt

    PCC_L_SEG_MM = 240.0
    PCC_CABLE_OFFSET_MM = 8.5
    PCC_R_PULLEY_MM = 14.5
    SLACK_SCALE = 1.0

    # Startup: tension @ home → HOLD_S (first IMU_CALIBRATION_S = mount align) → track
    HOLD_S = 15.0  # total home hold (calib + LSTM/delay fill); longer OK for RT settle
    IMU_CALIBRATION_S = 5.0  # first 5 s: OptiTrack+IMU → R_imu_in_rb (matches NN n_imu_calib)
    IMU_CALIBRATION_MIN_SAMPLES = 100
    IMU_MOUNT_NPZ = str(WS_ROOT / "R_imu_in_rb.npz")  # optional saved mount fallback
    RETURN_HOME_DURATION_S = 2.0
    SHUTDOWN_T_FF_RAMP_S = 2.0

    # Real-time compute (override via env: MPC_NN_DEVICE=cuda|cpu)
    NN_DEVICE = "cpu"  # small nets; CUDA optional (MPC_NN_DEVICE=cuda)
    # Stateful LSTM is ~0.2 ms → 2 threads enough; full-seq mode wants 4.
    TORCH_NUM_THREADS = 2
    # LSTM: carry (h,c) and run T=1 each tick (~9× faster than seq100 every tick).
    LSTM_STATEFUL = True
    NN_JIT_TRACE = True  # MLP only when LSTM_STATEFUL (JIT drops hc)
    COMPUTE_WARMUP_ITERS = 80  # dummy NN + OSQP solves before timer (cold → steady)
    # OSQP (DenseKMPC): polish off, modest iters — enough for warm-started Δu QP
    OSQP_MAX_ITER = 400
    OSQP_EPS_ABS = 1e-4
    OSQP_EPS_REL = 1e-4
    OSQP_POLISH = False

    # MPC
    # Horizon by control rate: [400 Hz, 100 Hz]
    MPC_HORIZON = [20, 10]
    # Q on tip outputs [pF_RB5_x,s pF_RB5_z, pB_RB5_x, pB_RB5_z]
    MPC_Q_TIP = [1.0, 1.0, 1.0, 1.0]
    MPC_R_DIAG = [1.0, 1.0, 1.0]  # penalty on Δenc (3)
    DELTA_U_MAX = 0.005  # |Δenc| physical bound [rad] per control step
    # Same κ limit as random_data_collection — this is the only actuation limit.
    # enc is always derived from κ (no separate enc-rad clip).
    KAPPA_LIMIT = 7.5

    REF_CSV = str(WS_ROOT / "mpc_ref" / "tip_ref.csv")
    LOG_DIR = str(WS_ROOT)  # mpc_log_*.csv here

    # Model paths (NN Koopman @ 400 Hz + OptiTrack Koopman @ 100 Hz)
    HANDLE_SETUP = {
        1: {
            "label": "LSTM ŷ → Koopman ridge @ 400 Hz (seq100)",
            "control_hz": 400.0,
            "koopman_npz": str(
                KOOP_MODEL_ROOT
                / "LSTM"
                / "lstm_L2_H256_seq100_stride50_drop1e-1_lr1e-3_sr400_valtip_rmse_oute+xy_lossglocal"
                / "koop_d10_seed42_full_ridge"
                / "koopman_model.npz"
            ),
            "nn_rel": (
                "LSTM/lstm_L2_H256_seq100_stride50_drop1e-1_lr1e-3_sr400_valtip_rmse_oute+xy_lossglocal"
            ),
            "state_source": "nn",
        },
        2: {
            "label": "MLP ŷ → Koopman ridge @ 400 Hz",
            "control_hz": 400.0,
            "koopman_npz": str(
                KOOP_MODEL_ROOT
                / "MLP"
                / "mlp_L2_W256_drop0_lr1e-3_actrelu_sr400_valtip_rmse_oute+xy_lossglocal"
                / "koop_d10_seed42_full_ridge"
                / "koopman_model.npz"
            ),
            "nn_rel": (
                "MLP/mlp_L2_W256_drop0_lr1e-3_actrelu_sr400_valtip_rmse_oute+xy_lossglocal"
            ),
            "state_source": "nn",
        },
        3: {
            "label": "OptiTrack Y → Koopman @ 100 Hz",
            "control_hz": 100.0,
            "koopman_npz": str(
                KOOP_MODEL_ROOT
                / "MLP"
                / "mlp_L2_W256_drop0_lr1e-3_actrelu_sr400_valtip_rmse_oute+xy_lossglocal"
                / "koop_d10_seed42_full_ridge"
                / "koopman_model_optitrack.npz"
            ),
            "nn_rel": None,
            "state_source": "optitrack",
        },
    }

    TOPIC_MOTOR = "/motor"
    TOPIC_OPTITRACK = "/optitrack/rigid_body_array"
    TOPIC_MPC_ERROR = "/mpc_error"
    TOPIC_MPC_LOG = "/mpc_log"  # Float64MultiArray → mpc_log_recorder
    TOPIC_MPC_LOG_HEADER = "/mpc_log_header"  # latched JSON column names
    WRITE_LOCAL_CSV = False  # True = also write CSV in this node (debug only)
    LOG_CONSOLE_HZ = 20.0  # tracking status (keep low — ROS log I/O causes Δt spikes)
    LOG_CONSOLE_HOLD_HZ = 5.0  # quieter during hold / calib
    CSV_FLUSH_EVERY = 400  # only used if WRITE_LOCAL_CSV
    PUBLISH_ERR_EVERY = 4  # /mpc_error at 100 Hz (state still 400 Hz on /motor)

    @staticmethod
    def _resolve_horizon(horizon, control_hz: float) -> int:
        """Pick horizon from ``[N_400, N_100]`` (or a single int) by control rate."""
        if isinstance(horizon, (list, tuple)):
            if len(horizon) < 2:
                raise ValueError(
                    f"MPC_HORIZON list must be [N_400Hz, N_100Hz], got {horizon!r}"
                )
            n400, n100 = int(horizon[0]), int(horizon[1])
            return n400 if float(control_hz) >= 200.0 else n100
        return int(horizon)

    def __init__(self) -> None:
        super().__init__("mpc_tip_control")
        cfg = type(self)
        self._handle = int(cfg.CONTROL_HANDLE)
        if self._handle not in cfg.HANDLE_SETUP:
            raise ValueError(f"CONTROL_HANDLE must be 1–3, got {self._handle}")
        self._setup = dict(cfg.HANDLE_SETUP[self._handle])
        self._control_hz = float(self._setup["control_hz"])
        self._log_hz = float(LOG_HZ)
        self._dt_log = 1.0 / self._log_hz
        self._ctrl_stride = max(1, int(round(self._log_hz / self._control_hz)))
        self._state_source = str(self._setup["state_source"])

        self._com_port = str(cfg.COM_PORT)
        self._baud = int(cfg.SERIAL_BAUD)
        self._motor_ids = [int(x) for x in cfg.MOTOR_IDS]
        self._n_motors = len(self._motor_ids)
        self._operation_kp = float(cfg.OPERATION_KP)
        self._operation_kd = float(cfg.OPERATION_KD)
        self._t_ff = np.asarray(cfg.T_FF_NM, dtype=np.float64).reshape(-1)
        self._v_set = np.asarray(cfg.V_SET_RAD_S, dtype=np.float64).reshape(-1)
        if self._t_ff.size == 1:
            self._t_ff = np.full(self._n_motors, float(self._t_ff[0]))
        if self._v_set.size == 1:
            self._v_set = np.full(self._n_motors, float(self._v_set[0]))

        self._pcc = PCCParameters(
            L_seg_mm=float(cfg.PCC_L_SEG_MM),
            cable_offset_mm=float(cfg.PCC_CABLE_OFFSET_MM),
            R_pulley_mm=float(cfg.PCC_R_PULLEY_MM),
        )
        self._slack_scale = slack_scale_vec(cfg.SLACK_SCALE, n_motors=self._n_motors)
        self._hold_s = float(cfg.HOLD_S)
        self._horizon = self._resolve_horizon(cfg.MPC_HORIZON, self._control_hz)
        self._Q_tip = np.asarray(cfg.MPC_Q_TIP, dtype=np.float64)
        self._R_diag = np.asarray(cfg.MPC_R_DIAG, dtype=np.float64)
        self._delta_u_max = float(cfg.DELTA_U_MAX)
        self._kappa_limit = float(getattr(cfg, "KAPPA_LIMIT", KAPPA_LIMIT_DEFAULT))
        self._ref_csv = str(cfg.REF_CSV)
        self._log_dir = Path(cfg.LOG_DIR)
        self._nn_device_pref = str(
            os.environ.get("MPC_NN_DEVICE", getattr(cfg, "NN_DEVICE", "cpu"))
        ).strip().lower()
        self._torch_threads = int(getattr(cfg, "TORCH_NUM_THREADS", 1))
        self._nn_jit = bool(getattr(cfg, "NN_JIT_TRACE", True))
        self._lstm_stateful = bool(getattr(cfg, "LSTM_STATEFUL", True))
        self._compute_warmup_iters = int(getattr(cfg, "COMPUTE_WARMUP_ITERS", 80))
        self._osqp_max_iter = int(getattr(cfg, "OSQP_MAX_ITER", 400))
        self._osqp_eps_abs = float(getattr(cfg, "OSQP_EPS_ABS", 1e-4))
        self._osqp_eps_rel = float(getattr(cfg, "OSQP_EPS_REL", 1e-4))
        self._osqp_polish = bool(getattr(cfg, "OSQP_POLISH", False))

        home_file = str(cfg.HOME_POSITION_FILE).strip()
        self._home_path = (
            Path(home_file) if home_file else default_home_position_path(SCRIPT_DIR)
        )
        self._abs_home = load_home_positions_rad(
            str(self._home_path), n_motors=self._n_motors, script_dir=SCRIPT_DIR
        )
        br = np.asarray(cfg.BASE_REL_ENC_RAD, dtype=np.float64).reshape(-1)
        if br.size == 1:
            br = np.full(self._n_motors, float(br[0]))
        self._base_rel = br
        self._hold_abs = self._abs_home + self._base_rel

        # Optional ROS override (launch out_dir → log_dir)
        self.declare_parameter("log_dir", str(cfg.LOG_DIR))
        self.declare_parameter("hold_s", float(cfg.HOLD_S))
        log_dir_p = self.get_parameter("log_dir").get_parameter_value().string_value.strip()
        if log_dir_p:
            self._log_dir = Path(log_dir_p)
            type(self).LOG_DIR = str(self._log_dir)
        self._log_dir.mkdir(parents=True, exist_ok=True)
        hold_p = float(self.get_parameter("hold_s").value)
        if hold_p > 0:
            self._hold_s = hold_p

        # runtime state
        self._target_abs = self._hold_abs.copy()
        self._enc_rel_cmd = self._base_rel.copy()
        self._kappa_cmd = np.zeros(2, dtype=np.float64)
        self._cmd_initialized = False
        self._tracking = False
        self._tick_count = 0
        self._ctrl_tick = 0
        self._t0 = None
        self._hold_done_logged = False
        self._done = False
        self._shutdown_done = False
        self._connected = False
        self._q0: np.ndarray | None = None
        self._imu_cal_s = float(cfg.IMU_CALIBRATION_S)
        self._imu_cal_min = int(cfg.IMU_CALIBRATION_MIN_SAMPLES)
        self._imu_mount_npz = Path(str(cfg.IMU_MOUNT_NPZ)).expanduser()
        self._R_imu_in_rb: dict[int, np.ndarray] | None = None
        self._imu_mount_ready = False
        self._imu_mount_fallback = False
        self._calib_imu_buf: list[np.ndarray] = []
        self._calib_rb_buf: list[np.ndarray] = []
        self._quat_rb_w = np.full((N_RB, 4), np.nan, dtype=np.float64)
        self._quat_rb1_w = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)

        self._delay = 0
        self._nx = 0
        self._feature_names: list[str] = []
        self._tip_idxs: list[int] = []
        self._x_mean = self._x_std = None
        self._u_mean = self._u_std = None
        self._delta_u_handle = 1
        self._A = self._B = self._C = None
        self._mpc: DenseKMPC | None = None
        self._state_history: list[np.ndarray] = []
        self._nn_input_history: list[np.ndarray] = []  # legacy list; ring preferred
        self._nn_hist_buf: np.ndarray | None = None  # (cap, in_dim) float32 ring
        self._nn_hist_cap = 0
        self._nn_hist_i = 0
        self._nn_hist_n = 0
        self._nn_in_dim = 0
        self._nn_out_dim = 0
        self._nn_xt = None  # preallocated torch input
        self._nn_y_buf: np.ndarray | None = None  # denorm workspace
        self._nn_seq_work: np.ndarray | None = None  # (seq, in) float32
        self._nn_row_work: np.ndarray | None = None  # (in,) float32 MLP
        self._nn_xt_step = None  # (1,1,in) for stateful LSTM
        self._nn_hc = None  # LSTM hidden/cell carry
        self._nn_lstm_bootstrapped = False
        self._torch = None
        self._z_buf: np.ndarray | None = None
        self._ref_n_buf: np.ndarray | None = None
        self._ref_phys_buf: np.ndarray | None = None
        self._ref_traj: np.ndarray | None = None
        self._ref_idx = 0

        self._nn = None
        self._nn_cfg: dict[str, Any] | None = None
        self._nn_device = None
        self._nn_arch = ""
        self._seq_len = 1
        self._nn_x_mean: np.ndarray | None = None
        self._nn_x_std: np.ndarray | None = None
        self._nn_y_mean: np.ndarray | None = None
        self._nn_y_std: np.ndarray | None = None
        self._pred_x: np.ndarray | None = None  # last physical shape x (16,)
        self._pred_tip = np.array([np.nan, np.nan], dtype=np.float64)
        self._nan_tip = np.array([np.nan, np.nan], dtype=np.float64)

        # OptiTrack
        self._ot_ids: list[int] | None = None
        self._opti_roles_locked = False
        self._opti_ready = False
        self._markers_xz = np.full((N_RB, 2), np.nan, dtype=np.float64)
        self._pos_rb1 = np.full((N_RB, 3), np.nan, dtype=np.float64)
        self._latest_ot_flat: list[float] | None = None

        self._load_koopman()
        self._load_nn_if_needed()
        self._load_reference()
        if self._mpc is None or self._ref_traj is None:
            raise RuntimeError("Failed to load Koopman model or tip reference")
        self._alloc_rt_buffers()
        self._warmup_compute()
        # Freeze GC during control — periodic collections cause multi-ms Δt spikes
        try:
            import gc

            gc.disable()
            self.get_logger().info("GC disabled for RT loop (re-enabled on shutdown)")
        except Exception:
            pass

        self._write_local_csv = bool(getattr(cfg, "WRITE_LOCAL_CSV", False))
        self._csv_path = None
        self._csv_file = None
        self._csv_writer = None
        self._csv_row_buf: list[list] = []
        self._csv_flush_every = max(
            1, int(getattr(cfg, "CSV_FLUSH_EVERY", CSV_FLUSH_EVERY))
        )
        if self._write_local_csv:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            self._csv_path = self._log_dir / f"mpc_log_{ts}.csv"
            self._csv_file = open(
                self._csv_path,
                "w",
                newline="",
                buffering=int(CSV_FILE_BUFFER),
            )
            self._csv_writer = csv.writer(self._csv_file)
            self._csv_writer.writerow(self._mpc_log_columns())
            atexit.register(self._close_csv)
            self.get_logger().warn(
                f"WRITE_LOCAL_CSV=True — CSV in control node → {self._csv_path} "
                "(prefer mpc_log_recorder)"
            )

        self._motor_pub = self.create_publisher(Float64MultiArray, cfg.TOPIC_MOTOR, 10)
        self._err_pub = self.create_publisher(Float64MultiArray, cfg.TOPIC_MPC_ERROR, 10)
        # Latched header + per-tick /mpc_log for async recorder (no disk in this node)
        _latched = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
        )
        self._log_header_pub = self.create_publisher(
            String, cfg.TOPIC_MPC_LOG_HEADER, _latched
        )
        self._log_pub = self.create_publisher(
            Float64MultiArray, cfg.TOPIC_MPC_LOG, 10
        )
        self._log_msg = Float64MultiArray()
        n_log = 15 + 5 * self._n_motors + 4 * N_IMU + 3 * N_RB + int(self._nx)
        self._log_msg.data = [0.0] * n_log
        hdr = String()
        hdr.data = json.dumps({"columns": self._mpc_log_columns()})
        self._log_header_pub.publish(hdr)
        self.get_logger().info(
            f"Publishing {cfg.TOPIC_MPC_LOG} ({n_log} floats/tick) — "
            "CSV via mpc_log_recorder"
        )

        # Reuse ROS msgs — avoid per-tick list/msg alloc
        self._motor_msg = Float64MultiArray()
        self._motor_msg.data = [0.0] * MOTOR_MSG_LEN
        self._err_msg = Float64MultiArray()
        self._err_msg.data = [0.0] * 6
        self._publish_err_every = max(1, int(getattr(cfg, "PUBLISH_ERR_EVERY", 4)))
        self.create_subscription(
            Float32MultiArray, cfg.TOPIC_OPTITRACK, self._on_optitrack, 10
        )

        pi = float(np.pi)
        self._ctrl = MotorMessages(
            ComsPort=self._com_port,
            Coms_Freq=self._log_hz,
            Motor_ids=self._motor_ids,
            InitialAnglesOffsets=[0.0] * self._n_motors,
            minAngles=[-20 * pi] * self._n_motors,
            maxAngles=[20 * pi] * self._n_motors,
            MotorType="RS05",
            baudrate=self._baud,
            log_Coms_freq=False,
        )
        self._ctrl.communicator.verbose = False
        configure_imu_telemetry(self._ctrl, n_motors=self._n_motors)

        self._log_every = max(1, int(round(self._log_hz / float(cfg.LOG_CONSOLE_HZ))))
        self._log_every_hold = max(
            1, int(round(self._log_hz / float(cfg.LOG_CONSOLE_HOLD_HZ)))
        )
        self._connect_and_arm()
        self._timer = self.create_timer(self._dt_log, self._tick)
        self.get_logger().info(
            f"ACTIVE control_handle={self._handle} ({self._setup['label']})  "
            f"koopman={Path(self._setup['koopman_npz']).name}  "
            f"ctrl={self._control_hz:g} Hz (stride={self._ctrl_stride})  "
            f"log={self._log_hz:g} Hz  hold={self._hold_s:g} s  "
            f"console_track={cfg.LOG_CONSOLE_HZ:g} Hz  "
            f"horizon={self._horizon}  delay={self._delay}  tip_cols={self._tip_idxs}  "
            f"Q={self._Q_tip.tolist()}  Δu_max={self._delta_u_max}"
        )

    # ------------------------------------------------------------------ loaders
    def _load_koopman(self) -> None:
        path = Path(self._setup["koopman_npz"])
        if not path.is_file():
            raise FileNotFoundError(f"Koopman npz not found: {path}")
        with np.load(path, allow_pickle=True) as f:
            self._A = np.asarray(f["A"], dtype=np.float64)
            self._B = np.asarray(f["B"], dtype=np.float64)
            self._C_full = np.asarray(f["C"], dtype=np.float64)
            self._x_mean = np.asarray(f["x_mean"], dtype=np.float64)
            self._x_std = np.asarray(f["x_std"], dtype=np.float64)
            self._u_mean = np.asarray(f["u_mean"], dtype=np.float64)
            self._u_std = np.asarray(f["u_std"], dtype=np.float64)
            self._delay = int(np.asarray(f["delay"]).reshape(-1)[0])
            self._delta_u_handle = int(np.asarray(f["delta_u_handle"]).reshape(-1)[0])
            self._feature_names = [str(n) for n in np.asarray(f["feature_names"])]
            hz = float(np.asarray(f["sample_rate_hz"]).reshape(-1)[0])
        self._nx = int(self._x_mean.size)
        self._x_std = np.where(self._x_std < 1e-12, 1.0, self._x_std)
        self._u_std = np.where(self._u_std < 1e-12, 1.0, self._u_std)
        self._tip_idxs = _tip_channel_indices(self._feature_names)
        n_lifted = int(self._A.shape[0])
        # C: map lifted z → tip channels of *current* x (first nx block)
        C = np.zeros((len(self._tip_idxs), n_lifted), dtype=np.float64)
        for j, idx in enumerate(self._tip_idxs):
            if idx < self._nx:
                C[j, idx] = 1.0
        self._C = C

        du_max = self._delta_u_max / self._u_std  # MPC in normalized u
        Q = np.diag(self._Q_tip[: len(self._tip_idxs)])
        R = np.diag(self._R_diag[: self._B.shape[1]])
        self._mpc = DenseKMPC(
            A=self._A,
            B=self._B,
            C=self._C,
            N=self._horizon,
            Q=Q,
            R=R,
            u_lb=-du_max,
            u_ub=du_max,
            verbose=False,
            max_iter=self._osqp_max_iter,
            eps_abs=self._osqp_eps_abs,
            eps_rel=self._osqp_eps_rel,
            polish=self._osqp_polish,
        )
        self.get_logger().info(
            f"Koopman {path.name}: A{self._A.shape} B{self._B.shape} C{self._C.shape} "
            f"delay={self._delay} hz={hz:g} features={self._nx} tip={self._tip_idxs} "
            f"OSQP(max_iter={self._osqp_max_iter}, polish={self._osqp_polish})"
        )

    def _load_nn_if_needed(self) -> None:
        if self._state_source != "nn":
            return
        import torch
        from LSTM.LSTM_training import PoseRNN
        from MLP.MLP_training import PoseMLP

        rel = self._setup.get("nn_rel")
        if not rel:
            raise RuntimeError("nn_rel required for NN state source")
        nn_dir = NN_MODELS / rel
        cfg_path = nn_dir / "config.json"
        ckpt = nn_dir / "model.pt"
        if not cfg_path.is_file() or not ckpt.is_file():
            raise FileNotFoundError(f"NN model missing under {nn_dir}")
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        self._nn_cfg = cfg
        arch = str(cfg.get("arch", "MLP")).strip().lower()
        self._nn_arch = arch
        self._seq_len = int(cfg.get("seq_len", 1)) if arch == "lstm" else 1

        # Small models: CPU default; CUDA via MPC_NN_DEVICE=cuda (prealloc buffers).
        pref = self._nn_device_pref
        if pref in ("cuda", "gpu") and torch.cuda.is_available():
            device = torch.device("cuda")
        else:
            device = torch.device("cpu")
            if pref in ("cuda", "gpu") and not torch.cuda.is_available():
                self.get_logger().warn("MPC_NN_DEVICE=cuda but CUDA unavailable — using CPU")
        try:
            # LSTM benefits from a few threads; MLP is tiny — keep modest to leave
            # cores for ROS/serial. Env MPC_TORCH_THREADS overrides.
            thr_env = os.environ.get("MPC_TORCH_THREADS", "").strip()
            if thr_env:
                nthr = max(1, int(thr_env))
            elif arch == "lstm" and not self._lstm_stateful:
                nthr = max(4, int(self._torch_threads))  # full seq100
            else:
                # stateful LSTM ~0.2 ms or MLP: 1–2 threads leave cores for ROS/serial
                nthr = max(1, min(2, int(self._torch_threads)))
            self._torch_threads = nthr
            torch.set_num_threads(nthr)
            if hasattr(torch, "set_num_interop_threads"):
                torch.set_num_interop_threads(1)
        except Exception:
            pass

        in_dim, out_dim = int(cfg["in_dim"]), int(cfg["out_dim"])
        self._nn_in_dim = in_dim
        self._nn_out_dim = out_dim
        if arch == "mlp":
            model = PoseMLP(
                in_dim,
                out_dim,
                layers=int(cfg.get("layers", 2)),
                width=int(cfg.get("width", 256)),
                dropout=float(cfg.get("dropout", 0.0)),
                activation=str(cfg.get("activation", "relu")),
            ).to(device)
        elif arch == "lstm":
            model = PoseRNN(
                in_dim,
                out_dim,
                layers=int(cfg.get("layers", 2)),
                hidden=int(cfg.get("hidden", 256)),
                dropout=float(cfg.get("dropout", 0.1)),
            ).to(device)
        else:
            raise ValueError(f"unsupported NN arch {arch!r}")
        blob = torch.load(ckpt, map_location=device, weights_only=False)
        state = (
            blob["model_state_dict"]
            if isinstance(blob, dict) and "model_state_dict" in blob
            else blob
        )
        model.load_state_dict(state)
        model.eval()
        for p in model.parameters():
            p.requires_grad_(False)

        # Preallocate torch inputs. Stateful LSTM uses T=1 + carried (h,c).
        if arch == "lstm":
            self._nn_xt = torch.zeros(
                1, self._seq_len, in_dim, dtype=torch.float32, device=device
            )
            self._nn_xt_step = torch.zeros(
                1, 1, in_dim, dtype=torch.float32, device=device
            )
            self._nn_seq_work = np.zeros(
                (self._seq_len, in_dim), dtype=np.float32
            )
            self._nn_row_work = np.zeros(in_dim, dtype=np.float32)
            self._nn_hc = None
            self._nn_lstm_bootstrapped = False
        else:
            self._nn_xt = torch.zeros(1, in_dim, dtype=torch.float32, device=device)
            self._nn_xt_step = None
            self._nn_seq_work = None
            self._nn_row_work = np.zeros(in_dim, dtype=np.float32)
        self._nn_y_buf = np.empty(out_dim, dtype=np.float64)

        # JIT drops optional hc — skip for stateful LSTM (keep eager for hc carry).
        do_jit = self._nn_jit and not (arch == "lstm" and self._lstm_stateful)
        if do_jit:
            try:
                with torch.inference_mode():
                    traced = torch.jit.trace(model, self._nn_xt.clone(), check_trace=False)
                    try:
                        traced = torch.jit.optimize_for_inference(traced)
                    except Exception:
                        pass
                model = traced
                self.get_logger().info("NN torch.jit.trace OK")
            except Exception as exc:
                self.get_logger().warn(f"NN JIT skipped ({exc})")
        elif arch == "lstm" and self._lstm_stateful:
            self.get_logger().info("LSTM stateful 1-step ON (JIT off — keep hc)")

        self._nn = model
        self._nn_device = device
        self._torch = torch  # keep module ref; avoid import-per-tick

        # Train-time z-score (quat channels: mean=0, std=1 — identity)
        self._nn_x_mean = np.asarray(cfg["x_mean"], dtype=np.float64).reshape(-1)
        self._nn_x_std = np.asarray(cfg["x_std"], dtype=np.float64).reshape(-1)
        self._nn_y_mean = np.asarray(cfg["y_mean"], dtype=np.float64).reshape(-1)
        self._nn_y_std = np.asarray(cfg["y_std"], dtype=np.float64).reshape(-1)
        self._nn_x_std = np.where(self._nn_x_std < 1e-12, 1.0, self._nn_x_std)
        self._nn_y_std = np.where(self._nn_y_std < 1e-12, 1.0, self._nn_y_std)
        # float32 copies for in-place normalize into torch buffer
        self._nn_x_mean_f32 = self._nn_x_mean.astype(np.float32)
        self._nn_x_std_f32 = self._nn_x_std.astype(np.float32)
        qmask = cfg.get("x_quat_channel_mask")
        if qmask is not None:
            qmask = np.asarray(qmask, dtype=bool).reshape(-1)
            if qmask.shape == self._nn_x_mean.shape:
                self._nn_x_mean[qmask] = 0.0
                self._nn_x_std[qmask] = 1.0
                self._nn_x_mean_f32[qmask] = 0.0
                self._nn_x_std_f32[qmask] = 1.0
        if self._nn_x_mean.size != in_dim or self._nn_y_mean.size != out_dim:
            raise RuntimeError(
                f"NN config norms size mismatch: x={self._nn_x_mean.size}/{in_dim} "
                f"y={self._nn_y_mean.size}/{out_dim}"
            )
        # Ring buffer: enough for LSTM seq + delay + slack (no list realloc)
        cap = max(self._seq_len, self._delay + 2) * 4 + 64
        self._nn_hist_cap = int(cap)
        self._nn_hist_buf = np.zeros((self._nn_hist_cap, in_dim), dtype=np.float32)
        self._nn_hist_i = 0
        self._nn_hist_n = 0
        imu = str(cfg.get("imu", "imu12"))
        mode = (
            "stateful-1step"
            if (arch == "lstm" and self._lstm_stateful)
            else ("seq" + str(self._seq_len) if arch == "lstm" else "mlp")
        )
        self.get_logger().info(
            f"NN {arch} loaded from {nn_dir.name}  in={in_dim} out={out_dim} "
            f"imu={imu} trq={cfg.get('use_trq')} cmd={cfg.get('cmd')}  "
            f"mode={mode} device={device} threads={self._torch_threads}"
        )

    def _alloc_rt_buffers(self) -> None:
        """Preallocate delay/ref workspaces once models + horizon are known."""
        need = int(self._delay) + 1
        self._z_buf = np.empty(need * int(self._nx), dtype=np.float64)
        n_tip = len(self._tip_idxs)
        self._ref_n_buf = np.empty((self._horizon, n_tip), dtype=np.float64)
        self._ref_phys_buf = np.empty((self._horizon, n_tip), dtype=np.float64)

    def _warmup_compute(self) -> None:
        """Cold → steady NN + OSQP before the 400 Hz timer (OK to take seconds)."""
        n = max(1, int(self._compute_warmup_iters))
        if self._mpc is not None:
            ms = self._mpc.warmup(n)
            self.get_logger().info(
                f"OSQP warmup ×{n}: {ms:.3f} ms/solve "
                f"(budget ~{1000.0 / self._control_hz:.2f} ms @ {self._control_hz:g} Hz)"
            )
        if self._nn is None or self._nn_hist_buf is None:
            return
        # Seed ring with zeros so predict path is exercised
        row = np.zeros(self._nn_in_dim, dtype=np.float32)
        for _ in range(max(self._seq_len, 1) + 2):
            self._nn_hist_push(row)
        torch = self._torch
        t0 = time.perf_counter()
        ok = 0
        with torch.inference_mode():
            for _ in range(n):
                y = self._nn_predict_x()
                if y is not None:
                    ok += 1
        ms = 1e3 * (time.perf_counter() - t0) / n
        self.get_logger().info(f"NN warmup ×{n}: {ms:.3f} ms/fwd (ok={ok}/{n})")
        # Leave history empty so hold-phase IMU fill is clean
        self._nn_hist_i = 0
        self._nn_hist_n = 0
        self._nn_hc = None
        self._nn_lstm_bootstrapped = False
        if self._nn_hist_buf is not None:
            self._nn_hist_buf.fill(0.0)

    def _nn_hist_push(self, row: np.ndarray) -> None:
        buf = self._nn_hist_buf
        if buf is None:
            self._nn_input_history.append(np.asarray(row, dtype=np.float32))
            return
        i = self._nn_hist_i % self._nn_hist_cap
        np.copyto(buf[i], np.asarray(row, dtype=np.float32).reshape(-1))
        self._nn_hist_i += 1
        self._nn_hist_n = min(self._nn_hist_n + 1, self._nn_hist_cap)

    def _nn_hist_ready(self, need: int) -> bool:
        if self._nn_hist_buf is not None:
            return self._nn_hist_n >= need
        return len(self._nn_input_history) >= need

    def _nn_hist_fill_seq(self, out: np.ndarray, need: int) -> None:
        """Write last ``need`` rows into ``out`` (need, in_dim) in time order."""
        buf = self._nn_hist_buf
        if buf is None:
            out[:] = np.stack(self._nn_input_history[-need:], axis=0)
            return
        # indices ending at hist_i - 1
        end = self._nn_hist_i
        cap = self._nn_hist_cap
        for t in range(need):
            out[t] = buf[(end - need + t) % cap]

    def _load_reference(self) -> None:
        path = Path(self._ref_csv)
        if not path.is_file():
            raise FileNotFoundError(f"tip reference not found: {path}")
        raw = np.genfromtxt(path, delimiter=",", names=True)
        if raw.dtype.names is None:
            data = np.genfromtxt(path, delimiter=",", skip_header=1)
            xz = np.asarray(data[:, :2], dtype=np.float64)
        else:
            names = {n.lower(): n for n in raw.dtype.names}
            xz = np.column_stack(
                [np.asarray(raw[names["x"]], dtype=np.float64),
                 np.asarray(raw[names["z"]], dtype=np.float64)]
            )
        # 400 Hz control → upsample so wall-clock tracking speed matches 100 Hz
        factor = max(1, int(round(self._control_hz / 100.0)))
        self._ref_traj = _interp_tip_ref(xz, factor)
        # Tip ref is RB1 (x,z) — same as Fig.5 / NN labels. Sanity vs κ ball:
        # large |x| or |z| can need |κ| > KAPPA_LIMIT even if tip is in the OT cloud.
        x_rng = (float(xz[:, 0].min()), float(xz[:, 0].max()))
        z_rng = (float(xz[:, 1].min()), float(xz[:, 1].max()))
        self.get_logger().info(
            f"tip_ref (RB1 x,z): {xz.shape[0]} pts → {self._ref_traj.shape[0]} @ "
            f"{self._control_hz:g} Hz (×{factor})  file={path}\n"
            f"  AABB x=[{x_rng[0]:+.4f},{x_rng[1]:+.4f}]  "
            f"z=[{z_rng[0]:+.4f},{z_rng[1]:+.4f}] m  "
            f"κ_limit={self._kappa_limit:g} (match data collection)"
        )

    def _mpc_log_columns(self) -> list[str]:
        """CSV /mpc_log column names (must match packed Float64 row)."""
        hdr = [
            "time_s",
            "control_handle",
            "tracking",
            "x_tar",
            "z_tar",
            "x_pred_tip",
            "z_pred_tip",
            "x_ot_tip",
            "z_ot_tip",
            "err_pred_x",
            "err_pred_z",
            "err_ot_x",
            "err_ot_z",
            "kappa1_cmd",
            "kappa2_cmd",
            "target_enc01",
            "target_enc02",
            "target_enc03",
            "real_enc01",
            "real_enc02",
            "real_enc03",
            "cal_enc01",
            "cal_enc02",
            "cal_enc03",
            "trq01",
            "trq02",
            "trq03",
            "u_delta1",
            "u_delta2",
            "u_delta3",
            "quat1_w",
            "quat1_x",
            "quat1_y",
            "quat1_z",
            "quat2_w",
            "quat2_x",
            "quat2_y",
            "quat2_z",
            "quat3_w",
            "quat3_x",
            "quat3_y",
            "quat3_z",
        ]
        for rb in range(1, N_RB + 1):
            hdr.extend([f"ot_RB{rb}_x", f"ot_RB{rb}_y", f"ot_RB{rb}_z"])
        for i in range(self._nx):
            name = self._feature_names[i] if i < len(self._feature_names) else f"x{i}"
            hdr.append(f"pred_{name}")
        return hdr

    def _close_csv(self) -> None:
        try:
            buf = getattr(self, "_csv_row_buf", None)
            if buf and getattr(self, "_csv_writer", None) is not None:
                self._csv_writer.writerows(buf)
                buf.clear()
            if getattr(self, "_csv_file", None) is not None and not self._csv_file.closed:
                self._csv_file.flush()
                self._csv_file.close()
        except Exception:
            pass
        try:
            import gc

            gc.enable()
        except Exception:
            pass

    # -------------------------------------------------------------- motors / OT
    def _build_stream(self, ctrl, pos_rad, *, t_ff=None):
        return build_ocm_stream(
            ctrl,
            pos_rad,
            t_ff=self._t_ff if t_ff is None else t_ff,
            v_set=self._v_set,
            kp=self._operation_kp,
            kd=self._operation_kd,
        )

    def _connect_and_arm(self) -> None:
        """Arm motors with t_ff tension at hold pose, optional IMU tip calibrate (like random_data_collection)."""
        c = self._ctrl
        c.StopMotors()
        time.sleep(0.05)
        c.SetControlMode("operation")
        c.ApplyFirmwareVelocityHeadroom()
        apply_drive_tuning(c)
        c.StartMotors()
        time.sleep(0.05)

        # Tension at home (+ base_rel) — same OCM stream as random_data_collection
        self._target_abs = np.asarray(self._hold_abs, dtype=np.float64)
        self._enc_rel_cmd = self._base_rel.copy()
        c.communicator.set_data_to_send(self._build_stream(c, self._hold_abs))
        c.communicator.start()
        time.sleep(0.15)

        exp = total_reply_bytes(self._n_motors)
        t0 = time.perf_counter()
        saw = False
        while time.perf_counter() - t0 < 2.0:
            c.communicator.set_data_to_send(self._build_stream(c, self._hold_abs))
            if latest_telemetry(c, n_motors=self._n_motors) is not None:
                saw = True
            time.sleep(self._dt_log)
        self.get_logger().info(
            f"Telemetry OK (expect {exp} B Teensy frame)."
            if saw
            else "WARNING: no telemetry yet."
        )
        self.get_logger().info(
            f"Tension t_ff={self._t_ff.tolist()} Nm @ hold_abs "
            f"(home+base_rel)={self._hold_abs.tolist()}"
        )

        self._connected = True
        self._t0 = time.perf_counter()
        self.get_logger().info(
            f"Hold {self._hold_s:g} s: first {self._imu_cal_s:g} s = IMU mount align "
            f"(OptiTrack+IMU → R_imu_in_rb; then RB-align → IMU3_aligned for NN), "
            f"then history fill → track. CSV → {self._csv_path}"
        )

    @staticmethod
    def _parse_optitrack_bodies(data: np.ndarray):
        n = len(data)
        if n >= 9 and (n - 1) % 8 == 0:
            n_bodies = (n - 1) // 8
            flat = data[: 8 * n_bodies]
        elif n >= 8 and n % 8 == 0:
            n_bodies = n // 8
            flat = data
        else:
            return None
        return n_bodies, flat.reshape(n_bodies, 8)

    def _on_optitrack(self, msg) -> None:
        self._latest_ot_flat = list(msg.data)
        parsed = self._parse_optitrack_bodies(np.array(msg.data, dtype=np.float64))
        if parsed is None:
            return
        n_bodies, bodies = parsed
        if n_bodies < 2:
            return
        if not self._opti_roles_locked:
            try:
                n_roles = role_count_for_bodies(n_bodies, max_roles=N_RB)
                self._ot_ids = lock_roles_by_y_sort(bodies, n_roles=n_roles)
                self._opti_roles_locked = True
                self.get_logger().info(
                    f"OptiTrack roles locked ({base_tip_layout_label(n_roles)}): "
                    + ", ".join(f"RB{i+1}←{tid}" for i, tid in enumerate(self._ot_ids))
                )
            except ValueError:
                return
        if self._ot_ids is None:
            return
        by_id = {int(round(float(r[0]))): r for r in bodies}
        if self._ot_ids[0] not in by_id:
            return
        base = by_id[self._ot_ids[0]]
        # World quats (wxyz) for mount calib + ideal→RB1 (same frame as NN train CSV)
        self._quat_rb_w.fill(np.nan)
        for i, tid in enumerate(self._ot_ids):
            if tid not in by_id:
                continue
            r = by_id[tid]
            # body layout: id, x,y,z, qx,qy,qz,qw
            self._quat_rb_w[i] = _normalize_quat_wxyz(
                np.array([r[7], r[4], r[5], r[6]], dtype=np.float64)
            )[0]
        if np.all(np.isfinite(self._quat_rb_w[0])):
            self._quat_rb1_w = self._quat_rb_w[0].copy()
        R_inv = Rotation.from_quat(base[4:8]).inv()  # qx qy qz qw
        base_pos = base[1:4]
        self._pos_rb1.fill(np.nan)
        self._pos_rb1[0, :] = 0.0
        self._markers_xz.fill(np.nan)
        self._markers_xz[0, :] = 0.0
        for i, tid in enumerate(self._ot_ids):
            if tid not in by_id:
                continue
            pos = R_inv.apply(by_id[tid][1:4] - base_pos)
            self._pos_rb1[i, :] = pos
            self._markers_xz[i, 0] = pos[0]
            self._markers_xz[i, 1] = pos[2]
        self._opti_ready = True

    def _load_saved_imu_mount(self) -> dict[int, np.ndarray] | None:
        """Load workspace ``R_imu_in_rb.npz`` if present (same file as NN training)."""
        path = self._imu_mount_npz
        if not path.is_file():
            return None
        try:
            with np.load(path) as f:
                out: dict[int, np.ndarray] = {}
                for imu_i in range(1, N_IMU + 1):
                    key = f"R_imu{imu_i}"
                    if key in f.files:
                        out[imu_i] = np.asarray(f[key], dtype=np.float64).reshape(3, 3)
            return out if out else None
        except Exception as exc:
            self.get_logger().warning(f"Could not load IMU mount {path}: {exc}")
            return None

    def _finalize_imu_mount_calib(self) -> None:
        """Estimate R_imu_in_rb from hold buffer (or fall back to saved .npz)."""
        min_n = max(1, self._imu_cal_min)
        saved = self._load_saved_imu_mount()
        if len(self._calib_imu_buf) >= min_n:
            imu_w = np.stack(self._calib_imu_buf, axis=0)
            quat_rb = np.stack(self._calib_rb_buf, axis=0)
            self._R_imu_in_rb = _estimate_R_imu_in_rb(quat_rb, imu_w)
            self._imu_mount_ready = True
            self._imu_mount_fallback = False
            for imu_i, R in sorted(self._R_imu_in_rb.items()):
                tr = float(np.trace(R))
                ang = float(np.degrees(np.arccos(np.clip((tr - 1.0) * 0.5, -1.0, 1.0))))
                rb = IMU_ON_RB.get(imu_i, -1)
                self.get_logger().info(
                    f"IMU mount ready (live): IMU{imu_i}→RB{rb}  |R−I|≈{ang:.2f} deg  "
                    f"n={imu_w.shape[0]}  → RB-align then IMU3_aligned for NN"
                )
        elif saved is not None:
            self._R_imu_in_rb = saved
            self._imu_mount_ready = True
            self._imu_mount_fallback = False
            self.get_logger().warning(
                f"IMU mount calib: only {len(self._calib_imu_buf)} live samples "
                f"(need ≥{min_n}) — using saved {self._imu_mount_npz.name}"
            )
        else:
            self._imu_mount_fallback = True
            self._imu_mount_ready = True
            self._R_imu_in_rb = None
            self.get_logger().warning(
                f"IMU mount calib: only {len(self._calib_imu_buf)} samples "
                f"(need ≥{min_n}) and no saved mount — falling back to "
                f"IMU3-relative without RB-align (not NN-matched)."
            )
        self._calib_imu_buf.clear()
        self._calib_rb_buf.clear()

    def _align_imu_for_nn(self, imu_quat_raw: np.ndarray) -> np.ndarray:
        """
        Match NN training ``rb_align_then_imu3_base``:

          IMU_raw → R_ideal = R_raw @ R_imu_in_rbᵀ  → under IMU3_aligned
          (IMU3 → I; NN ``imu12`` uses IMU1+IMU2 only)
        """
        q_raw = _normalize_quat_wxyz(
            np.asarray(imu_quat_raw, dtype=np.float64).reshape(-1, 4)
        )
        if self._imu_mount_ready and self._R_imu_in_rb is not None:
            q_aligned = _ideal_imu_world_from_real(q_raw, self._R_imu_in_rb)
            return _imu_in_base_frame(q_aligned)
        return _imu_in_base_frame(q_raw)

    # -------------------------------------------------------------- state / NN
    def _pack_optitrack_x(self) -> np.ndarray | None:
        """Option-e xz pack: global pF RB2–5 + local pB (= same for one-seg)."""
        if not self._opti_ready or not np.all(np.isfinite(self._markers_xz[1:])):
            return None
        g = []
        for rb in range(1, N_RB):  # RB2..RB5 → rows 1..4
            g.extend([float(self._markers_xz[rb, 0]), float(self._markers_xz[rb, 1])])
        # dual: local = global on one-seg
        x = np.asarray(g + g, dtype=np.float64)
        if x.size != self._nx:
            # pad / trim to model nx
            out = np.zeros(self._nx, dtype=np.float64)
            n = min(self._nx, x.size)
            out[:n] = x[:n]
            return out
        return x

    def _build_nn_input_row(
        self,
        enc_rel: np.ndarray,
        trq: np.ndarray,
        imu_quat: np.ndarray,
        target_enc_rel: np.ndarray,
        kappa: np.ndarray,
    ) -> np.ndarray:
        """Match NN config use_trq / imu / cmd packing (locked: imu12)."""
        cfg = self._nn_cfg or {}
        use_trq = bool(cfg.get("use_trq", True))
        imu = str(cfg.get("imu", "imu12")).lower()
        cmd = str(cfg.get("cmd", "none")).lower()
        blocks = [np.asarray(enc_rel, dtype=np.float64).reshape(-1)]
        if use_trq:
            blocks.append(np.asarray(trq, dtype=np.float64).reshape(-1))
        if imu != "none":
            q = self._align_imu_for_nn(imu_quat)
            n_imu = 2 if imu in ("imu12", "imu1234") else 3
            for i in range(n_imu):
                blocks.append(q[i])
        if cmd != "none":
            blocks.append(np.asarray(kappa, dtype=np.float64).reshape(-1)[:2])
            if cmd == "u":
                blocks.append(np.asarray(target_enc_rel, dtype=np.float64).reshape(-1))
            else:
                blocks.append(
                    np.asarray(target_enc_rel, dtype=np.float64).reshape(-1)
                    - np.asarray(enc_rel, dtype=np.float64).reshape(-1)
                )
        row = np.concatenate(blocks).astype(np.float32)
        in_dim = int(cfg.get("in_dim", row.size))
        if row.size != in_dim:
            raise RuntimeError(
                f"NN input dim {row.size} != config in_dim {in_dim} "
                f"(use_trq={use_trq} imu={imu} cmd={cmd})"
            )
        return row

    def _nn_hist_fill_seq(self, out: np.ndarray, need: int) -> None:
        """Write last ``need`` rows into ``out`` (need, in_dim) in time order."""
        buf = self._nn_hist_buf
        if buf is None:
            out[:] = np.stack(self._nn_input_history[-need:], axis=0)
            return
        end = self._nn_hist_i
        cap = self._nn_hist_cap
        idxs = np.arange(end - need, end) % cap
        out[:] = buf[idxs]

    def _nn_predict_x(self) -> np.ndarray | None:
        if self._nn is None or self._nn_x_mean is None or self._nn_xt is None:
            return None
        torch = self._torch
        xm = self._nn_x_mean_f32
        xs = self._nn_x_std_f32
        ym = self._nn_y_mean
        ys = self._nn_y_std
        cpu = self._nn_xt.device.type == "cpu"

        # ---- LSTM stateful 1-step (fast path) ----
        if self._nn_arch == "lstm" and self._lstm_stateful:
            need = self._seq_len
            if not self._nn_hist_ready(need):
                return None
            xt1 = self._nn_xt_step
            row = self._nn_row_work
            assert xt1 is not None and row is not None
            with torch.inference_mode():
                if not self._nn_lstm_bootstrapped:
                    # One full window to match training truncation; seed hc.
                    work = self._nn_seq_work
                    assert work is not None
                    self._nn_hist_fill_seq(work, need)
                    np.subtract(work, xm, out=work)
                    np.divide(work, xs, out=work)
                    xt = self._nn_xt
                    if cpu:
                        xt[0].numpy()[:] = work
                    else:
                        xt[0].copy_(torch.from_numpy(work))
                    y, hc = self._nn(xt)
                    self._nn_hc = hc
                    self._nn_lstm_bootstrapped = True
                    yh = y[0, -1].detach()
                else:
                    # Only the newest frame + carried (h,c) ≈ 0.2 ms
                    self._nn_hist_fill_seq(row.reshape(1, -1), 1)
                    np.subtract(row, xm, out=row)
                    np.divide(row, xs, out=row)
                    if cpu:
                        xt1[0, 0].numpy()[:] = row
                    else:
                        xt1[0, 0].copy_(torch.from_numpy(row))
                    y, self._nn_hc = self._nn(xt1, self._nn_hc)
                    yh = y[0, 0].detach()
                if not cpu:
                    yh = yh.cpu()
                np.copyto(self._nn_y_buf, yh.numpy())
            return self._nn_y_buf * ys + ym

        # ---- MLP or full-seq LSTM ----
        need = self._seq_len if self._nn_arch == "lstm" else 1
        if not self._nn_hist_ready(need):
            return None
        xt = self._nn_xt
        with torch.inference_mode():
            if self._nn_arch == "lstm":
                work = self._nn_seq_work
                assert work is not None
                self._nn_hist_fill_seq(work, need)
                np.subtract(work, xm, out=work)
                np.divide(work, xs, out=work)
                if cpu:
                    xt[0].numpy()[:] = work
                else:
                    xt[0].copy_(torch.from_numpy(work))
                y = self._nn(xt)
                if isinstance(y, (tuple, list)):
                    y = y[0]
                yh = y[0, -1].detach()
                if not cpu:
                    yh = yh.cpu()
                np.copyto(self._nn_y_buf, yh.numpy())
            else:
                work1 = self._nn_row_work
                assert work1 is not None
                self._nn_hist_fill_seq(work1.reshape(1, -1), 1)
                np.subtract(work1, xm, out=work1)
                np.divide(work1, xs, out=work1)
                if cpu:
                    xt[0].numpy()[:] = work1
                else:
                    xt[0].copy_(torch.from_numpy(work1))
                y = self._nn(xt)
                if isinstance(y, (tuple, list)):
                    y = y[0]
                yh = y[0].detach()
                if not cpu:
                    yh = yh.cpu()
                np.copyto(self._nn_y_buf, yh.numpy())
        return self._nn_y_buf * ys + ym

    def _normalize_x(self, x: np.ndarray) -> np.ndarray:
        return (np.asarray(x, dtype=np.float64) - self._x_mean) / self._x_std

    def _denorm_x(self, xn: np.ndarray) -> np.ndarray:
        return np.asarray(xn, dtype=np.float64) * self._x_std + self._x_mean

    def _build_delay_vector(self) -> np.ndarray | None:
        """z = [x(k), x(k-1), …, x(k-d)] in normalized coordinates."""
        need = self._delay + 1
        if len(self._state_history) < need:
            return None
        z = self._z_buf
        nx = self._nx
        if z is None or z.size != need * nx:
            return np.concatenate(self._state_history[-need:][::-1])
        # newest first into contiguous buffer
        for i in range(need):
            z[i * nx : (i + 1) * nx] = self._state_history[-(i + 1)]
        return z

    def _get_ref_window(self) -> np.ndarray:
        """(N, n_tip) tip reference in *normalized* tip channels."""
        assert self._ref_traj is not None and self._mpc is not None
        T = self._ref_traj.shape[0]
        n_tip = len(self._tip_idxs)
        ref_phys = self._ref_phys_buf
        ref_n = self._ref_n_buf
        if ref_phys is None or ref_n is None:
            idx = np.clip(
                np.arange(self._ref_idx, self._ref_idx + self._horizon), 0, T - 1
            )
            tip = self._ref_traj[idx]
            ref_phys = np.zeros((self._horizon, n_tip), dtype=np.float64)
            for j in range(n_tip):
                ref_phys[:, j] = tip[:, j % 2]
            ref_n = np.empty_like(ref_phys)
            for j, col in enumerate(self._tip_idxs):
                ref_n[:, j] = (ref_phys[:, j] - self._x_mean[col]) / self._x_std[col]
            return ref_n
        i0 = self._ref_idx
        for k in range(self._horizon):
            i = i0 + k
            if i >= T:
                i = T - 1
            tip = self._ref_traj[i]
            for j in range(n_tip):
                ref_phys[k, j] = tip[j % 2]
        for j, col in enumerate(self._tip_idxs):
            ref_n[:, j] = (ref_phys[:, j] - self._x_mean[col]) / self._x_std[col]
        return ref_n

    def _apply_delta_u(self, du_phys: np.ndarray) -> None:
        """
        Apply Koopman Δenc, then enforce the **same** κ→enc pipeline as
        ``random_data_collection``:

          enc_try = enc + Δu
          (κ1, κ2) = lstsq(enc_try)     # read current bend
          clip |κ| ≤ KAPPA_LIMIT        # only limit (same as data collection)
          target = target_abs_enc_from_kappa(κ, home, slack)

        No separate enc-rad limit — enc is whatever κ maps to.
        """
        du = np.asarray(du_phys, dtype=np.float64).reshape(-1)
        if du.size != self._n_motors:
            return
        enc_try = self._enc_rel_cmd + du
        k1, k2 = kappa_from_rel_enc(enc_try, self._pcc, kappa_limit=1e6)
        lim = float(self._kappa_limit)
        k1 = float(np.clip(k1, -lim, lim))
        k2 = float(np.clip(k2, -lim, lim))
        self._kappa_cmd[:] = (k1, k2)
        # identical mapping to data collection
        self._target_abs = target_abs_enc_from_kappa(
            k1, k2, self._abs_home, self._pcc, self._slack_scale
        )
        lo, hi = self._ctrl.minAngles, self._ctrl.maxAngles
        self._target_abs = np.clip(self._target_abs, lo, hi)
        self._enc_rel_cmd = self._target_abs - self._abs_home

    # ------------------------------------------------------------------ tick
    def _tick(self) -> None:
        if self._shutdown_done or not self._connected:
            return
        c = self._ctrl
        c.communicator.set_data_to_send(self._build_stream(c, self._target_abs))
        frame = latest_telemetry(c, n_motors=self._n_motors)

        angles = (
            np.asarray(frame.angles_rad, dtype=np.float64)
            if frame is not None
            else None
        )
        torques = (
            np.asarray(frame.torques_nm, dtype=np.float64)
            if frame is not None
            else np.full(self._n_motors, np.nan)
        )
        quats = (
            np.asarray(frame.quaternions, dtype=np.float64)
            if frame is not None
            else np.tile([1.0, 0.0, 0.0, 0.0], (N_IMU, 1))
        )

        now = time.perf_counter()
        t0 = self._t0 if self._t0 is not None else now
        t_s = now - t0
        do_ctrl = (self._tick_count % self._ctrl_stride) == 0
        u_delta = np.zeros(self._n_motors, dtype=np.float64)

        if angles is not None and not self._cmd_initialized:
            # Sync measured enc once for logging; hold phase still commands hold_abs.
            try:
                k1, k2 = kappa_from_rel_enc(
                    angles - self._abs_home, self._pcc, kappa_limit=self._kappa_limit
                )
                self._kappa_cmd[:] = (k1, k2)
            except Exception:
                pass
            self._cmd_initialized = True

        # Hold phase — force home+base_rel + t_ff; first IMU_CALIBRATION_S = mount align
        if t_s < self._hold_s:
            self._tracking = False
            self._target_abs = self._hold_abs.copy()
            self._enc_rel_cmd = self._base_rel.copy()
        else:
            if not self._hold_done_logged:
                self.get_logger().info(
                    f"Hold complete ({self._hold_s:g} s) — starting tip tracking"
                )
                self._hold_done_logged = True
            self._tracking = True

        # Collect OptiTrack+IMU for mount calib during first IMU_CALIBRATION_S of hold
        if not self._imu_mount_ready and t_s < self._imu_cal_s and self._opti_ready:
            need_rbs = {1, *IMU_ON_RB.values()}
            rb_ok = all(
                rb <= N_RB and np.all(np.isfinite(self._quat_rb_w[rb - 1]))
                for rb in need_rbs
            )
            imu_ok = (
                angles is not None
                and np.asarray(quats).size >= N_IMU * 4
                and np.all(np.isfinite(np.asarray(quats).reshape(-1, 4)[:N_IMU]))
            )
            if rb_ok and imu_ok:
                self._calib_imu_buf.append(
                    _normalize_quat_wxyz(np.asarray(quats).reshape(-1, 4)[:N_IMU]).copy()
                )
                self._calib_rb_buf.append(self._quat_rb_w.copy())
        if not self._imu_mount_ready and t_s >= self._imu_cal_s:
            self._finalize_imu_mount_calib()

        enc_rel_meas = (
            angles - self._abs_home
            if angles is not None
            else self._enc_rel_cmd.copy()
        )
        target_enc_rel = self._enc_rel_cmd.copy()

        # NN input history only after mount calib window (aligned IMU matches training)
        if self._state_source == "nn" and angles is not None and self._imu_mount_ready:
            try:
                row = self._build_nn_input_row(
                    enc_rel_meas, torques, quats, target_enc_rel, self._kappa_cmd
                )
                self._nn_hist_push(row)
            except Exception as exc:
                if self._tick_count % 400 == 0:
                    self.get_logger().warn(f"NN input build failed: {exc}")

        # Control-rate state update + MPC
        if do_ctrl and angles is not None:
            x_phys = None
            if self._state_source == "nn":
                x_phys = self._nn_predict_x()
            else:
                x_phys = self._pack_optitrack_x()

            if x_phys is not None and x_phys.size == self._nx:
                self._pred_x = x_phys.copy()
                tip_phys = x_phys[self._tip_idxs]
                # predicted tip (pF_RB5 = first two tip channels)
                self._pred_tip = np.array(
                    [tip_phys[0], tip_phys[1]], dtype=np.float64
                )
                xn = self._normalize_x(x_phys)
                self._state_history.append(xn)
                need = self._delay + 1
                if len(self._state_history) > need + 20:
                    self._state_history = self._state_history[-(need + 20) :]

                z = self._build_delay_vector()
                if (
                    self._tracking
                    and z is not None
                    and self._mpc is not None
                    and not self._done
                ):
                    ref = self._get_ref_window()
                    U = self._mpc.solve(z, ref)
                    if U is not None:
                        u0_n = U[0]
                        u0 = u0_n * self._u_std + self._u_mean
                        u0 = np.clip(u0, -self._delta_u_max, self._delta_u_max)
                        u_delta = u0
                        self._apply_delta_u(u0)
                    self._ref_idx += 1
                    if self._ref_idx >= (
                        self._ref_traj.shape[0] if self._ref_traj is not None else 0
                    ):
                        self._done = True
                        self.get_logger().info(
                            "Reference finished — ramping home + soft-release, then exit"
                        )
                self._ctrl_tick += 1

        # Publish /motor + error
        self._publish_motor(angles, torques, quats)
        x_tar, z_tar = (
            (float(self._ref_traj[min(self._ref_idx, len(self._ref_traj) - 1), 0]),
             float(self._ref_traj[min(self._ref_idx, len(self._ref_traj) - 1), 1]))
            if self._ref_traj is not None and self._tracking
            else (0.0, 0.0)
        )
        tip_i = tip_role_index(len(self._ot_ids)) if self._ot_ids else N_RB - 1
        ot_tip = (
            self._markers_xz[tip_i]
            if self._opti_ready and np.all(np.isfinite(self._markers_xz[tip_i]))
            else self._nan_tip
        )
        # Throttle /mpc_error — full state already on /motor @ 400 Hz
        if (self._tick_count % self._publish_err_every) == 0:
            d = self._err_msg.data
            d[0] = float(x_tar)
            d[1] = float(z_tar)
            d[2] = float(self._pred_tip[0])
            d[3] = float(self._pred_tip[1])
            d[4] = float(ot_tip[0])
            d[5] = float(ot_tip[1])
            self._err_pub.publish(self._err_msg)

        self._log_row(
            t_s=t_s,
            x_tar=x_tar,
            z_tar=z_tar,
            ot_tip=ot_tip,
            angles=angles,
            torques=torques,
            u_delta=u_delta,
            quats=quats,
        )

        # Console: low rate while tracking (ROS log I/O is a jitter source)
        do_console = False
        if self._tracking or self._done:
            do_console = (self._tick_count % self._log_every) == 0
        else:
            do_console = (self._tick_count % self._log_every_hold) == 0
        if do_console and not self._done:
            phase = "HOLD" if not self._tracking else "TRACK"
            self.get_logger().info(
                f"[{phase}] t={t_s:6.2f}s  "
                f"ref=({x_tar:+.4f},{z_tar:+.4f})  "
                f"pred=({self._pred_tip[0]:+.4f},{self._pred_tip[1]:+.4f})  "
                f"ot=({float(ot_tip[0]):+.4f},{float(ot_tip[1]):+.4f})  "
                f"κ=({self._kappa_cmd[0]:+.3f},{self._kappa_cmd[1]:+.3f})"
            )
        self._tick_count += 1

        # Tip ref exhausted → home + soft-release + stop node (ends launch)
        if self._done and not self._shutdown_done:
            self.soft_shutdown(return_home=True)
            if rclpy.ok():
                rclpy.shutdown()
            return

    def _publish_motor(self, angles, torques, quats) -> None:
        row = self._motor_msg.data
        for m in range(self._n_motors):
            row[IDX_TARGET + m] = float(self._target_abs[m])
        if angles is not None:
            for m in range(self._n_motors):
                row[IDX_REAL + m] = float(angles[m])
                row[IDX_TRQ + m] = (
                    float(torques[m]) if torques is not None else float("nan")
                )
        else:
            for m in range(self._n_motors):
                row[IDX_REAL + m] = float("nan")
                row[IDX_TRQ + m] = float("nan")
        row[IDX_KAPPA1] = float(self._kappa_cmd[0])
        row[IDX_KAPPA2] = float(self._kappa_cmd[1])
        q = np.asarray(quats, dtype=np.float64).reshape(N_IMU, 4)
        for imu in range(N_IMU):
            base = IDX_QUAT + imu * 4
            row[base] = float(q[imu, 0])
            row[base + 1] = float(q[imu, 1])
            row[base + 2] = float(q[imu, 2])
            row[base + 3] = float(q[imu, 3])
        row[IDX_SEQ_TIME] = float(self._tick_count) * self._dt_log
        self._motor_pub.publish(self._motor_msg)

    def _log_row(
        self,
        *,
        t_s: float,
        x_tar: float,
        z_tar: float,
        ot_tip: np.ndarray,
        angles,
        torques,
        u_delta: np.ndarray,
        quats=None,
    ) -> None:
        pred_tip = self._pred_tip
        # Always log the tip used as MPC state (_pred_tip): NN ŷ for handles 1–2,
        # OptiTrack-packed tip for handle 3.
        px, pz = float(pred_tip[0]), float(pred_tip[1])
        row = [
            float(t_s),
            int(self._handle),
            int(self._tracking),
            float(x_tar),
            float(z_tar),
            px,
            pz,
            float(ot_tip[0]),
            float(ot_tip[1]),
            float(px - x_tar) if np.isfinite(px) else float("nan"),
            float(pz - z_tar) if np.isfinite(pz) else float("nan"),
            float(ot_tip[0] - x_tar) if np.isfinite(ot_tip[0]) else float("nan"),
            float(ot_tip[1] - z_tar) if np.isfinite(ot_tip[1]) else float("nan"),
            float(self._kappa_cmd[0]),
            float(self._kappa_cmd[1]),
        ]
        for m in range(self._n_motors):
            row.append(float(self._target_abs[m]))
        for m in range(self._n_motors):
            row.append(float(angles[m]) if angles is not None else float("nan"))
        for m in range(self._n_motors):
            row.append(float(self._enc_rel_cmd[m]))
        for m in range(self._n_motors):
            row.append(float(torques[m]) if torques is not None else float("nan"))
        for m in range(self._n_motors):
            row.append(float(u_delta[m]))
        # Raw IMU quats (wxyz) — skip renormalize on log path (saved ~0.1 ms/tick)
        q = None
        if quats is not None:
            q = np.asarray(quats, dtype=np.float64).reshape(-1, 4)
        for i in range(N_IMU):
            if q is not None and i < q.shape[0] and np.all(np.isfinite(q[i])):
                row.extend([float(q[i, 0]), float(q[i, 1]), float(q[i, 2]), float(q[i, 3])])
            else:
                row.extend([float("nan")] * 4)
        for rb in range(N_RB):
            if np.all(np.isfinite(self._pos_rb1[rb])):
                row.extend(
                    [
                        float(self._pos_rb1[rb, 0]),
                        float(self._pos_rb1[rb, 1]),
                        float(self._pos_rb1[rb, 2]),
                    ]
                )
            else:
                row.extend([float("nan")] * 3)
        if self._pred_x is not None:
            for i in range(self._nx):
                row.append(float(self._pred_x[i]))
        else:
            row.extend([float("nan")] * self._nx)

        # Fast path: publish packed row to mpc_log_recorder (no disk I/O here)
        d = self._log_msg.data
        n = len(row)
        if len(d) != n:
            self._log_msg.data = [0.0] * n
            d = self._log_msg.data
        for i in range(n):
            d[i] = float(row[i])
        self._log_pub.publish(self._log_msg)

        # Optional in-node CSV (debug) — prefer external recorder
        if self._write_local_csv and self._csv_writer is not None:
            self._csv_row_buf.append(row)
            if len(self._csv_row_buf) >= self._csv_flush_every:
                self._csv_writer.writerows(self._csv_row_buf)
                self._csv_row_buf.clear()
                self._csv_file.flush()

    def soft_shutdown(self, *, return_home: bool = True) -> None:
        """
        Stop control timer, close CSV, then either:
          return_home=True  — ramp to hold_abs (home+base_rel) + soft-release t_ff (planned end)
          return_home=False — soft-release at last command only (Ctrl+C abort)
        """
        if self._shutdown_done:
            return
        self._shutdown_done = True
        self._tracking = False
        try:
            self._timer.cancel()
        except Exception:
            pass
        self._close_csv()
        c = self._ctrl
        if c is None or not self._connected:
            return
        try:
            if return_home:
                home = np.asarray(self._hold_abs, dtype=np.float64)
                self.get_logger().info(
                    f"Returning home ({float(type(self).RETURN_HOME_DURATION_S):.1f} s) "
                    "+ soft-release..."
                )
                go_home(
                    c,
                    home,
                    t_ff=self._t_ff,
                    v_set=self._v_set,
                    kp=self._operation_kp,
                    kd=self._operation_kd,
                    duration_s=float(type(self).RETURN_HOME_DURATION_S),
                    com_freq_hz=self._log_hz,
                )
            else:
                self.get_logger().info(
                    f"Soft-release at current pose "
                    f"({float(type(self).SHUTDOWN_T_FF_RAMP_S):.1f} s)..."
                )
                ramp_t_ff_to_zero(
                    c,
                    self._target_abs,
                    t_ff_start=self._t_ff,
                    duration_s=float(type(self).SHUTDOWN_T_FF_RAMP_S),
                    com_freq_hz=self._log_hz,
                    build_stream=lambda ctrl, pos, t_ff=None: self._build_stream(
                        ctrl, pos, t_ff=t_ff
                    ),
                )
        except Exception as exc:
            self.get_logger().warning(f"Shutdown motion failed: {exc}")
        try:
            c.communicator.running = False
        except Exception:
            pass
        time.sleep(0.2)
        try:
            c.StopMotors()
            c.communicator.stop()
        except Exception:
            pass
        self._connected = False
        self.get_logger().info(f"Shutdown complete. Log: {self._csv_path}")


def main(args=None) -> None:
    # =========================================================================
    # Tunables — THIS is what ros2 launch / -m mpc_tip_control uses
    # (class CONTROL_HANDLE above is overwritten by the line below)
    # =========================================================================
    CONTROL_HANDLE = 2  # 1 LSTM@400 | 2 MLP@400 | 3 OptiTrack@100
    # Handle 1–2: CSV x_pred_tip = NN tip.  Handle 3: CSV x_pred_tip = OT-packed
    # tip state used by MPC (same tip as OT RB5 in RB1 for option-e xz).

    COM_PORT = "/dev/ttyACM0"
    HOLD_S = 15.0  # total hold; first IMU_CALIBRATION_S (5 s) = mount align
    # RT: stateful LSTM 1-step (~0.2 ms) + OSQP; warmup at node start
    NN_DEVICE = "cpu"
    TORCH_NUM_THREADS = 2
    LSTM_STATEFUL = True  # False → full seq100 every tick (~1.5 ms)
    COMPUTE_WARMUP_ITERS = 80
    MPC_HORIZON = [20, 10]  # [400 Hz, 100 Hz]
    MPC_Q_TIP = [4.0, 4.0, 4.0, 4.0]  # pF_RB5_x/z, pB_RB5_x/z
    MPC_R_DIAG = [1.0, 1.0, 1.0]  # Δenc penalty
    DELTA_U_MAX = 0.005
    KAPPA_LIMIT = 7.5  # only actuation limit; same as random_data_collection
    REF_CSV = str(WS_ROOT / "mpc_ref" / "tip_ref.csv")  # RB1 (x,z) from Fig.5
    LOG_DIR = str(WS_ROOT)
    # =========================================================================

    MPCTipControlNode.CONTROL_HANDLE = int(CONTROL_HANDLE)
    MPCTipControlNode.COM_PORT = str(COM_PORT)
    MPCTipControlNode.HOLD_S = float(HOLD_S)
    MPCTipControlNode.NN_DEVICE = str(NN_DEVICE)
    MPCTipControlNode.TORCH_NUM_THREADS = int(TORCH_NUM_THREADS)
    MPCTipControlNode.LSTM_STATEFUL = bool(LSTM_STATEFUL)
    MPCTipControlNode.COMPUTE_WARMUP_ITERS = int(COMPUTE_WARMUP_ITERS)
    MPCTipControlNode.MPC_HORIZON = list(MPC_HORIZON)
    MPCTipControlNode.MPC_Q_TIP = list(MPC_Q_TIP)
    MPCTipControlNode.MPC_R_DIAG = list(MPC_R_DIAG)
    MPCTipControlNode.DELTA_U_MAX = float(DELTA_U_MAX)
    MPCTipControlNode.KAPPA_LIMIT = float(KAPPA_LIMIT)
    MPCTipControlNode.REF_CSV = str(REF_CSV)
    MPCTipControlNode.LOG_DIR = str(LOG_DIR)

    rclpy.init(args=args)
    node = MPCTipControlNode()

    def _sig(_signum, _frame):
        node.get_logger().info("Signal — soft shutdown")
        node.soft_shutdown(return_home=False)
        if rclpy.ok():
            rclpy.shutdown()

    signal.signal(signal.SIGINT, _sig)
    signal.signal(signal.SIGTERM, _sig)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.soft_shutdown(return_home=True)
        try:
            node.destroy_node()
        except Exception:
            pass
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
