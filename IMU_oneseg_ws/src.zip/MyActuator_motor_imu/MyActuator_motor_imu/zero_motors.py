"""
Keyboard zeroing — one-seg PCC κ teleop (3 motors)
==================================================

Startup (no snap to a prior home file)::

  1. Passive stream (kp=kd=t_ff=0) until current encoders arrive
  2. Hold that measured pose, then soft-ramp cable tension (t_ff)
  3. κ=0 for the session = that measured pose

Tune with keyboard κ until the desired home shape, then Enter to save::

  /root/DataCollection/IMU_oneseg_ws/home_position_saved.txt

Uses ``ICRA-OneSeg-pkg``::

  κ → rel_enc (PCC) → abs_target = abs_home + rel_enc

Controls (Windows + Linux):
    ↑ / ↓     κ₁
    → / ←     κ₂
    R         reset κ → 0 (return to session start pose)
    Enter     save current measured encoders as home
    X         soft-release t_ff and quit without saving
    Ctrl+C    same as X

Run (from workspace or this folder)::

  python src/MyActuator_motor_imu/MyActuator_motor_imu/zero_motors.py
"""

from __future__ import annotations

import ctypes
import sys
import time
from pathlib import Path

import numpy as np

if sys.platform != "win32":
    import select
    import termios
    import tty

# =============================================================================
# USER SETTINGS
# =============================================================================

COM_PORT = "/dev/ttyACM0" if sys.platform != "win32" else "COM4"
SERIAL_BAUD = 2_000_000
COM_FREQ_HZ = 400

KAPPA_RATE_PER_S = 2.0
KAPPA_LIMIT = 8.0
SLACK_SCALE = 1.0

OPERATION_KP = 10.0
OPERATION_KD = 0.31
T_FF_NM = [1.0, 1.0, 1.0]
V_SET_RAD_S = [0.0, 0.0, 0.0]

TELEMETRY_WARMUP_S = 2.0
STARTUP_T_FF_RAMP_S = 2.0  # soft-ramp tension while holding measured pose
SHUTDOWN_T_FF_RAMP_S = 2.0
# Console status rate (control loop stays at COM_FREQ_HZ). Shows all 3 IMUs.
PRINT_STATUS_HZ = 10.0

HOME_FILE = None  # None → <IMU_oneseg_ws>/home_position_saved.txt
HOME_NOTES = "ICRA-OneSeg — κ-teleop aligned home (3 motors)"

MOTOR_IDS = [0x10, 0x11, 0x12]

# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
ICRA_PKG_DIR = SCRIPT_DIR / "ICRA-OneSeg-pkg"
if not (ICRA_PKG_DIR / "icra_oneseg").is_dir():
    raise ModuleNotFoundError(
        f"ICRA-OneSeg-pkg not found at {ICRA_PKG_DIR}\n"
        "Expected: …/MyActuator_motor_imu/ICRA-OneSeg-pkg/icra_oneseg/"
    )
if str(ICRA_PKG_DIR) not in sys.path:
    sys.path.insert(0, str(ICRA_PKG_DIR))

from icra_oneseg.RobstrideMotorMessagesClass import MotorMessages  # noqa: E402
from icra_oneseg.home_position_io import (  # noqa: E402
    default_home_position_path,
    find_workspace_root,
    save_home_positions_rad,
)
from icra_oneseg.pcc_kinematics import (  # noqa: E402
    PCCParameters,
    target_abs_enc_from_kappa,
)
from icra_oneseg.rs05_drive_tuning import apply_drive_tuning  # noqa: E402
from icra_oneseg.soft_t_ff_release import (  # noqa: E402
    ramp_t_ff_from_zero,
    ramp_t_ff_to_zero,
)
from icra_oneseg.stack import (  # noqa: E402
    TIP_IMU_INDEX,
    build_ocm_stream,
    configure_imu_telemetry,
    latest_telemetry,
)

pi = np.pi
NUM_MOTORS = len(MOTOR_IDS)
_t_ff = np.asarray(T_FF_NM, dtype=float).reshape(-1)
_v_set = np.asarray(V_SET_RAD_S, dtype=float).reshape(-1)
_PCC = PCCParameters()

_IMU_LABELS = ("IMU1_tip", "IMU2_mid", "IMU3_base")


def _format_all_imu_quats(frame) -> str:
    """Stream all 3 BNO085 quaternions (wxyz): tip / mid / base."""
    if frame is None:
        return " ".join(f"{lab}=[----]" for lab in _IMU_LABELS)
    q = np.asarray(frame.quaternions, dtype=np.float64).reshape(-1, 4)
    parts = []
    for i, lab in enumerate(_IMU_LABELS):
        if i >= q.shape[0]:
            parts.append(f"{lab}=[----]")
            continue
        row = q[i]
        parts.append(
            f"{lab}=({row[0]:+.3f},{row[1]:+.3f},{row[2]:+.3f},{row[3]:+.3f})"
        )
    return " ".join(parts)

_VK_LEFT, _VK_UP, _VK_RIGHT, _VK_DOWN = 0x25, 0x26, 0x27, 0x28
_VK_R, _VK_X, _VK_RETURN = 0x52, 0x58, 0x0D


class _WinKeyState:
    def __init__(self) -> None:
        self._u = ctypes.windll.user32
        self._prev_r = False
        self._prev_x = False
        self._prev_enter = False

    def _down(self, vk: int) -> bool:
        return bool(self._u.GetAsyncKeyState(vk) & 0x8000)

    def arrow_deltas(self, rate_per_s: float, dt_s: float) -> tuple[float, float]:
        scale = float(rate_per_s) * float(dt_s)
        dk1 = dk2 = 0.0
        if self._down(_VK_UP):
            dk1 -= scale
        if self._down(_VK_DOWN):
            dk1 += scale
        if self._down(_VK_RIGHT):
            dk2 += scale
        if self._down(_VK_LEFT):
            dk2 -= scale
        return dk1, dk2

    def reset_pressed(self) -> bool:
        now = self._down(_VK_R)
        edge = now and not self._prev_r
        self._prev_r = now
        return edge

    def quit_pressed(self) -> bool:
        now = self._down(_VK_X)
        edge = now and not self._prev_x
        self._prev_x = now
        return edge

    def enter_pressed(self) -> bool:
        now = self._down(_VK_RETURN)
        edge = now and not self._prev_enter
        self._prev_enter = now
        return edge

    def close(self) -> None:
        pass

    def flush(self) -> None:
        pass


class _LinuxKeyState:
    _HOLD_TIMEOUT_S = 0.15
    _ARROW_MAP = {
        "\x1b[A": "up",
        "\x1b[B": "down",
        "\x1b[C": "right",
        "\x1b[D": "left",
        "\x1bOA": "up",
        "\x1bOB": "down",
        "\x1bOC": "right",
        "\x1bOD": "left",
    }
    _OPPOSITE = {"up": "down", "down": "up", "left": "right", "right": "left"}

    def __init__(self) -> None:
        if not sys.stdin.isatty():
            raise SystemExit(
                "zero_motors.py needs a TTY for Linux keyboard teleop "
                "(run in an interactive terminal)."
            )
        self._fd = sys.stdin.fileno()
        self._old = termios.tcgetattr(self._fd)
        tty.setcbreak(self._fd)
        self._buf = ""
        self._held_until: dict[str, float] = {}
        self._edges: list[str] = []
        self.flush()

    def close(self) -> None:
        try:
            termios.tcsetattr(self._fd, termios.TCSADRAIN, self._old)
        except Exception:
            pass

    def flush(self) -> None:
        while True:
            r, _, _ = select.select([self._fd], [], [], 0.0)
            if not r:
                break
            if not sys.stdin.read(1):
                break
        self._buf = ""
        self._held_until.clear()
        self._edges.clear()

    def _mark_held(self, name: str) -> None:
        opp = self._OPPOSITE.get(name)
        if opp is not None:
            self._held_until.pop(opp, None)
        self._held_until[name] = time.perf_counter() + self._HOLD_TIMEOUT_S

    def _held(self, name: str) -> bool:
        until = self._held_until.get(name)
        return until is not None and time.perf_counter() <= until

    def _consume_escape(self) -> bool:
        if not self._buf or self._buf[0] != "\x1b":
            return True
        if len(self._buf) < 2:
            return False
        for seq, name in self._ARROW_MAP.items():
            if self._buf.startswith(seq):
                self._buf = self._buf[len(seq) :]
                self._mark_held(name)
                return True
        self._buf = self._buf[1:]
        return True

    def _drain(self) -> None:
        while True:
            r, _, _ = select.select([self._fd], [], [], 0.0)
            if not r:
                break
            ch = sys.stdin.read(1)
            if not ch:
                break
            self._buf += ch
        while self._buf:
            if self._buf[0] == "\x1b":
                if not self._consume_escape():
                    break
                continue
            c = self._buf[0]
            self._buf = self._buf[1:]
            if c in ("\r", "\n"):
                self._edges.append("enter")
            elif c.lower() == "r":
                self._edges.append("r")
            elif c.lower() in ("x", "q"):
                self._edges.append("quit")

    def arrow_deltas(self, rate_per_s: float, dt_s: float) -> tuple[float, float]:
        self._drain()
        scale = float(rate_per_s) * float(dt_s)
        dk1 = dk2 = 0.0
        if self._held("up"):
            dk1 -= scale
        if self._held("down"):
            dk1 += scale
        if self._held("right"):
            dk2 += scale
        if self._held("left"):
            dk2 -= scale
        return dk1, dk2

    def _pop_edge(self, name: str) -> bool:
        self._drain()
        if name in self._edges:
            idx = self._edges.index(name)
            del self._edges[idx]
            return True
        return False

    def reset_pressed(self) -> bool:
        return self._pop_edge("r")

    def quit_pressed(self) -> bool:
        return self._pop_edge("quit")

    def enter_pressed(self) -> bool:
        return self._pop_edge("enter")


def _make_key_state():
    if sys.platform == "win32":
        return _WinKeyState()
    return _LinuxKeyState()


def _build_stream(
    ctrl: MotorMessages,
    pos_rad: np.ndarray,
    *,
    t_ff=None,
    kp=None,
    kd=None,
):
    return build_ocm_stream(
        ctrl,
        pos_rad,
        t_ff=_t_ff if t_ff is None else t_ff,
        v_set=_v_set,
        kp=OPERATION_KP if kp is None else kp,
        kd=OPERATION_KD if kd is None else kd,
    )


def _enc_from_kappa(k1: float, k2: float, abs_home: np.ndarray) -> np.ndarray:
    lim = float(KAPPA_LIMIT)
    return target_abs_enc_from_kappa(
        float(np.clip(k1, -lim, lim)),
        float(np.clip(k2, -lim, lim)),
        abs_home,
        _PCC,
        SLACK_SCALE,
    )


def _wait_for_encoders(
    ctrl: MotorMessages,
    *,
    warmup_s: float,
    dt: float,
) -> np.ndarray | None:
    """Passive TX (kp=kd=t_ff=0) until valid encoder telemetry arrives."""
    t_ff_zero = np.zeros(NUM_MOTORS, dtype=np.float64)
    zeros = np.zeros(NUM_MOTORS, dtype=np.float64)
    ctrl.communicator.set_data_to_send(
        _build_stream(ctrl, zeros, t_ff=t_ff_zero, kp=0.0, kd=0.0)
    )
    if not ctrl.communicator.running:
        ctrl.communicator.start()
    print(
        f"  Warmup: passive stream, waiting up to {warmup_s:g} s for encoders..."
    )
    t0 = time.perf_counter()
    last_note = t0
    while (time.perf_counter() - t0) < float(warmup_s):
        frame = latest_telemetry(ctrl, n_motors=NUM_MOTORS)
        if frame is not None:
            enc = np.asarray(frame.angles_rad, dtype=np.float64)
            if enc.size == NUM_MOTORS and np.all(np.isfinite(enc)):
                print(f"  Telemetry OK after {time.perf_counter() - t0:.2f} s.")
                return enc
        now = time.perf_counter()
        if (now - last_note) >= 1.0:
            print(f"  … still waiting ({now - t0:.1f}/{warmup_s:g} s)")
            last_note = now
        ctrl.communicator.set_data_to_send(
            _build_stream(ctrl, zeros, t_ff=t_ff_zero, kp=0.0, kd=0.0)
        )
        time.sleep(dt)
    return None


def main() -> None:
    ws = find_workspace_root(SCRIPT_DIR)
    home_path = Path(HOME_FILE) if HOME_FILE else default_home_position_path(SCRIPT_DIR)
    dt = 1.0 / float(COM_FREQ_HZ)

    print("3-motor κ-teleop home capture (ICRA-OneSeg-pkg)")
    print(f"  kit={ICRA_PKG_DIR}")
    if ws is not None:
        print(f"  workspace={ws}")
    print(f"  COM={COM_PORT}  ctrl={COM_FREQ_HZ:g} Hz  status={PRINT_STATUS_HZ:g} Hz")
    print(f"  IMUs: tip=IMU{TIP_IMU_INDEX + 1}, mid=IMU2, base=IMU3 (all shown live)")
    print(f"  PCC L={_PCC.L_seg_mm} mm  r={_PCC.cable_offset_mm} mm  R={_PCC.R_pulley_mm} mm")
    print(f"  t_ff={_t_ff.tolist()} Nm  kp={OPERATION_KP}  kd={OPERATION_KD}")
    print(f"  Will save → {home_path}")
    print("  ↑↓ κ1 | ←→ κ2 | R reset | Enter save | X quit")

    keys = _make_key_state()
    ctrl = MotorMessages(
        ComsPort=COM_PORT,
        Coms_Freq=float(COM_FREQ_HZ),
        Motor_ids=MOTOR_IDS,
        InitialAnglesOffsets=[0.0] * NUM_MOTORS,
        minAngles=[-20 * pi] * NUM_MOTORS,
        maxAngles=[20 * pi] * NUM_MOTORS,
        MotorType="RS05",
        baudrate=int(SERIAL_BAUD),
        log_Coms_freq=False,
    )
    ctrl.communicator.verbose = False
    configure_imu_telemetry(ctrl, n_motors=NUM_MOTORS)

    kappa = np.zeros(2, dtype=np.float64)
    session_home = np.zeros(NUM_MOTORS, dtype=np.float64)
    hold = np.zeros(NUM_MOTORS, dtype=np.float64)
    saved: np.ndarray | None = None
    abort = False
    started = False

    try:
        ctrl.StopMotors()
        time.sleep(0.05)
        ctrl.SetControlMode("operation")
        ctrl.ApplyFirmwareVelocityHeadroom()
        apply_drive_tuning(ctrl)
        ctrl.StartMotors()
        time.sleep(0.1)

        t_ff_zero = np.zeros(NUM_MOTORS, dtype=np.float64)

        # 1) Passive read current encoders — never cmd zeros with real Kp/t_ff.
        current = _wait_for_encoders(ctrl, warmup_s=float(TELEMETRY_WARMUP_S), dt=dt)
        if current is None:
            raise SystemExit(
                f"ERROR: no telemetry after {TELEMETRY_WARMUP_S:g} s — "
                "check Teensy / USB."
            )

        # 2) Hold measured pose with t_ff still 0 (stiff position, no cable pull yet).
        hold = current.copy()
        ctrl.communicator.set_data_to_send(
            _build_stream(ctrl, hold, t_ff=t_ff_zero)
        )
        for _ in range(max(1, int(0.15 * float(COM_FREQ_HZ)))):
            frame = latest_telemetry(ctrl, n_motors=NUM_MOTORS)
            if frame is not None:
                hold = np.asarray(frame.angles_rad, dtype=np.float64)
                ctrl.communicator.set_data_to_send(
                    _build_stream(ctrl, hold, t_ff=t_ff_zero)
                )
            time.sleep(dt)
        print(
            "  Holding current pose "
            + "["
            + ", ".join(f"{v:+.3f}" for v in hold)
            + "]"
        )

        # 3) Soft-start cable tension while holding that pose.
        ramp_t_ff_from_zero(
            ctrl,
            hold,
            t_ff_end=_t_ff,
            duration_s=float(STARTUP_T_FF_RAMP_S),
            com_freq_hz=float(COM_FREQ_HZ),
            build_stream=lambda c, pos, t_ff=None: _build_stream(c, pos, t_ff=t_ff),
        )
        started = True
        frame = latest_telemetry(ctrl, n_motors=NUM_MOTORS)
        if frame is not None:
            hold = np.asarray(frame.angles_rad, dtype=np.float64)
            ctrl.communicator.set_data_to_send(_build_stream(ctrl, hold))

        # κ=0 = measured pose at tension-on (do not ramp to a prior home file).
        session_home = hold.copy()
        print(f"  Session home (κ=0): {np.array2string(session_home, precision=4)}")
        keys.flush()
        print_dt = 1.0 / max(float(PRINT_STATUS_HZ), 1.0)
        last_print = 0.0
        last_tick = time.perf_counter()

        while not abort:
            if keys.quit_pressed():
                abort = True
                break
            if keys.enter_pressed():
                frame = latest_telemetry(ctrl, n_motors=NUM_MOTORS)
                if frame is None:
                    print("  No telemetry — not saved.")
                else:
                    saved = np.asarray(frame.angles_rad, dtype=np.float64)
                    break
            if keys.reset_pressed():
                kappa[:] = 0.0

            dk1, dk2 = keys.arrow_deltas(KAPPA_RATE_PER_S, dt)
            if dk1 or dk2:
                lim = float(KAPPA_LIMIT)
                kappa[0] = float(np.clip(kappa[0] + dk1, -lim, lim))
                kappa[1] = float(np.clip(kappa[1] + dk2, -lim, lim))

            target = _enc_from_kappa(float(kappa[0]), float(kappa[1]), session_home)
            ctrl.communicator.set_data_to_send(_build_stream(ctrl, target))
            hold = target

            now = time.perf_counter()
            if now - last_print >= print_dt:
                frame = latest_telemetry(ctrl, n_motors=NUM_MOTORS)
                enc = (
                    np.asarray(frame.angles_rad, dtype=np.float64)
                    if frame is not None
                    else hold
                )
                print(
                    f"  κ=({kappa[0]:+6.2f},{kappa[1]:+6.2f})  "
                    f"enc_deg=[{', '.join(f'{np.degrees(e):+7.2f}' for e in enc)}]  "
                    f"{_format_all_imu_quats(frame)}",
                    flush=True,
                )
                last_print = now

            sleep_s = (last_tick + dt) - time.perf_counter()
            if sleep_s > 0:
                time.sleep(sleep_s)
            last_tick = max(last_tick + dt, time.perf_counter())

    except KeyboardInterrupt:
        print("\nInterrupted.")
        abort = True
    finally:
        keys.close()
        if started:
            try:
                ramp_t_ff_to_zero(
                    ctrl,
                    hold if saved is None else saved,
                    t_ff_start=_t_ff,
                    duration_s=SHUTDOWN_T_FF_RAMP_S,
                    com_freq_hz=COM_FREQ_HZ,
                    build_stream=lambda c, pos, t_ff=None: _build_stream(c, pos, t_ff=t_ff),
                )
            except Exception:
                pass
        try:
            ctrl.communicator.running = False
        except Exception:
            pass
        time.sleep(0.1)
        try:
            ctrl.StopMotors()
        except Exception:
            pass
        try:
            ctrl.communicator.stop()
        except Exception:
            pass

    if saved is None:
        print("Home not saved.")
        return

    out = save_home_positions_rad(
        saved,
        home_path,
        motor_ids=MOTOR_IDS,
        notes=HOME_NOTES,
        script_dir=SCRIPT_DIR,
    )
    print(f"Saved home → {out}")
    print(f"  κ at save: ({kappa[0]:+.3f}, {kappa[1]:+.3f})")
    for i, mid in enumerate(MOTOR_IDS):
        print(
            f"  {hex(mid)}: {saved[i]:+.6f} rad ({np.degrees(saved[i]):+.2f} deg)"
        )


if __name__ == "__main__":
    main()
