#!/usr/bin/env python3
"""
MPC tip-tracking performance analysis
=====================================

Compare for one ``mpc_log_*.csv`` (saved under the ``IMU_oneseg_ws`` root):

  1. tip reference        (x_tar, z_tar)     — gray on the tip-plane plot
  2. OptiTrack tip true   (x_ot_tip, z_ot_tip) in RB1  — real MPC response
  3. NN / state prediction (x_pred_tip, z_pred_tip)  — NaN for handle 3 (OptiTrack)

Also plot commanded κ, encoders, tip speed, and per-sample Δt / rate.

Layout (this repo)::

  Paper/IMU_oneseg_ws/
    mpc_log_*.csv          ← logs live here
    optitrack_roles.py
    src/MyActuator_motor_imu/MyActuator_motor_imu/
      mpc_tracking_performance.py

Edit ``MPC_LOG_NAME`` / ``SKIP_FIRST_N`` in ``main()`` for another run.
Figures open in interactive windows (not saved to disk).

  python mpc_tracking_performance.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Workspace root = folder that holds mpc_log_*.csv and optitrack_roles.py
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent

# Nominal log / COM rate for MPC tip control
NOMINAL_HZ = 400.0
NOMINAL_DT_S = 1.0 / NOMINAL_HZ  # 0.0025 s
TIP_SPEED_FILTER_WIN = 20  # moving-average window on ‖v‖ (samples @ 400 Hz)

# Tip-plane colours
COLOR_REF = "0.55"   # gray reference
COLOR_OT = "#1f77b4"  # real MPC / OptiTrack tip


def _make_stdio_utf8() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, OSError):
            try:
                reconfigure(errors="replace")
            except (ValueError, OSError):
                pass


def find_ws_root(start: Path) -> Path:
    """
    Resolve ``IMU_oneseg_ws`` (contains ``optitrack_roles.py`` + ``mpc_log_*.csv``).

    Order: ``IMU_ONESEG_WS`` env → walk parents of this script → cwd.
    """
    candidates: list[Path] = []
    raw = os.environ.get("IMU_ONESEG_WS", "").strip()
    if raw:
        candidates.append(Path(raw))
    cur = start.resolve()
    for _ in range(12):
        candidates.append(cur)
        if cur.parent == cur:
            break
        cur = cur.parent
    candidates.append(Path.cwd().resolve())

    for cand in candidates:
        cand = cand.resolve()
        if (cand / "optitrack_roles.py").is_file():
            return cand
    raise FileNotFoundError(
        "Could not find IMU_oneseg_ws (optitrack_roles.py).\n"
        "Expected Paper/IMU_oneseg_ws next to the mpc_log_*.csv files,\n"
        "or set IMU_ONESEG_WS to that folder."
    )


WS_ROOT = find_ws_root(SCRIPT_DIR)

HANDLE_LABEL = {
    1: "LSTM yhat @ 400 Hz",
    2: "MLP yhat @ 400 Hz",
    3: "OptiTrack Y @ 100 Hz",
}


def resolve_mpc_log(name_or_path: str | Path) -> Path:
    """
    Resolve a log path.

    Accepts an absolute/relative path, or a bare ``mpc_log_*.csv`` name under
    ``WS_ROOT`` (where the recorder writes).
    """
    p = Path(name_or_path)
    if p.is_file():
        return p.resolve()
    under_ws = WS_ROOT / p.name
    if under_ws.is_file():
        return under_ws.resolve()
    under_cwd = Path.cwd() / p
    if under_cwd.is_file():
        return under_cwd.resolve()
    raise FileNotFoundError(
        f"mpc log not found: {name_or_path}\n"
        f"Looked in:\n  {p}\n  {under_ws}\n  {under_cwd}\n"
        f"WS_ROOT={WS_ROOT}"
    )


def load_mpc_log(path: Path) -> pd.DataFrame:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    need = [
        "time_s",
        "tracking",
        "x_tar",
        "z_tar",
        "x_pred_tip",
        "z_pred_tip",
        "x_ot_tip",
        "z_ot_tip",
        "kappa1_cmd",
        "kappa2_cmd",
        "real_enc01",
        "real_enc02",
        "real_enc03",
        "target_enc01",
        "target_enc02",
        "target_enc03",
        "cal_enc01",
        "cal_enc02",
        "cal_enc03",
    ]
    miss = [c for c in need if c not in df.columns]
    if miss:
        raise ValueError(f"{path.name} missing columns: {miss}")
    return df


def _rmse(a: np.ndarray, b: np.ndarray | None = None) -> float:
    a = np.asarray(a, dtype=np.float64)
    if b is not None:
        b = np.asarray(b, dtype=np.float64)
        d = a - b
    else:
        d = a
    m = np.isfinite(d)
    if not np.any(m):
        return float("nan")
    return float(np.sqrt(np.mean(d[m] ** 2)))


def compute_timing(time_s: np.ndarray) -> dict:
    """
    Per-sample Δt from consecutive ``time_s`` stamps.

    Target for this logger is 400 Hz → dt = 2.5 ms.
    """
    t = np.asarray(time_s, dtype=np.float64).reshape(-1)
    if t.size < 2:
        return {
            "n_dt": 0,
            "dt_s": np.array([], dtype=np.float64),
            "hz": np.array([], dtype=np.float64),
            "dt_mean_ms": float("nan"),
            "dt_median_ms": float("nan"),
            "dt_std_ms": float("nan"),
            "dt_min_ms": float("nan"),
            "dt_max_ms": float("nan"),
            "dt_p95_ms": float("nan"),
            "dt_p99_ms": float("nan"),
            "hz_mean": float("nan"),
            "hz_median": float("nan"),
            "frac_dt_le_nominal": float("nan"),
            "frac_hz_ge_nominal": float("nan"),
            "n_overrun_gt_1p5x": 0,
            "n_gap_gt_10ms": 0,
        }
    dt = np.diff(t)
    # Guard against non-positive / NaN gaps from clock jumps
    ok = np.isfinite(dt) & (dt > 0.0)
    dt_ok = dt[ok]
    hz = np.where(dt_ok > 0.0, 1.0 / dt_ok, np.nan)
    nom = NOMINAL_DT_S
    return {
        "n_dt": int(dt_ok.size),
        "dt_s": dt_ok,
        "hz": hz,
        "dt_mean_ms": float(np.mean(dt_ok) * 1e3),
        "dt_median_ms": float(np.median(dt_ok) * 1e3),
        "dt_std_ms": float(np.std(dt_ok) * 1e3),
        "dt_min_ms": float(np.min(dt_ok) * 1e3),
        "dt_max_ms": float(np.max(dt_ok) * 1e3),
        "dt_p95_ms": float(np.percentile(dt_ok, 95) * 1e3),
        "dt_p99_ms": float(np.percentile(dt_ok, 99) * 1e3),
        "hz_mean": float(np.nanmean(hz)),
        "hz_median": float(np.nanmedian(hz)),
        "frac_dt_le_nominal": float(np.mean(dt_ok <= nom + 1e-9)),
        "frac_hz_ge_nominal": float(np.mean(hz >= NOMINAL_HZ - 1e-6)),
        "n_overrun_gt_1p5x": int(np.sum(dt_ok > 1.5 * nom)),
        "n_gap_gt_10ms": int(np.sum(dt_ok > 0.010)),
    }


def compute_metrics(df: pd.DataFrame, *, skip_first_n: int = 0) -> dict:
    """
    Tip RMSE/MAE on the provided dataframe (caller should already drop
    ``SKIP_FIRST_N`` rows). Within that window, only ``tracking==1`` rows
    are scored (or all rows if none are marked tracking).
    """
    skip_first_n = max(0, int(skip_first_n))
    trk = df["tracking"].to_numpy(dtype=np.float64) > 0.5
    if not np.any(trk):
        trk = np.ones(len(df), dtype=bool)
    t = df.loc[trk, "time_s"].to_numpy(dtype=np.float64)
    xref = df.loc[trk, "x_tar"].to_numpy(dtype=np.float64)
    zref = df.loc[trk, "z_tar"].to_numpy(dtype=np.float64)
    xot = df.loc[trk, "x_ot_tip"].to_numpy(dtype=np.float64)
    zot = df.loc[trk, "z_ot_tip"].to_numpy(dtype=np.float64)
    xpred = df.loc[trk, "x_pred_tip"].to_numpy(dtype=np.float64)
    zpred = df.loc[trk, "z_pred_tip"].to_numpy(dtype=np.float64)

    e_ot_x = xot - xref
    e_ot_z = zot - zref
    e_pred_x = xpred - xref
    e_pred_z = zpred - zref

    tip_ot_err = np.sqrt(e_ot_x**2 + e_ot_z**2)
    tip_pred_err = np.sqrt(e_pred_x**2 + e_pred_z**2)
    n_rmse = int(np.sum(np.isfinite(tip_ot_err)))

    handle = int(df["control_handle"].iloc[0]) if "control_handle" in df.columns else -1
    has_pred = bool(np.any(np.isfinite(xpred) & np.isfinite(zpred)))

    # Timing on full kept window (every CSV row = one log tick @ nominal 400 Hz)
    t_all = df["time_s"].to_numpy(dtype=np.float64)
    timing = compute_timing(t_all)
    timing_trk = compute_timing(t)
    speed = _tip_speed_bundle(xref, zref, xot, zot, NOMINAL_DT_S, TIP_SPEED_FILTER_WIN)

    metrics = {
        "n_rows": int(len(df)),
        "n_track": int(np.sum(trk)),
        "n_rmse": n_rmse,
        "skip_first_n": skip_first_n,
        "t_start_s": float(df["time_s"].iloc[0]),
        "t_end_s": float(df["time_s"].iloc[-1]),
        "t_track_start_s": float(t[0]) if len(t) else float("nan"),
        "t_track_end_s": float(t[-1]) if len(t) else float("nan"),
        "control_handle": handle,
        "handle_label": HANDLE_LABEL.get(handle, f"handle={handle}"),
        "has_nn_pred": has_pred,
        # OptiTrack vs ref (true tracking)
        "rmse_ot_x_mm": _rmse(e_ot_x) * 1e3,
        "rmse_ot_z_mm": _rmse(e_ot_z) * 1e3,
        "rmse_ot_tip_mm": _rmse(tip_ot_err) * 1e3,
        "mae_ot_tip_mm": float(np.nanmean(np.abs(tip_ot_err))) * 1e3,
        "max_ot_tip_mm": float(np.nanmax(np.abs(tip_ot_err))) * 1e3,
        # NN pred vs ref (model fidelity along the run)
        "rmse_pred_x_mm": _rmse(e_pred_x) * 1e3 if has_pred else float("nan"),
        "rmse_pred_z_mm": _rmse(e_pred_z) * 1e3 if has_pred else float("nan"),
        "rmse_pred_tip_mm": _rmse(tip_pred_err) * 1e3 if has_pred else float("nan"),
        # pred vs OT (NN vs truth)
        "rmse_pred_vs_ot_tip_mm": (
            _rmse(np.sqrt((xpred - xot) ** 2 + (zpred - zot) ** 2)) * 1e3
            if has_pred
            else float("nan")
        ),
        "kappa1_max_abs": float(np.nanmax(np.abs(df.loc[trk, "kappa1_cmd"]))),
        "kappa2_max_abs": float(np.nanmax(np.abs(df.loc[trk, "kappa2_cmd"]))),
        "cal_enc_max_abs": float(
            np.nanmax(
                np.abs(
                    df.loc[trk, ["cal_enc01", "cal_enc02", "cal_enc03"]].to_numpy(
                        dtype=np.float64
                    )
                )
            )
        ),
        # Timing (full kept window)
        "dt_mean_ms": timing["dt_mean_ms"],
        "dt_median_ms": timing["dt_median_ms"],
        "dt_std_ms": timing["dt_std_ms"],
        "dt_min_ms": timing["dt_min_ms"],
        "dt_max_ms": timing["dt_max_ms"],
        "dt_p95_ms": timing["dt_p95_ms"],
        "dt_p99_ms": timing["dt_p99_ms"],
        "hz_mean": timing["hz_mean"],
        "hz_median": timing["hz_median"],
        "frac_dt_le_2p5ms": timing["frac_dt_le_nominal"],
        "frac_hz_ge_400": timing["frac_hz_ge_nominal"],
        "n_overrun_gt_1p5x": timing["n_overrun_gt_1p5x"],
        "n_gap_gt_10ms": timing["n_gap_gt_10ms"],
        # Timing (tracking phase only)
        "trk_dt_median_ms": timing_trk["dt_median_ms"],
        "trk_hz_median": timing_trk["hz_median"],
        "trk_frac_hz_ge_400": timing_trk["frac_hz_ge_nominal"],
        # Tip speed ‖v‖ (filtered, tracking phase)
        "v_ref_max_m_s": speed["v_ref_max"],
        "v_ref_mean_m_s": speed["v_ref_mean"],
        "v_ot_max_m_s": speed["v_ot_max"],
        "v_ot_mean_m_s": speed["v_ot_mean"],
        "tip_speed_filter_win": TIP_SPEED_FILTER_WIN,
    }
    return metrics


def _subsample(n: int, max_pts: int = 8000) -> np.ndarray:
    if n <= max_pts:
        return np.arange(n)
    return np.linspace(0, n - 1, max_pts).astype(int)


def _tip_speed_m_s(x: np.ndarray, z: np.ndarray, dt: float) -> np.ndarray:
    """Total tip speed ‖v‖ = √(ẋ²+ż²) in RB1 xz [m/s]; ``dt`` = sample period."""
    x = np.asarray(x, dtype=np.float64)
    z = np.asarray(z, dtype=np.float64)
    if x.size < 2 or dt <= 0.0:
        return np.full(x.shape, np.nan, dtype=np.float64)
    vx = np.gradient(x, dt)
    vz = np.gradient(z, dt)
    return np.sqrt(vx * vx + vz * vz)


def _moving_average(x: np.ndarray, window: int) -> np.ndarray:
    """Centered moving average; ``min_periods=1`` at edges."""
    x = np.asarray(x, dtype=np.float64)
    w = max(1, int(window))
    if w <= 1 or x.size == 0:
        return x.copy()
    return (
        pd.Series(x)
        .rolling(window=w, center=True, min_periods=1)
        .mean()
        .to_numpy(dtype=np.float64)
    )


def _tip_speed_stats(v: np.ndarray) -> tuple[float, float]:
    m = np.isfinite(v)
    if not np.any(m):
        return float("nan"), float("nan")
    vf = v[m]
    return float(np.max(vf)), float(np.mean(vf))


def _tip_speed_bundle(
    x_ref: np.ndarray,
    z_ref: np.ndarray,
    x_ot: np.ndarray,
    z_ot: np.ndarray,
    dt: float,
    window: int,
) -> dict:
    """Raw + filtered tip speeds and max/mean on the filtered series."""
    v_ref_raw = _tip_speed_m_s(x_ref, z_ref, dt)
    v_ot_raw = _tip_speed_m_s(x_ot, z_ot, dt)
    v_ref_filt = _moving_average(v_ref_raw, window)
    v_ot_filt = _moving_average(v_ot_raw, window)
    v_ref_max, v_ref_mean = _tip_speed_stats(v_ref_filt)
    v_ot_max, v_ot_mean = _tip_speed_stats(v_ot_filt)
    return {
        "v_ref_raw": v_ref_raw,
        "v_ref_filt": v_ref_filt,
        "v_ref_max": v_ref_max,
        "v_ref_mean": v_ref_mean,
        "v_ot_raw": v_ot_raw,
        "v_ot_filt": v_ot_filt,
        "v_ot_max": v_ot_max,
        "v_ot_mean": v_ot_mean,
    }


def make_figures(df: pd.DataFrame, metrics: dict, stem: str) -> None:
    trk = df["tracking"].to_numpy(dtype=np.float64) > 0.5
    # Prefer tracking window for tip overlays; full log for enc/κ / timing
    d = df.loc[trk].reset_index(drop=True) if np.any(trk) else df
    idx = _subsample(len(d))
    # Fig 1 time axis: assume each CSV row is one 400 Hz tick (do NOT use time_s)
    t = idx.astype(np.float64) * NOMINAL_DT_S
    xref = d["x_tar"].to_numpy(dtype=np.float64)[idx]
    zref = d["z_tar"].to_numpy(dtype=np.float64)[idx]
    xot = d["x_ot_tip"].to_numpy(dtype=np.float64)[idx]
    zot = d["z_ot_tip"].to_numpy(dtype=np.float64)[idx]
    xpred = d["x_pred_tip"].to_numpy(dtype=np.float64)[idx]
    zpred = d["z_pred_tip"].to_numpy(dtype=np.float64)[idx]
    has_pred = metrics.get("has_nn_pred", False)

    # Tip speed on full tracking window (filtered), then subsample for plot
    speed = _tip_speed_bundle(
        d["x_tar"].to_numpy(dtype=np.float64),
        d["z_tar"].to_numpy(dtype=np.float64),
        d["x_ot_tip"].to_numpy(dtype=np.float64),
        d["z_ot_tip"].to_numpy(dtype=np.float64),
        NOMINAL_DT_S,
        TIP_SPEED_FILTER_WIN,
    )
    v_ref = speed["v_ref_filt"][idx]
    v_ot = speed["v_ot_filt"][idx]
    v_ref_max = metrics.get("v_ref_max_m_s", speed["v_ref_max"])
    v_ref_mean = metrics.get("v_ref_mean_m_s", speed["v_ref_mean"])
    v_ot_max = metrics.get("v_ot_max_m_s", speed["v_ot_max"])
    v_ot_mean = metrics.get("v_ot_mean_m_s", speed["v_ot_mean"])

    # ----- Fig 1: tip plane + time series (t = row / 400 Hz) -----
    fig = plt.figure(figsize=(12, 10), constrained_layout=True)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.0, 0.85])
    fig.suptitle(
        f"MPC tip tracking — {stem}\n"
        f"{metrics['handle_label']}  |  "
        f"OT tip RMSE={metrics['rmse_ot_tip_mm']:.1f} mm"
        + (
            f"  |  NN tip RMSE vs ref={metrics['rmse_pred_tip_mm']:.1f} mm"
            if has_pred
            else "  |  (no NN pred in this log)"
        )
        + f"  |  time axis = row/{NOMINAL_HZ:g}",
        fontsize=11,
    )

    ax = fig.add_subplot(gs[0, 0])
    # Tip xz: reference (gray) + real MPC tip from OptiTrack.
    ax.plot(
        xref, zref, color=COLOR_REF, lw=2.0, label="reference", zorder=2,
    )
    ax.plot(
        xot, zot, color=COLOR_OT, lw=1.3, alpha=0.9,
        label="MPC tip (OptiTrack)", zorder=3,
    )
    ax.set_aspect("equal", adjustable="datalim")
    ax.set_xlabel("x (m) in RB1")
    ax.set_ylabel("z (m) in RB1")
    ax.set_title("Tip plane xz (tracking phase)")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    ax = fig.add_subplot(gs[0, 1])
    ax.plot(t, xref, color=COLOR_REF, lw=1.6, label="ref x")
    ax.plot(t, xot, color=COLOR_OT, lw=1.0, alpha=0.9, label="OT x")
    if has_pred:
        ax.plot(t, xpred, "C1-", lw=0.9, alpha=0.7, label="pred x")
    ax.set_xlabel(f"time (s)  [= row / {NOMINAL_HZ:g} Hz]")
    ax.set_ylabel("x (m)")
    ax.set_title("Tip x(t)")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    ax = fig.add_subplot(gs[1, 0])
    ax.plot(t, zref, color=COLOR_REF, lw=1.6, label="ref z")
    ax.plot(t, zot, color=COLOR_OT, lw=1.0, alpha=0.9, label="OT z")
    if has_pred:
        ax.plot(t, zpred, "C1-", lw=0.9, alpha=0.7, label="pred z")
    ax.set_xlabel(f"time (s)  [= row / {NOMINAL_HZ:g} Hz]")
    ax.set_ylabel("z (m)")
    ax.set_title("Tip z(t)")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    ax = fig.add_subplot(gs[1, 1])
    e_ot = np.sqrt((xot - xref) ** 2 + (zot - zref) ** 2) * 1e3
    ax.plot(t, e_ot, "C0-", lw=1.0, label="‖OT − ref‖")
    if has_pred:
        e_pred = np.sqrt((xpred - xref) ** 2 + (zpred - zref) ** 2) * 1e3
        ax.plot(t, e_pred, "C1-", lw=1.0, alpha=0.85, label="‖pred − ref‖")
    ax.set_xlabel(f"time (s)  [= row / {NOMINAL_HZ:g} Hz]")
    ax.set_ylabel("tip error (mm)")
    ax.set_title("Tip tracking error")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    ax = fig.add_subplot(gs[2, :])
    win = int(metrics.get("tip_speed_filter_win", TIP_SPEED_FILTER_WIN))
    ax.plot(
        t,
        v_ref,
        color=COLOR_REF,
        lw=1.5,
        label=f"‖v‖ ref (MA win={win})  max={v_ref_max:.3f}  avg={v_ref_mean:.3f} m/s",
    )
    ax.plot(
        t,
        v_ot,
        color=COLOR_OT,
        lw=1.0,
        alpha=0.9,
        label=f"‖v‖ OT (MA win={win})  max={v_ot_max:.3f}  avg={v_ot_mean:.3f} m/s",
    )
    ax.set_xlabel(f"time (s)  [= row / {NOMINAL_HZ:g} Hz]")
    ax.set_ylabel("tip speed (m/s)")
    ax.set_title(
        f"Tip speed ‖v‖ = √(ẋ²+ż²), moving avg win={win} @ {NOMINAL_HZ:g} Hz"
    )
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    # ----- Fig 2: kappa + encoders (full log) — uses loaded time_s -----
    fig2, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True, constrained_layout=True)
    fig2.suptitle(f"Actuation — {stem}  (time_s from log)", fontsize=11)
    idx_f = _subsample(len(df))
    tf = df["time_s"].to_numpy(dtype=np.float64)[idx_f]
    trk_f = df["tracking"].to_numpy(dtype=np.float64)[idx_f]

    ax = axes[0]
    ax.plot(tf, df["kappa1_cmd"].to_numpy()[idx_f], label="κ₁", lw=1.0)
    ax.plot(tf, df["kappa2_cmd"].to_numpy()[idx_f], label="κ₂", lw=1.0)
    if np.any(trk_f > 0.5) and np.any(trk_f < 0.5):
        t_track0 = float(df.loc[df["tracking"] > 0.5, "time_s"].iloc[0])
        ax.axvline(t_track0, color="0.4", ls="--", lw=0.8, label="track start")
    ax.set_ylabel("κ (1/m)")
    ax.set_title("Commanded κ (from enc_rel)")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    ax = axes[1]
    for i, c in enumerate(("real_enc01", "real_enc02", "real_enc03"), start=1):
        ax.plot(tf, df[c].to_numpy()[idx_f], lw=1.0, label=f"real{i}")
    for i, c in enumerate(("target_enc01", "target_enc02", "target_enc03"), start=1):
        ax.plot(tf, df[c].to_numpy()[idx_f], lw=0.9, ls="--", alpha=0.75, label=f"tgt{i}")
    ax.set_ylabel("enc abs (rad)")
    ax.set_title("Real vs target absolute encoders")
    ax.legend(loc="best", fontsize=7, ncol=3)
    ax.grid(True, alpha=0.3)

    ax = axes[2]
    for i, c in enumerate(("cal_enc01", "cal_enc02", "cal_enc03"), start=1):
        ax.plot(tf, df[c].to_numpy()[idx_f], lw=1.0, label=f"cal_rel{i}")
    ax.set_xlabel("time_s (s)  [from log]")
    ax.set_ylabel("enc rel (rad)")
    ax.set_title("Commanded home-relative enc (cal_enc = enc_rel_cmd)")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    # ----- Fig 3: timing — loaded time_s + Δt per snapshot (400 Hz check) -----
    t_all = df["time_s"].to_numpy(dtype=np.float64)
    n = int(t_all.size)
    sample_idx = np.arange(n, dtype=np.float64)
    dt = np.diff(t_all)
    # Align Δt with the *end* sample of each interval
    t_dt = t_all[1:]
    ok = np.isfinite(dt) & (dt > 0.0)
    dt_ms = np.where(ok, dt * 1e3, np.nan)
    hz = np.where(ok, 1.0 / dt, np.nan)

    # Subsample for plotting (keep outliers visible: also mark large gaps)
    idx_p = _subsample(n, max_pts=12000)
    # For Δt series use same density on consecutive pairs
    idx_dt_p = _subsample(max(n - 1, 1), max_pts=12000)

    fig3, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=False, constrained_layout=True)
    fig3.suptitle(
        f"Loop timing — {stem}  (uses loaded time_s)\n"
        f"nominal {NOMINAL_HZ:g} Hz (dt={NOMINAL_DT_S * 1e3:.2f} ms)  |  "
        f"median Δt={metrics['dt_median_ms']:.3f} ms  "
        f"({metrics['hz_median']:.1f} Hz)  |  "
        f"frac ≥400 Hz={100.0 * metrics['frac_hz_ge_400']:.1f}%",
        fontsize=11,
    )

    ax = axes[0]
    ax.plot(sample_idx[idx_p], t_all[idx_p], "C0-", lw=1.0, label="time_s")
    # Ideal line from first stamp at 400 Hz
    t0 = float(t_all[0])
    ax.plot(
        sample_idx[idx_p],
        t0 + sample_idx[idx_p] * NOMINAL_DT_S,
        "k--",
        lw=1.0,
        alpha=0.7,
        label="ideal @ 400 Hz",
    )
    if np.any(trk):
        i0 = int(np.flatnonzero(trk)[0])
        ax.axvline(i0, color="0.4", ls=":", lw=0.9, label="track start (row)")
    ax.set_xlabel("snapshot index")
    ax.set_ylabel("time_s (s)")
    ax.set_title("Wall-clock time_s vs snapshot (should be linear @ 400 Hz)")
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    ax = axes[1]
    ax.plot(t_dt[idx_dt_p], dt_ms[idx_dt_p], "C1-", lw=0.8, alpha=0.85, label="Δt")
    ax.axhline(NOMINAL_DT_S * 1e3, color="k", ls="--", lw=1.0, label="2.5 ms (400 Hz)")
    ax.axhline(1.5 * NOMINAL_DT_S * 1e3, color="C3", ls=":", lw=1.0, label="1.5× (3.75 ms)")
    # Mark large gaps
    big = ok & (dt > 0.010)
    if np.any(big):
        ax.scatter(
            t_dt[big],
            dt[big] * 1e3,
            s=18,
            c="C3",
            zorder=5,
            label=f"gaps >10 ms (n={int(np.sum(big))})",
        )
    ax.set_xlabel("time_s (s)  [from log]")
    ax.set_ylabel("Δt (ms)")
    ax.set_title(
        f"Per-sample Δt = time_s[k]−time_s[k−1]  |  "
        f"mean={metrics['dt_mean_ms']:.3f}  med={metrics['dt_median_ms']:.3f}  "
        f"p95={metrics['dt_p95_ms']:.3f}  max={metrics['dt_max_ms']:.3f} ms"
    )
    # Cap y for readability unless huge overruns
    y_hi = max(10.0, float(np.nanpercentile(dt_ms[ok], 99.5)) * 1.2)
    ax.set_ylim(0.0, min(y_hi, 50.0))
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    ax = axes[2]
    ax.plot(t_dt[idx_dt_p], hz[idx_dt_p], "C2-", lw=0.8, alpha=0.85, label="1/Δt")
    ax.axhline(NOMINAL_HZ, color="k", ls="--", lw=1.0, label="400 Hz")
    ax.set_xlabel("time_s (s)  [from log]")
    ax.set_ylabel("rate (Hz)")
    ax.set_title(
        f"Instantaneous rate  |  mean={metrics['hz_mean']:.1f}  "
        f"med={metrics['hz_median']:.1f} Hz  |  "
        f"overruns >1.5×dt: {metrics['n_overrun_gt_1p5x']}"
    )
    ax.set_ylim(0.0, min(800.0, max(500.0, float(np.nanpercentile(hz[ok], 99)) * 1.1)))
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    plt.show()


def analyze_mpc_log(log_path: Path) -> dict:
    """Load log, print-ready metrics, and show figure windows."""
    log_path = resolve_mpc_log(log_path)
    df = load_mpc_log(log_path)
    metrics = compute_metrics(df)
    metrics["log_path"] = str(log_path.resolve())
    make_figures(df, metrics, log_path.stem)
    return metrics


def main() -> None:
    _make_stdio_utf8()
    # =========================================================================
    # Tunables — change MPC_LOG_NAME for another run (file under WS_ROOT)
    # =========================================================================
    MPC_LOG_NAME = "mpc_log_20260826_221447.csv"  # LSTM
    # mpc_log_20260825_220859.csv  # OT
    # mpc_log_20260826_221209.csv  # MLP
    SKIP_FIRST_N = 8000  # drop first N rows for plots AND RMSE/MAE (0 = keep all)
    # =========================================================================

    print(f"WS_ROOT : {WS_ROOT}")
    log_path = resolve_mpc_log(MPC_LOG_NAME)

    df = load_mpc_log(log_path)
    n_raw = len(df)
    skip = max(0, int(SKIP_FIRST_N))
    if skip > 0:
        if skip >= n_raw:
            raise ValueError(f"SKIP_FIRST_N={skip} >= n_rows={n_raw}")
        df = df.iloc[skip:].reset_index(drop=True)

    metrics = compute_metrics(df, skip_first_n=skip)
    metrics["log_path"] = str(log_path.resolve())
    metrics["n_rows_raw"] = n_raw

    print("=" * 72)
    print(f"log     : {metrics['log_path']}")
    print(f"handle  : {metrics['control_handle']}  ({metrics['handle_label']})")
    print(
        f"skip    : first {skip} rows removed from plots + RMSE  "
        f"(kept {len(df)}/{n_raw}, RMSE n={metrics['n_rmse']})"
    )
    print(
        f"window  : t={metrics['t_start_s']:.2f}->{metrics['t_end_s']:.2f} s  "
        f"track={metrics['t_track_start_s']:.2f}->{metrics['t_track_end_s']:.2f} s  "
        f"n_track={metrics['n_track']}/{metrics['n_rows']}"
    )
    print("-" * 72)
    print(
        f"Loop timing (CSV rows @ nominal {NOMINAL_HZ:g} Hz, "
        f"dt={NOMINAL_DT_S * 1e3:.2f} ms):"
    )
    print(
        f"  dt ms: mean={metrics['dt_mean_ms']:.3f}  "
        f"med={metrics['dt_median_ms']:.3f}  "
        f"std={metrics['dt_std_ms']:.3f}  "
        f"min={metrics['dt_min_ms']:.3f}  p95={metrics['dt_p95_ms']:.3f}  "
        f"p99={metrics['dt_p99_ms']:.3f}  max={metrics['dt_max_ms']:.3f}"
    )
    print(
        f"  rate:  mean={metrics['hz_mean']:.1f} Hz  "
        f"med={metrics['hz_median']:.1f} Hz  "
        f"frac >=400 Hz={100.0 * metrics['frac_hz_ge_400']:.1f}%  "
        f"frac dt<=2.5 ms={100.0 * metrics['frac_dt_le_2p5ms']:.1f}%"
    )
    print(
        f"  overruns >1.5x dt: {metrics['n_overrun_gt_1p5x']}  "
        f"gaps >10 ms: {metrics['n_gap_gt_10ms']}  |  "
        f"track med={metrics['trk_hz_median']:.1f} Hz "
        f"({100.0 * metrics['trk_frac_hz_ge_400']:.1f}% >=400)"
    )
    print("-" * 72)
    print(f"True tracking (OptiTrack tip vs ref) [mm]  -- after skip={skip}:")
    print(
        f"  RMSE tip={metrics['rmse_ot_tip_mm']:.2f}  "
        f"x={metrics['rmse_ot_x_mm']:.2f}  z={metrics['rmse_ot_z_mm']:.2f}  "
        f"MAE={metrics['mae_ot_tip_mm']:.2f}  max={metrics['max_ot_tip_mm']:.2f}"
    )
    if metrics["has_nn_pred"]:
        print("NN prediction (pred tip vs ref) [mm]:")
        print(
            f"  RMSE tip={metrics['rmse_pred_tip_mm']:.2f}  "
            f"x={metrics['rmse_pred_x_mm']:.2f}  "
            f"z={metrics['rmse_pred_z_mm']:.2f}  "
            f"pred vs OT={metrics['rmse_pred_vs_ot_tip_mm']:.2f}"
        )
    else:
        print("NN prediction: not present in this log (handle 3 / OptiTrack state).")
    print(
        f"kappa max |k1|={metrics['kappa1_max_abs']:.3f}  "
        f"|k2|={metrics['kappa2_max_abs']:.3f}  "
        f"|cal_enc|_max={metrics['cal_enc_max_abs']:.3f} rad"
    )
    win = int(metrics.get("tip_speed_filter_win", TIP_SPEED_FILTER_WIN))
    print(f"Tip speed ||v|| [m/s]  (MA win={win}, tracking phase):")
    print(
        f"  ref: max={metrics['v_ref_max_m_s']:.3f}  "
        f"avg={metrics['v_ref_mean_m_s']:.3f}"
    )
    print(
        f"  OT : max={metrics['v_ot_max_m_s']:.3f}  "
        f"avg={metrics['v_ot_mean_m_s']:.3f}"
    )
    print("=" * 72)
    print("Opening figure windows (close them to exit)...")

    make_figures(df, metrics, log_path.stem)


if __name__ == "__main__":
    main()
