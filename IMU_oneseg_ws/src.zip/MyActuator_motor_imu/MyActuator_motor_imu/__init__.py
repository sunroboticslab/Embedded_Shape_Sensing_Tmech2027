"""MyActuator 3-motor + 3-IMU one-segment ROS package."""
