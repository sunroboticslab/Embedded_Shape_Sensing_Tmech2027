#!/usr/bin/env python3
"""
ROS2 node: 3-motor one-seg PCC + 3 IMUs (ICRA-OneSeg-pkg).

Publishes ``/motor`` (Float64MultiArray, 24 floats)::

  target_abs×3, real_abs×3, trq×3,
  kappa1, kappa2,
  quat×12 (IMU1 tip, IMU2 mid, IMU3 base — each wxyz),
  seq_time_s

Teensy USB frame::

  Host  → Teensy: [0xAA][36 B motor cmds]
  Teensy → host:  [0xAA][36 B motor telem][48 B = 3×(w,x,y,z) float32 LE]
  → 84 B payload after sync.

κ control (``icra_oneseg.pcc_kinematics``)::

  abs_target = abs_home + rel_enc(κ1, κ2)

Modes:
  1 — random κ in bounds, random ramp + hold (may LOOP until CSV max_rows)
  2 — fixed κ grid (× MODE2_REPEAT), fixed ramp & hold — **one pass**, then home + soft-release
  3 — continuous sinusoidal κ₁, κ₂ — **one pass**, then home + soft-release

Home: workspace ``home_position_saved.txt`` from ``zero_motors.py``.

Run (edit MODE / COM_PORT / PUBLISH_HZ below first)::

  python src/MyActuator_motor_imu/MyActuator_motor_imu/zero_motors.py
  ros2 run MyActuator_motor_imu random_data_collection
"""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Sequence

import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

# =============================================================================
# ICRA-OneSeg-pkg on sys.path (source tree or installed package_data)
# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
ICRA_PKG_DIR = SCRIPT_DIR / "ICRA-OneSeg-pkg"
if not (ICRA_PKG_DIR / "icra_oneseg").is_dir():
    raise ModuleNotFoundError(
        f"ICRA-OneSeg-pkg not found at {ICRA_PKG_DIR}\n"
        "Expected next to random_data_collection.py"
    )
if str(ICRA_PKG_DIR) not in sys.path:
    sys.path.insert(0, str(ICRA_PKG_DIR))

from icra_oneseg.RobstrideMotorMessagesClass import MotorMessages  # noqa: E402
from icra_oneseg.home_position_io import (  # noqa: E402
    default_home_position_path,
    load_home_positions_rad,
)
from icra_oneseg.pcc_kinematics import (  # noqa: E402
    PCCParameters,
    slack_scale_vec,
    target_abs_enc_from_kappa,
)
from icra_oneseg.rs05_drive_tuning import apply_drive_tuning  # noqa: E402
from icra_oneseg.soft_t_ff_release import ramp_t_ff_to_zero  # noqa: E402
from icra_oneseg.stack import (  # noqa: E402
    IMU_COUNT,
    TIP_IMU_INDEX,
    build_ocm_stream,
    calibrate_q0_from_stream,
    configure_imu_telemetry,
    go_home,
    latest_telemetry,
    reconstruct_from_quat,
    total_reply_bytes,
)

# /motor Float64MultiArray layout
N_MOTORS = 3
N_IMU = IMU_COUNT  # 3
N_QUAT = N_IMU * 4  # 12
IDX_TARGET = 0
IDX_REAL = N_MOTORS
IDX_TRQ = 2 * N_MOTORS
IDX_KAPPA1 = 3 * N_MOTORS
IDX_KAPPA2 = IDX_KAPPA1 + 1
IDX_QUAT = IDX_KAPPA2 + 1
IDX_SEQ_TIME = IDX_QUAT + N_QUAT
MOTOR_MSG_LEN = IDX_SEQ_TIME + 1  # 24


def _as_base_rel(n: int, base: Sequence[float]) -> np.ndarray:
    b = np.array(list(base), dtype=np.float64).reshape(-1)
    if b.size == 1:
        return np.full(n, float(b[0]), dtype=np.float64)
    if b.size != n:
        raise ValueError(f"base_rel_enc_rad must have length 1 or {n}, got {b.size}")
    return b.astype(np.float64)


def _kappa_grid_to_flat(grid: list[tuple[float, float]]) -> list[float]:
    out: list[float] = []
    for k1, k2 in grid:
        out.extend([float(k1), float(k2)])
    return out


def _identity_quats(n_imu: int = N_IMU) -> np.ndarray:
    return np.tile(np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64), (n_imu, 1))


def _format_all_imu_quats(quats: np.ndarray) -> str:
    """Format IMU1 tip / IMU2 mid / IMU3 base quaternions (wxyz)."""
    q = np.asarray(quats, dtype=np.float64).reshape(-1, 4)
    labels = ("IMU1_tip", "IMU2_mid", "IMU3_base")
    parts = []
    for i, row in enumerate(q):
        name = labels[i] if i < len(labels) else f"IMU{i + 1}"
        parts.append(
            f"{name}=({row[0]:+.3f},{row[1]:+.3f},{row[2]:+.3f},{row[3]:+.3f})"
        )
    return " ".join(parts)


def _piecewise_ramp_hold(
    keyframes: np.ndarray,
    ramp_each: np.ndarray,
    hold_each: np.ndarray,
    dt: float,
    kappa_keyframes: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    k = keyframes.shape[0]
    if k < 2:
        raise ValueError("need at least 2 keyframes")
    n_seg = k - 1
    if ramp_each.shape != (n_seg,) or hold_each.shape != (n_seg,):
        raise ValueError("ramp_each and hold_each must have length K-1")

    seg_len = ramp_each + hold_each
    total_time = float(np.sum(seg_len))
    n_steps = max(0, int(np.ceil(total_time / dt)))
    times = np.minimum(np.arange(n_steps + 1, dtype=np.float64) * dt, total_time)

    seg_starts = np.empty(n_seg, dtype=np.float64)
    seg_starts[0] = 0.0
    if n_seg > 1:
        np.cumsum(seg_len[:-1], out=seg_starts[1:])

    seg_idx = np.searchsorted(seg_starts, times, side="right") - 1
    seg_idx = np.clip(seg_idx, 0, n_seg - 1)

    t_in_seg = times - seg_starts[seg_idx]
    ramps = ramp_each[seg_idx]
    holds = hold_each[seg_idx]

    in_ramp = t_in_seg < ramps
    safe_ramp = np.where(ramps > 1e-12, ramps, 1.0)
    alpha = np.where(in_ramp, t_in_seg / safe_ramp, 1.0)
    alpha = np.clip(alpha, 0.0, 1.0)

    kf_from = keyframes[seg_idx]
    kf_to = keyframes[seg_idx + 1]
    kk_from = kappa_keyframes[seg_idx]
    kk_to = kappa_keyframes[seg_idx + 1]
    in_ramp_or_hold = t_in_seg < (ramps + holds)

    out = np.where(
        in_ramp_or_hold[:, None],
        kf_from * (1.0 - alpha[:, None]) + kf_to * alpha[:, None],
        kf_to,
    )
    out_kappa = np.where(
        in_ramp_or_hold[:, None],
        kk_from * (1.0 - alpha[:, None]) + kk_to * alpha[:, None],
        kk_to,
    )
    past_end = times >= total_time - 1e-15
    out[past_end] = keyframes[-1]
    out_kappa[past_end] = kappa_keyframes[-1]
    return out, out_kappa


def gen_mode1_random_pcc(
    *,
    tau: int,
    abs_home: np.ndarray,
    base_rel: np.ndarray,
    dt: float,
    ramp_time_min: float,
    ramp_time_max: float,
    hold_time: float,
    kappa1_min: float,
    kappa1_max: float,
    kappa2_min: float,
    kappa2_max: float,
    kappa_limit: float,
    pcc: PCCParameters,
    slack_scale: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    base_abs = abs_home + base_rel
    n_motors = len(base_abs)
    n_kf = tau + 3
    key = np.zeros((n_kf, n_motors), dtype=np.float64)
    kappa_key = np.zeros((n_kf, 2), dtype=np.float64)
    key[0] = base_abs
    key[1] = base_abs
    lim = float(kappa_limit)
    for i in range(tau):
        k1 = float(np.clip(rng.uniform(kappa1_min, kappa1_max), -lim, lim))
        k2 = float(np.clip(rng.uniform(kappa2_min, kappa2_max), -lim, lim))
        kappa_key[2 + i] = (k1, k2)
        key[2 + i] = target_abs_enc_from_kappa(k1, k2, abs_home, pcc, slack_scale)
    key[tau + 2] = base_abs

    ramp_each = np.zeros(tau + 2, dtype=np.float64)
    ramp_each[0] = 0.0
    ramp_each[1:] = rng.uniform(ramp_time_min, ramp_time_max, size=(tau + 1,))
    hold_each = np.full(tau + 2, hold_time, dtype=np.float64)
    return _piecewise_ramp_hold(key, ramp_each, hold_each, dt, kappa_key)


def gen_mode2_kappa_grid(
    *,
    kappa_rows: np.ndarray,
    abs_home: np.ndarray,
    base_rel: np.ndarray,
    dt: float,
    ramp_s: float,
    hold_s: float,
    pcc: PCCParameters,
    slack_scale: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    base_abs = abs_home + base_rel
    rows: list[np.ndarray] = [base_abs.copy()]
    kappa_kf: list[tuple[float, float]] = [(0.0, 0.0)]
    for r in range(kappa_rows.shape[0]):
        k1, k2 = float(kappa_rows[r, 0]), float(kappa_rows[r, 1])
        kappa_kf.append((k1, k2))
        rows.append(target_abs_enc_from_kappa(k1, k2, abs_home, pcc, slack_scale))
    rows.append(base_abs.copy())
    kappa_kf.append((0.0, 0.0))
    key = np.vstack(rows)
    kappa_key = np.array(kappa_kf, dtype=np.float64)
    n_kf = key.shape[0]
    ramp_each = np.full(n_kf - 1, float(ramp_s), dtype=np.float64)
    hold_each = np.full(n_kf - 1, float(hold_s), dtype=np.float64)
    return _piecewise_ramp_hold(key, ramp_each, hold_each, dt, kappa_key)


def gen_mode3_sinusoidal_kappa(
    *,
    abs_home: np.ndarray,
    base_rel: np.ndarray,
    dt: float,
    duration_s: float,
    kappa1_amp: float,
    kappa2_amp: float,
    period_s: float,
    phase_k1: float,
    phase_k2: float,
    kappa_limit: float,
    pcc: PCCParameters,
    slack_scale: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    n_steps = max(1, int(np.ceil(duration_s / dt)))
    times = np.arange(n_steps + 1, dtype=np.float64) * dt
    omega = 2.0 * np.pi / max(float(period_s), 1e-9)
    lim = float(kappa_limit)
    k1 = np.clip(kappa1_amp * np.sin(omega * times + phase_k1), -lim, lim)
    k2 = np.clip(kappa2_amp * np.sin(omega * times + phase_k2), -lim, lim)
    kappa = np.column_stack([k1, k2])
    targets = np.zeros((n_steps + 1, N_MOTORS), dtype=np.float64)
    for i in range(n_steps + 1):
        targets[i] = target_abs_enc_from_kappa(
            float(kappa[i, 0]), float(kappa[i, 1]), abs_home, pcc, slack_scale
        )
    return targets, kappa


def _prepend_warmup(
    targets: np.ndarray,
    kappa: np.ndarray,
    *,
    hold_abs: np.ndarray,
    n_warmup: int,
) -> tuple[np.ndarray, np.ndarray]:
    if n_warmup <= 0:
        return targets, kappa
    tw = np.tile(np.asarray(hold_abs, dtype=np.float64).reshape(1, -1), (n_warmup, 1))
    kw = np.zeros((n_warmup, 2), dtype=np.float64)
    return np.vstack([tw, targets]), np.vstack([kw, kappa])


def _fmt2(x: float) -> str:
    try:
        if np.isnan(float(x)):
            return "nan"
    except (TypeError, ValueError):
        return "nan"
    return f"{float(x):.2f}"


class RandomDataCollectionNode(Node):
    """
    Edit the settings below, then::

      ros2 run MyActuator_motor_imu random_data_collection
    """

    # ========================================================================
    # Run mode / I/O  (edit these first)
    # ========================================================================
    MODE = 1  # 1=random κ ramp+hold, 2=κ grid, 3=sinusoid
    COM_PORT = "/dev/ttyACM0"
    PUBLISH_HZ = 400.0  # must match data_collection rate_hz (OptiTrack upsampled)

    # ========================================================================
    # Serial / motors
    # ========================================================================
    SERIAL_BAUD = 2_000_000
    MOTOR_IDS = [0x10, 0x11, 0x12]

    OPERATION_KP = 10.0
    OPERATION_KD = 0.31
    T_FF_NM = [1.0, 1.0, 1.0]  # Nm — all three motors
    V_SET_RAD_S = [0.0, 0.0, 0.0]
    BASE_REL_ENC_RAD = [0.0, 0.0, 0.0]

    # ========================================================================
    # PCC geometry (literal — keep in sync with physical robot)
    # ========================================================================
    PCC_L_SEG_MM = 240.0  # segment arc length [mm]
    PCC_CABLE_OFFSET_MM = 8.5  # tendon radius from centerline [mm]
    PCC_R_PULLEY_MM = 14.5  # winch / pulley radius [mm]
    SEGMENT_LENGTH_MM = 240.0  # IMU shape recon arc length [mm]

    # ========================================================================
    # Warmup / shutdown
    # ========================================================================
    IMU_WARMUP_S = 10.0  # hold home at start (still publishes → CSV)
    IMU_CALIBRATION_S = 2.0
    IMU_CALIBRATION_MIN_SAMPLES = 40
    RETURN_HOME_DURATION_S = 2.0  # Mode 2/3 finish (and Mode 1 !LOOP): ramp → home
    SHUTDOWN_T_FF_RAMP_S = 2.0  # then soft-release t_ff → 0 (once)

    # ========================================================================
    # Mode 1 — random κ ramp + hold
    # ========================================================================
    TAU = 4000  # number of random κ waypoints per sequence
    RAMP_TIME_MIN = 0.8
    RAMP_TIME_MAX = 3.0
    HOLD_TIME_S = 1.0
    KAPPA_LIMIT = 7.5
    KAPPA1_MIN = -7.5
    KAPPA1_MAX = 7.5
    KAPPA2_MIN = -7.5
    KAPPA2_MAX = 7.5
    SLACK_SCALE = 1.0

    # ========================================================================
    # Mode 2 — fixed κ grid
    # ========================================================================
    MODE2_KAPPA_GRID: list[tuple[float, float]] = [
        (8.0, 0.0),
        (8.0, 8.0),
        (0.0, 8.0),
        (-8.0, 8.0),
        (-8.0, 0.0),
        (-8.0, -8.0),
        (0.0, -8.0),
        (8.0, -8.0),
    ]
    MODE2_REPEAT = 1
    MODE2_RAMP_S = 2.0
    MODE2_HOLD_S = 1.0

    # ========================================================================
    # Mode 3 — continuous sinusoid κ
    # ========================================================================
    MODE3_DURATION_S = 20.0
    MODE3_KAPPA1_AMP = 4.0
    MODE3_KAPPA2_AMP = 4.0
    MODE3_PERIOD_S = 5.0
    MODE3_PHASE_K1 = 0.0
    MODE3_PHASE_K2 = np.pi / 2

    # ========================================================================
    # Looping / logging / home
    # ========================================================================
    # Mode 1 only: when data_collection_max_rows > 0 (pipeline), regenerate
    # sequences until the CSV hits max_rows. Modes 2 / 3 ignore LOOP and run
    # the built trajectory once, then return home + soft-release (no re-wrap).
    LOOP = True
    RANDOM_SEED = -1
    HOME_POSITION_FILE = ""  # empty → workspace home_position_saved.txt
    # Console INFO only (all 3 IMUs). Control + /motor publish stay at PUBLISH_HZ.
    LOG_HZ = 100.0
    TOPIC_NAME = "/motor"
    DATA_COLLECTION_MAX_ROWS = 0  # 0=standalone; launch overrides with max_rows

    def __init__(self) -> None:
        super().__init__("myactuator_random_datacollection")
        cfg = type(self)
        mode2_kappa_flat = _kappa_grid_to_flat(list(cfg.MODE2_KAPPA_GRID))

        self._mode = int(cfg.MODE)
        self._com_port = str(cfg.COM_PORT)
        self._publish_hz = float(cfg.PUBLISH_HZ)
        if self._publish_hz <= 0:
            self._publish_hz = 100.0

        self.declare_parameter("serial_baud", cfg.SERIAL_BAUD)
        self.declare_parameter("motor_ids", cfg.MOTOR_IDS)
        self.declare_parameter("operation_kp", cfg.OPERATION_KP)
        self.declare_parameter("operation_kd", cfg.OPERATION_KD)
        self.declare_parameter("t_ff_nm", list(cfg.T_FF_NM))
        self.declare_parameter("base_rel_enc_rad", cfg.BASE_REL_ENC_RAD)

        self.declare_parameter("pcc_L_seg_mm", cfg.PCC_L_SEG_MM)
        self.declare_parameter("pcc_cable_offset_mm", cfg.PCC_CABLE_OFFSET_MM)
        self.declare_parameter("pcc_R_pulley_mm", cfg.PCC_R_PULLEY_MM)
        self.declare_parameter("segment_length_mm", cfg.SEGMENT_LENGTH_MM)

        self.declare_parameter("tau", cfg.TAU)
        self.declare_parameter("ramp_time_min", cfg.RAMP_TIME_MIN)
        self.declare_parameter("ramp_time_max", cfg.RAMP_TIME_MAX)
        self.declare_parameter("hold_time", cfg.HOLD_TIME_S)
        self.declare_parameter("kappa_limit", cfg.KAPPA_LIMIT)
        self.declare_parameter("kappa1_min", cfg.KAPPA1_MIN)
        self.declare_parameter("kappa1_max", cfg.KAPPA1_MAX)
        self.declare_parameter("kappa2_min", cfg.KAPPA2_MIN)
        self.declare_parameter("kappa2_max", cfg.KAPPA2_MAX)
        self.declare_parameter("slack_scale", cfg.SLACK_SCALE)

        self.declare_parameter("mode2_kappa_flat", mode2_kappa_flat)
        self.declare_parameter("mode2_num_rows", len(cfg.MODE2_KAPPA_GRID))
        self.declare_parameter("mode2_repeat", cfg.MODE2_REPEAT)
        self.declare_parameter("mode2_ramp_s", cfg.MODE2_RAMP_S)
        self.declare_parameter("mode2_hold_s", cfg.MODE2_HOLD_S)

        self.declare_parameter("mode3_duration_s", cfg.MODE3_DURATION_S)
        self.declare_parameter("mode3_kappa1_amp", cfg.MODE3_KAPPA1_AMP)
        self.declare_parameter("mode3_kappa2_amp", cfg.MODE3_KAPPA2_AMP)
        self.declare_parameter("mode3_period_s", cfg.MODE3_PERIOD_S)
        self.declare_parameter("mode3_phase_k1", cfg.MODE3_PHASE_K1)
        self.declare_parameter("mode3_phase_k2", cfg.MODE3_PHASE_K2)

        self.declare_parameter("imu_warmup_s", cfg.IMU_WARMUP_S)
        self.declare_parameter("imu_calibration_s", cfg.IMU_CALIBRATION_S)
        self.declare_parameter("loop", cfg.LOOP)
        self.declare_parameter("random_seed", cfg.RANDOM_SEED)
        self.declare_parameter("home_position_file", cfg.HOME_POSITION_FILE)
        self.declare_parameter("log_hz", cfg.LOG_HZ)
        self.declare_parameter("topic_name", cfg.TOPIC_NAME)
        self.declare_parameter("data_collection_max_rows", cfg.DATA_COLLECTION_MAX_ROWS)

        p = self.get_parameter
        self._baud = int(p("serial_baud").get_parameter_value().integer_value)
        self._operation_kp = float(p("operation_kp").get_parameter_value().double_value)
        self._operation_kd = float(p("operation_kd").get_parameter_value().double_value)
        self._segment_length_mm = float(
            p("segment_length_mm").get_parameter_value().double_value
        )
        self._imu_warmup_s = float(p("imu_warmup_s").get_parameter_value().double_value)
        self._imu_cal_s = float(p("imu_calibration_s").get_parameter_value().double_value)

        ids = list(p("motor_ids").get_parameter_value().integer_array_value)
        self._motor_ids = [int(x) for x in ids] if ids else list(cfg.MOTOR_IDS)
        self._n_motors = len(self._motor_ids)
        if self._n_motors != N_MOTORS:
            raise ValueError(f"Expected {N_MOTORS} motors, got {self._n_motors}")

        t_ff = list(p("t_ff_nm").get_parameter_value().double_array_value)
        self._t_ff = np.asarray(t_ff if t_ff else cfg.T_FF_NM, dtype=float).reshape(-1)
        self._v_set = np.asarray(cfg.V_SET_RAD_S, dtype=float).reshape(-1)
        if self._t_ff.size == 1:
            self._t_ff = np.full(self._n_motors, float(self._t_ff[0]))
        if self._t_ff.size != N_MOTORS:
            raise ValueError(f"t_ff_nm must have {N_MOTORS} entries")
        if self._v_set.size == 1:
            self._v_set = np.full(self._n_motors, float(self._v_set[0]))

        self._pcc = PCCParameters(
            L_seg_mm=float(p("pcc_L_seg_mm").get_parameter_value().double_value),
            cable_offset_mm=float(
                p("pcc_cable_offset_mm").get_parameter_value().double_value
            ),
            R_pulley_mm=float(p("pcc_R_pulley_mm").get_parameter_value().double_value),
        )

        self._tau = max(1, int(p("tau").get_parameter_value().integer_value))
        self._ramp_time_min = float(p("ramp_time_min").get_parameter_value().double_value)
        self._ramp_time_max = float(p("ramp_time_max").get_parameter_value().double_value)
        self._hold_time = float(p("hold_time").get_parameter_value().double_value)
        self._kappa_limit = float(p("kappa_limit").get_parameter_value().double_value)
        self._kappa1_min = float(p("kappa1_min").get_parameter_value().double_value)
        self._kappa1_max = float(p("kappa1_max").get_parameter_value().double_value)
        self._kappa2_min = float(p("kappa2_min").get_parameter_value().double_value)
        self._kappa2_max = float(p("kappa2_max").get_parameter_value().double_value)

        flat2 = list(p("mode2_kappa_flat").get_parameter_value().double_array_value)
        self._mode2_num_rows = max(
            1, int(p("mode2_num_rows").get_parameter_value().integer_value)
        )
        self._mode2_repeat = max(
            1, int(p("mode2_repeat").get_parameter_value().integer_value)
        )
        self._mode2_ramp_s = float(p("mode2_ramp_s").get_parameter_value().double_value)
        self._mode2_hold_s = float(p("mode2_hold_s").get_parameter_value().double_value)

        self._mode3_duration = float(
            p("mode3_duration_s").get_parameter_value().double_value
        )
        self._mode3_k1_amp = float(
            p("mode3_kappa1_amp").get_parameter_value().double_value
        )
        self._mode3_k2_amp = float(
            p("mode3_kappa2_amp").get_parameter_value().double_value
        )
        self._mode3_period = float(p("mode3_period_s").get_parameter_value().double_value)
        self._mode3_ph1 = float(p("mode3_phase_k1").get_parameter_value().double_value)
        self._mode3_ph2 = float(p("mode3_phase_k2").get_parameter_value().double_value)

        br = list(p("base_rel_enc_rad").get_parameter_value().double_array_value)
        self._base_rel = _as_base_rel(self._n_motors, br if br else cfg.BASE_REL_ENC_RAD)

        home_file = p("home_position_file").get_parameter_value().string_value.strip()
        self._home_path = (
            Path(home_file) if home_file else default_home_position_path(SCRIPT_DIR)
        )
        self._abs_home = load_home_positions_rad(
            str(self._home_path), n_motors=self._n_motors, script_dir=SCRIPT_DIR
        )

        self._log_hz = float(p("log_hz").get_parameter_value().double_value)
        if self._log_hz <= 0:
            self._log_hz = 100.0
        # Screen updates at LOG_HZ; ticks still fire at PUBLISH_HZ (400).
        self._log_every = max(1, int(round(self._publish_hz / self._log_hz)))
        topic = p("topic_name").get_parameter_value().string_value or "/motor"
        self._data_collection_max_rows = max(
            0, int(p("data_collection_max_rows").get_parameter_value().integer_value)
        )

        self._loop = bool(p("loop").get_parameter_value().bool_value)
        # Mode 1 + pipeline: keep regenerating until CSV hits max_rows.
        # Modes 2 / 3: fixed-length — never wrap / re-run the grid or sinusoid.
        if self._mode in (2, 3):
            if self._loop:
                self.get_logger().info(
                    f"Mode {self._mode}: fixed trajectory — disabling LOOP "
                    "(run once → home + soft-release)."
                )
            self._loop = False
        elif self._data_collection_max_rows > 0:
            self._loop = True
            self.get_logger().info(
                "Mode 1 LOOP=True — regenerate until CSV max_rows / Ctrl+C."
            )
        seed = int(p("random_seed").get_parameter_value().integer_value)
        self._rng = np.random.default_rng(None if seed < 0 else seed)

        self._dt = 1.0 / self._publish_hz
        need_k = self._mode2_num_rows * 2
        if len(flat2) < need_k:
            raise ValueError(
                f"mode2_kappa_flat length {len(flat2)} < 2*num_rows = {need_k}"
            )
        self._mode2_kappa = np.array(flat2[:need_k], dtype=np.float64).reshape(
            self._mode2_num_rows, 2
        )

        ss_pv = p("slack_scale").get_parameter_value()
        slack_raw = list(ss_pv.double_array_value)
        if not slack_raw:
            slack_raw = [float(ss_pv.double_value)]
        self._slack_scale = slack_scale_vec(slack_raw, n_motors=self._n_motors)

        if self._mode not in (1, 2, 3):
            raise ValueError(f"mode must be 1, 2, or 3; got {self._mode}")

        self._ctrl: MotorMessages | None = None
        self._sequence: np.ndarray | None = None
        self._kappa_sequence: np.ndarray | None = None
        self._q0: np.ndarray | None = None
        self._idx = 0
        self._n_warmup = 0
        self._tick_count = 0
        self._connected = False
        self._finishing = False
        self._shutdown_done = False
        self._motors_shutdown_done = False
        self._last_target_abs: np.ndarray | None = None
        self._hold_abs = self._abs_home + self._base_rel

        self._pub = self.create_publisher(Float64MultiArray, topic, 10)

        pi = float(np.pi)
        self.get_logger().info(f"kit={ICRA_PKG_DIR}")
        self.get_logger().info(f"home file: {self._home_path}")
        self.get_logger().info(f"abs_home_enc (rad): {self._abs_home.tolist()}")
        self.get_logger().info(
            f"PCC L_seg={self._pcc.L_seg_mm} mm, r_c={self._pcc.cable_offset_mm} mm, "
            f"R_pulley={self._pcc.R_pulley_mm} mm | tip_IMU=IMU{TIP_IMU_INDEX + 1}"
        )
        self.get_logger().info(
            f"t_ff={self._t_ff.tolist()} Nm | /motor len={MOTOR_MSG_LEN} "
            f"(3 motors + 2κ + {N_IMU} IMUs)"
        )
        self.get_logger().info(f"Opening serial {self._com_port} @ {self._baud} ...")

        self._ctrl = MotorMessages(
            ComsPort=self._com_port,
            Coms_Freq=self._publish_hz,
            Motor_ids=self._motor_ids,
            InitialAnglesOffsets=[0.0] * self._n_motors,
            minAngles=[-20 * pi] * self._n_motors,
            maxAngles=[20 * pi] * self._n_motors,
            MotorType="RS05",
            baudrate=self._baud,
            log_Coms_freq=False,
        )
        self._ctrl.communicator.verbose = False
        configure_imu_telemetry(self._ctrl, n_motors=self._n_motors)

        self._connect_and_calibrate()
        self._regenerate_sequence()

        self._timer = self.create_timer(self._dt, self._tick)
        self.get_logger().info(
            f"mode={self._mode}, κ≤{self._kappa_limit}, "
            f"ctrl/pub={self._publish_hz:.1f} Hz → {topic} ({MOTOR_MSG_LEN} floats/msg), "
            f"console={self._log_hz:.0f} Hz (every {self._log_every} ticks)"
        )

    def _build_stream(
        self, ctrl: MotorMessages, pos_rad: np.ndarray, *, t_ff=None
    ) -> list[int]:
        return build_ocm_stream(
            ctrl,
            pos_rad,
            t_ff=self._t_ff if t_ff is None else t_ff,
            v_set=self._v_set,
            kp=self._operation_kp,
            kd=self._operation_kd,
        )

    def _connect_and_calibrate(self) -> None:
        c = self._ctrl
        assert c is not None
        c.StopMotors()
        time.sleep(0.05)
        c.SetControlMode("operation")
        c.ApplyFirmwareVelocityHeadroom()
        apply_drive_tuning(c)
        c.StartMotors()
        time.sleep(0.05)

        self._last_target_abs = np.asarray(self._hold_abs, dtype=np.float64)
        c.communicator.set_data_to_send(self._build_stream(c, self._hold_abs))
        c.communicator.start()
        time.sleep(0.15)

        exp = total_reply_bytes(N_MOTORS)
        t0 = time.perf_counter()
        saw = False
        last_quats = _identity_quats()
        while time.perf_counter() - t0 < 2.0:
            c.communicator.set_data_to_send(self._build_stream(c, self._hold_abs))
            frame = latest_telemetry(c, n_motors=self._n_motors)
            if frame is not None:
                saw = True
                last_quats = frame.quaternions
            time.sleep(self._dt)
        self.get_logger().info(
            f"Telemetry OK (expect {exp} B Teensy frame)."
            if saw
            else "WARNING: no telemetry yet."
        )
        self.get_logger().info(f"IMU wxyz @ connect: {_format_all_imu_quats(last_quats)}")

        if self._imu_cal_s > 0:
            cfg = type(self)
            self.get_logger().info(
                f"IMU tip calibrate ({self._imu_cal_s:g} s) — hold home..."
            )
            self._q0 = calibrate_q0_from_stream(
                c,
                self._hold_abs,
                duration_s=self._imu_cal_s,
                min_samples=cfg.IMU_CALIBRATION_MIN_SAMPLES,
                com_freq_hz=self._publish_hz,
                build_stream_fn=self._build_stream,
                n_motors=self._n_motors,
                imu_index=TIP_IMU_INDEX,
            )
            self.get_logger().info(f"q0_tip = {np.array2string(self._q0, precision=4)}")

        self._connected = True

    def _build_sequence(self) -> tuple[np.ndarray, np.ndarray]:
        dt = self._dt
        pcc = self._pcc
        if self._mode == 1:
            return gen_mode1_random_pcc(
                tau=self._tau,
                abs_home=self._abs_home,
                base_rel=self._base_rel,
                dt=dt,
                ramp_time_min=self._ramp_time_min,
                ramp_time_max=self._ramp_time_max,
                hold_time=self._hold_time,
                kappa1_min=self._kappa1_min,
                kappa1_max=self._kappa1_max,
                kappa2_min=self._kappa2_min,
                kappa2_max=self._kappa2_max,
                kappa_limit=self._kappa_limit,
                pcc=pcc,
                slack_scale=self._slack_scale,
                rng=self._rng,
            )
        if self._mode == 2:
            kappa_rows = np.tile(self._mode2_kappa, (self._mode2_repeat, 1))
            return gen_mode2_kappa_grid(
                kappa_rows=kappa_rows,
                abs_home=self._abs_home,
                base_rel=self._base_rel,
                dt=dt,
                ramp_s=self._mode2_ramp_s,
                hold_s=self._mode2_hold_s,
                pcc=pcc,
                slack_scale=self._slack_scale,
            )
        return gen_mode3_sinusoidal_kappa(
            abs_home=self._abs_home,
            base_rel=self._base_rel,
            dt=dt,
            duration_s=self._mode3_duration,
            kappa1_amp=self._mode3_k1_amp,
            kappa2_amp=self._mode3_k2_amp,
            period_s=self._mode3_period,
            phase_k1=self._mode3_ph1,
            phase_k2=self._mode3_ph2,
            kappa_limit=self._kappa_limit,
            pcc=pcc,
            slack_scale=self._slack_scale,
        )

    def _regenerate_sequence(self, *, include_warmup: bool | None = None) -> None:
        targets, kappa = self._build_sequence()
        if include_warmup is None:
            # First build uses IMU_WARMUP_S; later wraps skip re-warmup.
            include_warmup = self._sequence is None
        n_warm = (
            max(0, int(round(self._imu_warmup_s / self._dt))) if include_warmup else 0
        )
        targets, kappa = _prepend_warmup(
            targets, kappa, hold_abs=self._hold_abs, n_warmup=n_warm
        )
        self._sequence = targets
        self._kappa_sequence = kappa
        self._n_warmup = n_warm
        self._idx = 0
        self.get_logger().info(
            f"Sequence mode {self._mode}: {targets.shape[0]} samples "
            f"(warmup={n_warm}), dt={self._dt:.6f} s"
        )

    def _shape_from_frame(self, frame) -> tuple[float, float, float]:
        nan3 = (float("nan"), float("nan"), float("nan"))
        if frame is None or self._q0 is None:
            return nan3
        try:
            shape = reconstruct_from_quat(
                self._q0,
                frame.quaternion,
                arc_length_mm=self._segment_length_mm,
            )
            return float(shape["theta"]), float(shape["phi"]), float(shape["kappa"])
        except Exception:
            return nan3

    def _perform_motors_shutdown(self, *, return_home: bool) -> None:
        """
        ``return_home=True``  — planned end (ramp → home, then soft-release).
        ``return_home=False`` — Ctrl+C / abort (soft-release at last cmd only).
        """
        if self._motors_shutdown_done:
            return
        self._motors_shutdown_done = True
        c = self._ctrl
        if c is None or not getattr(self, "_connected", False):
            self._connected = False
            return
        home = np.asarray(self._hold_abs, dtype=np.float64)
        hold = np.asarray(
            getattr(self, "_last_target_abs", home), dtype=np.float64
        )
        try:
            if return_home:
                self.get_logger().info(
                    f"Returning home ({type(self).RETURN_HOME_DURATION_S:.1f} s) "
                    "then soft-release..."
                )
                go_home(
                    c,
                    home,
                    t_ff=self._t_ff,
                    v_set=self._v_set,
                    kp=self._operation_kp,
                    kd=self._operation_kd,
                    duration_s=type(self).RETURN_HOME_DURATION_S,
                    com_freq_hz=self._publish_hz,
                )
            else:
                self.get_logger().info(
                    f"Soft-release at current pose "
                    f"({type(self).SHUTDOWN_T_FF_RAMP_S:.1f} s)..."
                )
                ramp_t_ff_to_zero(
                    c,
                    hold,
                    t_ff_start=self._t_ff,
                    duration_s=type(self).SHUTDOWN_T_FF_RAMP_S,
                    com_freq_hz=self._publish_hz,
                    build_stream=lambda ctrl, pos, t_ff=None: self._build_stream(
                        ctrl, pos, t_ff=t_ff
                    ),
                )
        except Exception as exc:
            self.get_logger().warning(f"Shutdown motion failed: {exc}")
            try:
                ramp_t_ff_to_zero(
                    c,
                    hold,
                    t_ff_start=self._t_ff,
                    duration_s=type(self).SHUTDOWN_T_FF_RAMP_S,
                    com_freq_hz=self._publish_hz,
                    build_stream=lambda ctrl, pos, t_ff=None: self._build_stream(
                        ctrl, pos, t_ff=t_ff
                    ),
                )
            except Exception:
                pass
        try:
            c.communicator.running = False
        except Exception:
            pass
        time.sleep(0.2)
        try:
            c.StopMotors()
        except Exception:
            pass
        time.sleep(0.1)
        try:
            c.communicator.stop()
        except Exception:
            pass
        self._connected = False
        try:
            self.get_logger().info("Motors shutdown complete.")
        except Exception:
            pass

    def _finish_and_exit(self) -> None:
        """End of Mode 2/3 (or !LOOP): home + soft-release once, then exit spin."""
        if self._finishing or self._shutdown_done:
            return
        self._finishing = True
        self._shutdown_done = True
        if hasattr(self, "_timer") and self._timer is not None:
            try:
                self._timer.cancel()
            except Exception:
                pass
        self.get_logger().info(
            f"Mode {self._mode} trajectory finished (100%) — "
            "return home + soft-release (once)."
        )
        self._perform_motors_shutdown(return_home=True)
        try:
            if rclpy.ok():
                rclpy.shutdown()
        except Exception:
            pass

    def _tick(self) -> None:
        if (
            self._finishing
            or self._shutdown_done
            or not self._connected
            or self._ctrl is None
            or self._sequence is None
            or self._kappa_sequence is None
        ):
            return

        seq = self._sequence
        kseq = self._kappa_sequence
        i = min(self._idx, seq.shape[0] - 1)
        target_abs = seq[i]
        self._last_target_abs = np.asarray(target_abs, dtype=np.float64)
        kappa1 = float(kseq[i, 0])
        kappa2 = float(kseq[i, 1])

        self._ctrl.communicator.set_data_to_send(
            self._build_stream(self._ctrl, target_abs)
        )
        frame = latest_telemetry(self._ctrl, n_motors=self._n_motors)

        row = [0.0] * MOTOR_MSG_LEN
        n = self._n_motors
        for m in range(n):
            row[IDX_TARGET + m] = float(target_abs[m])
        if frame is not None:
            for m in range(n):
                row[IDX_REAL + m] = float(frame.angles_rad[m])
                row[IDX_TRQ + m] = float(frame.torques_nm[m])
            q = np.asarray(frame.quaternions, dtype=np.float64).reshape(N_IMU, 4)
            for imu in range(N_IMU):
                base = IDX_QUAT + imu * 4
                row[base] = float(q[imu, 0])
                row[base + 1] = float(q[imu, 1])
                row[base + 2] = float(q[imu, 2])
                row[base + 3] = float(q[imu, 3])
        else:
            for m in range(n):
                row[IDX_REAL + m] = float("nan")
                row[IDX_TRQ + m] = float("nan")
            for j in range(N_QUAT):
                row[IDX_QUAT + j] = float("nan")

        row[IDX_KAPPA1] = kappa1
        row[IDX_KAPPA2] = kappa2
        # Monotonic run time (never freezes / resets when a sequence wraps).
        row[IDX_SEQ_TIME] = float(self._tick_count) * self._dt

        msg = Float64MultiArray()
        msg.data = [float(x) for x in row]
        self._pub.publish(msg)

        self._tick_count += 1
        if self._tick_count % self._log_every == 0:
            t_s = float(self._tick_count - 1) * self._dt
            # Mode 2/3: progress vs one built pass. Mode 1: CSV max_rows if set.
            if self._mode in (2, 3):
                denom = seq.shape[0]
            elif self._data_collection_max_rows > 0:
                denom = self._data_collection_max_rows
            else:
                denom = seq.shape[0]
            pct = min(100.0, 100.0 * self._tick_count / max(denom, 1))
            # First sequence only: indices < warmup are the home hold.
            phase = "WARMUP" if i < int(getattr(self, "_n_warmup", 0)) else "RUN"
            enc = frame.angles_rad if frame is not None else [float("nan")] * n
            trq = frame.torques_nm if frame is not None else [float("nan")] * n
            th, ph, k_imu = self._shape_from_frame(frame)
            if frame is not None:
                imu_str = (
                    f"{_format_all_imu_quats(frame.quaternions)} | "
                    f"θ={np.degrees(th):.1f}° φ={np.degrees(ph):.1f}° "
                    f"κ_imu={k_imu:.5f}/mm"
                )
            else:
                imu_str = "IMU1_tip=[----] IMU2_mid=[----] IMU3_base=[----]"
            self.get_logger().info(
                f"[{phase}] t_s={_fmt2(t_s)}s {pct:.1f}% "
                f"({self._tick_count:,}/{denom:,}) | "
                f"κ=({kappa1:.2f},{kappa2:.2f}) | "
                f"tar={[f'{float(target_abs[m]):.1f}' for m in range(n)]} | "
                f"enc={[f'{float(enc[m]):.1f}' for m in range(n)]} | "
                f"trq={[f'{float(trq[m]):.2f}' for m in range(n)]} | "
                f"{imu_str}"
            )

        self._idx += 1
        if self._idx >= seq.shape[0]:
            # Mode 2/3 (and Mode 1 with LOOP=False): one pass → home + soft-release.
            # Mode 1 with LOOP: regenerate until CSV max_rows / Ctrl+C.
            if self._mode in (2, 3) or not self._loop:
                self._finish_and_exit()
            else:
                self._regenerate_sequence()

    def destroy_node(self) -> None:
        if hasattr(self, "_timer") and self._timer is not None:
            try:
                self._timer.cancel()
            except Exception:
                pass
        # Planned finish already did home + soft-release once — do not repeat.
        if not self._shutdown_done:
            self._shutdown_done = True
            # Ctrl+C / abort: soft-release at current pose (no second home yank).
            self._perform_motors_shutdown(return_home=False)
        elif not self._motors_shutdown_done:
            self._perform_motors_shutdown(return_home=False)
        try:
            super().destroy_node()
        except Exception:
            pass


def main(args: list[str] | None = None) -> None:
    rclpy.init(args=args)
    node = RandomDataCollectionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.destroy_node()
        except Exception:
            pass
        try:
            if rclpy.ok():
                rclpy.shutdown()
        except Exception:
            pass


if __name__ == "__main__":
    main()
