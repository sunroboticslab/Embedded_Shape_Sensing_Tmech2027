"""
ICRA-OneSeg motor control — stream absolute / relative targets to 3 motors
==========================================================================

Same pattern as the 7-motor + 4-IMU colleague kit: you inject targets for each
motor

Requires firmware: ``Teensy/Teensy_3motor_3IMU.ino``
Requires home file: ``home_position_saved.txt`` from ``zero_motors.py``

Edit USER SETTINGS and ``my_trajectory(...)``, then::

  python motor_control.py
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

# =============================================================================
# USER SETTINGS
# =============================================================================

COM_PORT = "/dev/ttyACM0" if sys.platform != "win32" else "COM4"
SERIAL_BAUD = 2_000_000
COM_FREQ_HZ = 400

MOTOR_IDS = [0x10, 0x11, 0x12]

OPERATION_KP = 10.0
OPERATION_KD = 0.31
T_FF_NM = [1.0, 1.0, 1.0]
V_SET_RAD_S = [0.0, 0.0, 0.0]

# Home from zero_motors.py (None → workspace home_position_saved.txt).
USE_SAVED_HOME = True
HOME_FILE = None

# If True, my_trajectory() / TRAJECTORY_ARRAY are offsets from home.
# If False, they are absolute encoder targets [rad].
TRAJECTORY_RELATIVE_TO_HOME = True

RUN_DURATION_S = None  # None = run until Ctrl+C
TELEMETRY_WARMUP_S = 2.0
RETURN_HOME_DURATION_S = 2.0
PRINT_EVERY_N = 50  # 0 = never

# =============================================================================
# YOUR TRAJECTORY — edit this function
# =============================================================================


def my_trajectory(t: float) -> np.ndarray:
    """
    Return motor targets for time ``t`` [s] since start.

    Shape: (3,) float64 — motors 0x10, 0x11, 0x12 in that order.
    Units: radians.
      - TRAJECTORY_RELATIVE_TO_HOME True  → offsets from saved home
      - TRAJECTORY_RELATIVE_TO_HOME False → absolute encoder positions

    Default: hold home (relative zeros). Replace with your planner output.
    """
    return np.zeros(3, dtype=np.float64)


# Optional offline array [N x 3] instead of my_trajectory(t). None → use function.
TRAJECTORY_ARRAY: np.ndarray | None = None
TRAJECTORY_ARRAY_DT: float | None = None  # None → 1/COM_FREQ_HZ

# =============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from icra_oneseg.RobstrideMotorMessagesClass import MotorMessages  # noqa: E402
from icra_oneseg.home_position_io import (  # noqa: E402
    default_home_position_path,
    load_home_positions_rad,
)
from icra_oneseg.rs05_drive_tuning import apply_drive_tuning  # noqa: E402
from icra_oneseg.stack import (  # noqa: E402
    build_ocm_stream,
    configure_imu_telemetry,
    go_home,
    latest_telemetry,
)

pi = np.pi
NUM_MOTORS = len(MOTOR_IDS)
_t_ff = np.asarray(T_FF_NM, dtype=float).reshape(-1)
_v_set = np.asarray(V_SET_RAD_S, dtype=float).reshape(-1)


def _build_stream(ctrl: MotorMessages, pos_rad: np.ndarray, *, t_ff=None):
    return build_ocm_stream(
        ctrl,
        pos_rad,
        t_ff=_t_ff if t_ff is None else t_ff,
        v_set=_v_set,
        kp=OPERATION_KP,
        kd=OPERATION_KD,
    )


def _next_command(t: float, i: int, array: np.ndarray | None, array_dt: float) -> np.ndarray:
    if array is not None:
        idx = min(i, array.shape[0] - 1)
        return np.asarray(array[idx], dtype=np.float64).reshape(NUM_MOTORS)
    cmd = np.asarray(my_trajectory(t), dtype=np.float64).reshape(-1)
    if cmd.size != NUM_MOTORS:
        raise ValueError(f"my_trajectory must return {NUM_MOTORS} values, got {cmd.size}")
    return cmd


def main() -> None:
    home_path = Path(HOME_FILE) if HOME_FILE else default_home_position_path(SCRIPT_DIR)
    dt = 1.0 / float(COM_FREQ_HZ)

    ctrl = MotorMessages(
        ComsPort=COM_PORT,
        Coms_Freq=float(COM_FREQ_HZ),
        Motor_ids=MOTOR_IDS,
        InitialAnglesOffsets=[0.0] * NUM_MOTORS,
        minAngles=[-20 * pi] * NUM_MOTORS,
        maxAngles=[20 * pi] * NUM_MOTORS,
        MotorType="RS05",
        baudrate=int(SERIAL_BAUD),
        log_Coms_freq=False,
    )
    ctrl.communicator.verbose = False
    configure_imu_telemetry(ctrl, n_motors=NUM_MOTORS)

    if USE_SAVED_HOME:
        abs_home = load_home_positions_rad(home_path, n_motors=NUM_MOTORS, script_dir=SCRIPT_DIR)
        print(f"Home from {home_path}: {abs_home.tolist()}")
    else:
        abs_home = np.zeros(NUM_MOTORS, dtype=np.float64)
        print("WARNING: USE_SAVED_HOME=False — home treated as zeros.")

    traj_array = None if TRAJECTORY_ARRAY is None else np.asarray(TRAJECTORY_ARRAY, dtype=np.float64)
    if traj_array is not None:
        if traj_array.ndim != 2 or traj_array.shape[1] != NUM_MOTORS:
            raise ValueError(f"TRAJECTORY_ARRAY must be shape (N, {NUM_MOTORS})")
    array_dt = float(TRAJECTORY_ARRAY_DT) if TRAJECTORY_ARRAY_DT else dt

    print("3-motor direct position control")
    print(f"  COM={COM_PORT}  {COM_FREQ_HZ:g} Hz")
    print(f"  relative_to_home={TRAJECTORY_RELATIVE_TO_HOME}")
    if RUN_DURATION_S is None:
        print("  duration: until Ctrl+C")
    else:
        print(f"  duration: {RUN_DURATION_S:g} s")

    try:
        ctrl.StopMotors()
        time.sleep(0.05)
        ctrl.SetControlMode("operation")
        ctrl.ApplyFirmwareVelocityHeadroom()
        apply_drive_tuning(ctrl)
        ctrl.StartMotors()
        time.sleep(0.1)

        ctrl.communicator.set_data_to_send(_build_stream(ctrl, abs_home))
        ctrl.communicator.start()
        time.sleep(0.15)

        t0 = time.perf_counter()
        saw = False
        while time.perf_counter() - t0 < TELEMETRY_WARMUP_S:
            ctrl.communicator.set_data_to_send(_build_stream(ctrl, abs_home))
            if latest_telemetry(ctrl, n_motors=NUM_MOTORS) is not None:
                saw = True
            time.sleep(dt)
        print("  Telemetry OK." if saw else "  WARNING: no telemetry yet.")

        t0 = time.perf_counter()
        last_tick = t0
        i = 0

        while True:
            t_now = time.perf_counter()
            t = t_now - t0
            if RUN_DURATION_S is not None and t >= float(RUN_DURATION_S):
                break
            if traj_array is not None and i >= traj_array.shape[0]:
                break

            cmd = _next_command(
                t if traj_array is None else i * array_dt,
                i,
                traj_array,
                array_dt,
            )
            target = abs_home + cmd if TRAJECTORY_RELATIVE_TO_HOME else cmd
            ctrl.communicator.set_data_to_send(_build_stream(ctrl, target))

            if PRINT_EVERY_N > 0 and (i % PRINT_EVERY_N) == 0:
                frame = latest_telemetry(ctrl, n_motors=NUM_MOTORS)
                if frame is None:
                    print(f"t={t:6.2f}  tgt={np.array2string(target, precision=3)}  (no telem)")
                else:
                    print(
                        f"t={t:6.2f}  "
                        f"tgt={np.array2string(target, precision=3)}  "
                        f"enc={np.array2string(np.asarray(frame.angles_rad), precision=3)}"
                    )

            sleep_s = (last_tick + dt) - time.perf_counter()
            if sleep_s > 0:
                time.sleep(sleep_s)
            last_tick = max(last_tick + dt, time.perf_counter())
            i += 1

        print(f"Done. Streamed {i} ticks ({i * dt:.2f} s).")

    except KeyboardInterrupt:
        print("\nInterrupted.")
    finally:
        try:
            go_home(
                ctrl,
                abs_home,
                t_ff=_t_ff,
                v_set=_v_set,
                kp=OPERATION_KP,
                kd=OPERATION_KD,
                duration_s=RETURN_HOME_DURATION_S,
                com_freq_hz=COM_FREQ_HZ,
            )
        except Exception as exc:
            print(f"  WARNING: return-home failed ({exc})")
        try:
            ctrl.communicator.running = False
        except Exception:
            pass
        time.sleep(0.15)
        try:
            ctrl.StopMotors()
        except Exception:
            pass
        try:
            ctrl.communicator.stop()
        except Exception:
            pass


if __name__ == "__main__":
    main()
