# ICRA One-Segment Package

Self-contained kit for the **3-motor + 3-IMU** single-segment continuum robot.
Copy/zip this whole folder — it does not depend on any other repo paths.

```
ICRA-OneSeg-pkg/
  Teensy/Teensy_3motor_3IMU.ino   # flash once (needs Adafruit_BNO08x_Multi + FlexCAN_T4)
  icra_oneseg/                    # Python package (unique name — no kit collisions)
  motor_control.py                # stream absolute/relative targets to 3 motors
  README.md
```

ROS workspace scripts that use this kit (outside the zip root):

- `../zero_motors.py` — κ teleop → workspace `home_position_saved.txt`
- `../random_data_collection.py` — ROS2 /motor publisher for CSV pipeline

## Physical parameters (PCC)

Edit **`icra_oneseg/pcc_kinematics.py`** — block marked `>>> UPDATE PHYSICAL PARAMETERS HERE <<<`.

| Symbol | Constant | Meaning |
|--------|----------|---------|
| L | `L_SEG_MM_DEFAULT` | Segment arc length [mm] |
| r | `CABLE_OFFSET_MM_DEFAULT` | Tendon radial offset [mm] |
| R | `R_PULLEY_MM_DEFAULT` | Pulley / winch radius [mm] |
| ψ | `CABLE_ANGLES_RAD_DEFAULT` | Tendon angles for motors 0,1,2 |
| — | `REL_ENC_RESOLUTION_RAD` | Encoder quantize step [rad] |

κ → motor command:

```text
rel_enc = cable_ΔL(κ1, κ2) / R_pulley
abs_target = abs_home + slack_scaled(rel_enc)
```

(`target_abs_enc_from_kappa` in `pcc_kinematics.py`.)

## Firmware

Board: Teensy 4.1. Sketch: `Teensy/Teensy_3motor_3IMU.ino`  
After USB plug, wait **≥10 s** before opening the COM port.

### Motors

`0x10`, `0x11`, `0x12` on CAN1 @ 1 Mbps

### IMU UART (P1 → 3.3 V)

| IMU | Role | UART | RX ← SDA | TX → SCL |
|-----|------|------|----------|----------|
| 1 | **tip** | Serial1 | pin 0 | pin 1 |
| 2 | middle | Serial2 | pin 7 | pin 8 |
| 3 | **base** | Serial3 | pin 15 | pin 14 |

Absolute Rotation Vector @ **400 Hz** (`kReportIntervalUs = 2500`).

Tip index for PCC shape reconstruction: `icra_oneseg.stack.TIP_IMU_INDEX = 0` (IMU1).

### World / OptiTrack orientation

Robot is placed so that:

- **X–Z** = base / mounting plane  
- **Y** = backbone elongation (base → tip)

`pcc_centerline` rest axis is **+Y** (bend azimuth in the X–Z plane).  
OptiTrack marker roles sort by world-**y** (see workspace `optitrack_roles.py`).

### USB frame (2 Mbaud)

| Direction | Payload |
|-----------|---------|
| Host → Teensy | `0xAA` + 36 B (3×12 motor cmds) |
| Teensy → Host | `0xAA` + 36 B motors + **48 B** (3× wxyz float32 LE) = **84 B** |

## Python deps

```bash
pip install numpy pyserial matplotlib
```

## Workflow (standalone kit)

```bash
cd ICRA-OneSeg-pkg
# edit COM_PORT in the scripts if needed

python ../zero_motors.py   # from MyActuator_motor_imu/ — κ teleop, save home
python motor_control.py    # edit my_trajectory() (or TRAJECTORY_ARRAY), then run
```

### Home + motion model

1. `zero_motors.py` saves absolute encoder angles to workspace
   `home_position_saved.txt` (κ teleop: ↑↓ κ₁, ←→ κ₂, Enter save).
2. `motor_control.py` / `random_data_collection.py` load that home.
3. Default feedforward: **`T_FF_NM = [1.0, 1.0, 1.0]`**.
4. On exit, motors return home then soft-release `t_ff`.

## Tips

- Failed IMUs stay at identity `(1,0,0,0)` on their quat slot.
- Soft-release of `t_ff` runs on script exit.
