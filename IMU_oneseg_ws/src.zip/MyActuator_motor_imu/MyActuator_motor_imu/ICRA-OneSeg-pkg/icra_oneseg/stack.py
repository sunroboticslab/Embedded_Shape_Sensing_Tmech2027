"""
Shared 3-motor + 3-IMU stack helpers.

Host  -> Teensy: [0xAA][36 B motor cmds]
Teensy -> host:  [0xAA][36 B motor telemetry][48 B = 3 x (w,x,y,z) float32 LE]
"""

from __future__ import annotations

import struct
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from .pcc_centerline import average_quaternions, reconstruct_centerline
from .rs05_operation_frame import build_operation_stream
from .soft_t_ff_release import ramp_t_ff_to_zero

MOTOR_FRAME_BYTES = 12
IMU_COUNT = 3
FLOATS_PER_QUAT = 4
IMU_FRAME_BYTES = IMU_COUNT * FLOATS_PER_QUAT * 4  # 48
DEFAULT_MOTOR_IDS = [0x10, 0x11, 0x12]
# Tip IMU index for one-seg PCC reconstruction.
# Hardware: IMU1 = tip, IMU2 = middle, IMU3 = base → tip index 0.
TIP_IMU_INDEX = 0


@dataclass
class TelemetryFrame:
    """One Teensy reply payload after the sync byte."""

    raw: bytes
    angles_rad: list[float]
    vels_rad_s: list[float]
    torques_nm: list[float]
    temps_c: list[float]
    quaternions: np.ndarray  # (3, 4) wxyz

    @property
    def quaternion(self) -> tuple[float, float, float, float]:
        """Tip IMU quaternion (backward-compatible single-quat API)."""
        q = self.quaternions[TIP_IMU_INDEX]
        return (float(q[0]), float(q[1]), float(q[2]), float(q[3]))


def configure_imu_telemetry(ctrl: Any, *, n_motors: int = 3) -> None:
    total = MOTOR_FRAME_BYTES * n_motors + IMU_FRAME_BYTES
    ctrl.communicator.n_Bytes_from_arduino = total
    ctrl.communicator.expected_bytes = total


def motor_reply_bytes(n_motors: int = 3) -> int:
    return MOTOR_FRAME_BYTES * n_motors


def total_reply_bytes(n_motors: int = 3) -> int:
    return motor_reply_bytes(n_motors) + IMU_FRAME_BYTES


def latest_raw_frame(ctrl: Any, *, n_motors: int = 3) -> bytes | None:
    buf = ctrl.communicator.get_buffer()
    if not buf:
        return None
    raw = bytes(buf[-1])
    if len(raw) < total_reply_bytes(n_motors):
        return None
    return raw


def parse_quaternions(raw: bytes, *, n_motors: int = 3) -> np.ndarray:
    start = motor_reply_bytes(n_motors)
    flat = struct.unpack("<12f", raw[start : start + IMU_FRAME_BYTES])
    return np.asarray(flat, dtype=np.float64).reshape(IMU_COUNT, FLOATS_PER_QUAT)


def parse_telemetry(ctrl: Any, raw: bytes, *, n_motors: int = 3) -> TelemetryFrame | None:
    angles: list[float] = []
    vels: list[float] = []
    torques: list[float] = []
    temps: list[float] = []
    for i in range(n_motors):
        chunk = list(raw[i * MOTOR_FRAME_BYTES : (i + 1) * MOTOR_FRAME_BYTES])
        parsed = ctrl.ParseMotorResponse(chunk, ctrl.MotorType)
        if parsed is None:
            return None
        _mid, ang, vel, trq, temp, _mt = parsed
        angles.append(float(ang))
        vels.append(float(vel) if vel is not None else 0.0)
        torques.append(float(trq) if trq is not None else float("nan"))
        temps.append(float(temp) if temp is not None else float("nan"))
    return TelemetryFrame(
        raw=raw,
        angles_rad=angles,
        vels_rad_s=vels,
        torques_nm=torques,
        temps_c=temps,
        quaternions=parse_quaternions(raw, n_motors=n_motors),
    )


def latest_telemetry(ctrl: Any, *, n_motors: int = 3) -> TelemetryFrame | None:
    raw = latest_raw_frame(ctrl, n_motors=n_motors)
    if raw is None:
        return None
    return parse_telemetry(ctrl, raw, n_motors=n_motors)


def build_ocm_stream(
    ctrl: Any,
    target_abs_rad: np.ndarray | list[float],
    *,
    t_ff: np.ndarray | list[float],
    v_set: np.ndarray | list[float],
    kp: float | list[float],
    kd: float | list[float],
) -> list[int]:
    from .RobstrideMotorMessagesClass import MotorMessages

    n = len(ctrl.Motor_ids)
    pos = [
        MotorMessages.clamp(float(target_abs_rad[m]), ctrl.minAngles[m], ctrl.maxAngles[m])
        for m in range(n)
    ]
    t_ff_a = np.asarray(t_ff, dtype=float).reshape(-1)
    v_a = np.asarray(v_set, dtype=float).reshape(-1)
    if t_ff_a.size == 1:
        t_ff_a = np.full(n, float(t_ff_a[0]))
    if v_a.size == 1:
        v_a = np.full(n, float(v_a[0]))
    if np.ndim(kp) == 0:
        kp_l = [float(kp)] * n
    else:
        kp_l = [float(x) for x in np.asarray(kp, dtype=float).reshape(-1)]
    if np.ndim(kd) == 0:
        kd_l = [float(kd)] * n
    else:
        kd_l = [float(x) for x in np.asarray(kd, dtype=float).reshape(-1)]
    return build_operation_stream(
        ctrl.Motor_ids,
        t_ff_a.tolist(),
        pos,
        v_a.tolist(),
        kp_l,
        kd_l,
    )


def reconstruct_from_quat(
    q0: np.ndarray | tuple[float, float, float, float],
    q: np.ndarray | tuple[float, float, float, float],
    *,
    arc_length_mm: float,
    num_points: int = 40,
) -> dict[str, Any]:
    return reconstruct_centerline(q0, q, float(arc_length_mm), int(num_points))


def calibrate_q0_from_stream(
    ctrl: Any,
    hold_target: np.ndarray,
    *,
    duration_s: float,
    min_samples: int,
    com_freq_hz: float,
    build_stream_fn,
    n_motors: int = 3,
    imu_index: int = TIP_IMU_INDEX,
) -> np.ndarray:
    """Average tip (or selected) IMU quaternion while holding ``hold_target``."""
    samples: list[np.ndarray] = []
    t_end = time.perf_counter() + float(duration_s)
    dt = 1.0 / float(com_freq_hz)
    while time.perf_counter() < t_end or len(samples) < min_samples:
        ctrl.communicator.set_data_to_send(build_stream_fn(ctrl, hold_target))
        frame = latest_telemetry(ctrl, n_motors=n_motors)
        if frame is not None:
            samples.append(frame.quaternions[imu_index].copy())
        time.sleep(dt)
    if len(samples) < min_samples:
        raise RuntimeError(
            f"IMU calibration got {len(samples)} samples (need {min_samples})."
        )
    return average_quaternions(samples)


def calibrate_q0_multi_from_stream(
    ctrl: Any,
    hold_target: np.ndarray,
    *,
    duration_s: float,
    min_samples: int,
    com_freq_hz: float,
    build_stream_fn,
    n_motors: int = 3,
) -> np.ndarray:
    """Average all 3 IMU quaternions → shape (3, 4)."""
    samples: list[np.ndarray] = []
    t_end = time.perf_counter() + float(duration_s)
    dt = 1.0 / float(com_freq_hz)
    while time.perf_counter() < t_end or len(samples) < min_samples:
        ctrl.communicator.set_data_to_send(build_stream_fn(ctrl, hold_target))
        frame = latest_telemetry(ctrl, n_motors=n_motors)
        if frame is not None:
            samples.append(frame.quaternions.copy())
        time.sleep(dt)
    if len(samples) < min_samples:
        raise RuntimeError(
            f"IMU calibration got {len(samples)} samples (need {min_samples})."
        )
    stacked = np.stack(samples, axis=0)
    out = np.zeros((IMU_COUNT, 4), dtype=np.float64)
    for i in range(IMU_COUNT):
        out[i] = average_quaternions(list(stacked[:, i]))
    return out


def go_home(
    ctrl: Any,
    home_enc_rad: np.ndarray,
    *,
    t_ff: np.ndarray | list[float],
    v_set: np.ndarray | list[float],
    kp: float,
    kd: float,
    duration_s: float,
    com_freq_hz: float,
) -> None:
    def _stream(c, pos, t_ff=None):
        return build_ocm_stream(
            c,
            pos,
            t_ff=t_ff if t_ff is not None else t_ff_arr,
            v_set=v_set,
            kp=kp,
            kd=kd,
        )

    t_ff_arr = np.asarray(t_ff, dtype=float).reshape(-1)
    print(f"Returning to home for {duration_s:g} s...")
    t0 = time.perf_counter()
    dt = 1.0 / float(com_freq_hz)
    while time.perf_counter() - t0 < float(duration_s):
        ctrl.communicator.set_data_to_send(_stream(ctrl, home_enc_rad))
        time.sleep(dt)

    ramp_t_ff_to_zero(
        ctrl,
        home_enc_rad,
        t_ff_start=t_ff_arr,
        duration_s=min(2.0, float(duration_s)),
        com_freq_hz=float(com_freq_hz),
        build_stream=_stream,
    )


def package_root() -> Path:
    return Path(__file__).resolve().parent.parent
