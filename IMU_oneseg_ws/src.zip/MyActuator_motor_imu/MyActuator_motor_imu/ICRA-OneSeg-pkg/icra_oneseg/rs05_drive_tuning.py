"""
Apply RS05 parameters via MotorMessages while motors are **stopped**.

Call after StopMotors / SetControlMode / ApplyFirmwareVelocityHeadroom and before StartMotors.
"""


def apply_drive_tuning(
    ctrl,
    *,
    cur_filt_gain=None,
    cur_kp=None,
    cur_ki=None,
    loc_kp=None,
    vel_kp=None,
    vel_ki=None,
    vel_filter_gain=None,
):
    """
    Each keyword: if not None, writes that parameter to all motors. None = skip (firmware default).
    """
    applied = []
    if cur_kp is not None:
        ctrl.Set_Cur_Kp(float(cur_kp))
        applied.append(f"cur_kp={float(cur_kp)}")
    if cur_ki is not None:
        ctrl.Set_Cur_Ki(float(cur_ki))
        applied.append(f"cur_ki={float(cur_ki)}")
    if cur_filt_gain is not None:
        ctrl.Set_Cur_Filt_Gain(float(cur_filt_gain))
        applied.append(f"cur_filt_gain={float(cur_filt_gain)}")
    if loc_kp is not None:
        ctrl.Set_Loc_Kp(float(loc_kp))
        applied.append(f"loc_kp={float(loc_kp)}")
    if vel_kp is not None:
        ctrl.Set_Vel_Kp(float(vel_kp))
        applied.append(f"vel_kp={float(vel_kp)}")
    if vel_ki is not None:
        ctrl.Set_Vel_Ki(float(vel_ki))
        applied.append(f"vel_ki={float(vel_ki)}")
    if vel_filter_gain is not None:
        ctrl.Set_vel_filter_gain(float(vel_filter_gain))
        applied.append(f"vel_filter_gain={float(vel_filter_gain)}")
    if applied:
        print("RS05 drive tuning:", ", ".join(applied))
