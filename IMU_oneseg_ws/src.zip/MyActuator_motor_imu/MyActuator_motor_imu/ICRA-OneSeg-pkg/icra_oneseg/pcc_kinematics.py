"""
Piecewise Constant Curvature (PCC) kinematics — one segment, three tendons.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

# =============================================================================
# >>> UPDATE PHYSICAL PARAMETERS HERE <<<
# Segment length L [mm], tendon radial offset [mm], pulley radius [mm],
# and tendon angles around the disk [rad]. Scripts build PCCParameters() from these.
# =============================================================================
L_SEG_MM_DEFAULT = 240.0          # backbone / segment arc length [mm]
CABLE_OFFSET_MM_DEFAULT = 8.5     # tendon radius from centerline [mm]
R_PULLEY_MM_DEFAULT = 14.5        # winch / pulley radius [mm]
CABLE_ANGLES_RAD_DEFAULT = np.deg2rad([0.0, 120.0, 240.0])  # motor 0,1,2

REL_ENC_RESOLUTION_RAD = 4e-4
KAPPA_LIMIT_DEFAULT = 8.0
SLACK_SCALE_DEFAULT = 1.0
# =============================================================================


@dataclass(frozen=True)
class PCCParameters:
    """Pass custom values, or leave defaults (from the USER SETTINGS block above)."""

    L_seg_mm: float = L_SEG_MM_DEFAULT
    cable_offset_mm: float = CABLE_OFFSET_MM_DEFAULT
    R_pulley_mm: float = R_PULLEY_MM_DEFAULT
    cable_angles_rad: np.ndarray = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.cable_angles_rad is None:
            object.__setattr__(self, "cable_angles_rad", CABLE_ANGLES_RAD_DEFAULT.copy())
        else:
            object.__setattr__(
                self,
                "cable_angles_rad",
                np.asarray(self.cable_angles_rad, dtype=np.float64),
            )
        if self.R_pulley_mm <= 0:
            raise ValueError("R_pulley_mm must be > 0")


def quantize_rel_enc(rel_rad: np.ndarray, step: float = REL_ENC_RESOLUTION_RAD) -> np.ndarray:
    x = np.asarray(rel_rad, dtype=np.float64)
    return np.round(x / step) * step


def cable_delta_length_mm(
    kappa1: float,
    kappa2: float,
    params: PCCParameters | None = None,
) -> np.ndarray:
    p = params or PCCParameters()
    k1, k2 = float(kappa1), float(kappa2)
    psi = p.cable_angles_rad
    r_m = p.cable_offset_mm * 1e-3
    L_m = p.L_seg_mm * 1e-3
    dL_m = -r_m * L_m * (k1 * np.cos(psi) + k2 * np.sin(psi))
    return dL_m * 1e3


def rel_enc_from_kappa(
    kappa1: float,
    kappa2: float,
    params: PCCParameters | None = None,
    *,
    quantize: bool = True,
) -> np.ndarray:
    p = params or PCCParameters()
    dL_mm = cable_delta_length_mm(kappa1, kappa2, p)
    rel = dL_mm / p.R_pulley_mm
    if quantize:
        rel = quantize_rel_enc(rel)
    return rel


def kappa_from_rel_enc(
    rel_enc: np.ndarray,
    params: PCCParameters | None = None,
    *,
    kappa_limit: float = KAPPA_LIMIT_DEFAULT,
) -> tuple[float, float]:
    """Least-squares (κ1, κ2) from measured home-relative encoders."""
    p = params or PCCParameters()
    rel = np.asarray(rel_enc, dtype=np.float64).reshape(-1)
    if rel.size != p.cable_angles_rad.size:
        raise ValueError(f"rel_enc length {rel.size} != n_cables {p.cable_angles_rad.size}")
    scale = -(p.cable_offset_mm * p.L_seg_mm * 1e-3) / p.R_pulley_mm
    m = np.column_stack([scale * np.cos(p.cable_angles_rad), scale * np.sin(p.cable_angles_rad)])
    k, *_ = np.linalg.lstsq(m, rel, rcond=None)
    lim = float(kappa_limit)
    return float(np.clip(k[0], -lim, lim)), float(np.clip(k[1], -lim, lim))


def slack_scale_vec(
    slack_scale: float | np.ndarray = SLACK_SCALE_DEFAULT,
    n_motors: int = 3,
) -> np.ndarray:
    o = np.asarray(slack_scale, dtype=np.float64).reshape(-1)
    if o.size == 1:
        return np.full(n_motors, float(o[0]), dtype=np.float64)
    if o.size != n_motors:
        raise ValueError(f"slack_scale must be scalar or length {n_motors}")
    return o


def slack_scalar(rel_enc: np.ndarray) -> np.ndarray:
    return np.where(np.asarray(rel_enc, dtype=np.float64) < 0, 1.0, 0.0)


def rel_enc_for_command(
    rel_enc: np.ndarray,
    slack_scale: float | np.ndarray = SLACK_SCALE_DEFAULT,
) -> np.ndarray:
    rel = np.asarray(rel_enc, dtype=np.float64)
    sc = slack_scale_vec(slack_scale, n_motors=rel.size)
    s = slack_scalar(rel)
    scaled = rel * sc
    return rel * (1.0 - s) + s * scaled


def target_abs_enc_from_rel(
    rel_enc: np.ndarray,
    abs_home_enc: np.ndarray,
    slack_scale: float | np.ndarray = SLACK_SCALE_DEFAULT,
) -> np.ndarray:
    rel_cmd = quantize_rel_enc(rel_enc_for_command(rel_enc, slack_scale))
    return np.asarray(abs_home_enc, dtype=np.float64) + rel_cmd


def target_abs_enc_from_kappa(
    kappa1: float,
    kappa2: float,
    abs_home_enc: np.ndarray,
    params: PCCParameters | None = None,
    slack_scale: float | np.ndarray = SLACK_SCALE_DEFAULT,
) -> np.ndarray:
    p = params or PCCParameters()
    rel = rel_enc_from_kappa(kappa1, kappa2, p, quantize=False)
    return target_abs_enc_from_rel(rel, abs_home_enc, slack_scale)
