"""ICRA one-segment helpers (motors, home I/O, 3-IMU telemetry, PCC)."""
