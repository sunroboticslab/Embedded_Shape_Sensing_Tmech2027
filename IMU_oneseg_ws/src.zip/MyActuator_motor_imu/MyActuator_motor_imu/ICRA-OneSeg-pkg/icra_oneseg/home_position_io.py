"""
Home encoder file for ICRA-OneSeg-pkg (txt).

Canonical path (ROS workspace)::

  /root/DataCollection/IMU_oneseg_ws/home_position_saved.txt

Canonical line::

  POSITION_TARGETS_RAD: <m0>, <m1>, <m2>
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

HOME_POSITION_FILENAME = "home_position_saved.txt"
NUM_MOTORS_DEFAULT = 3
_WS_MARKER = "optitrack_roles.py"


def find_workspace_root(start: Path | None = None) -> Path | None:
    """Locate IMU_oneseg_ws (contains ``optitrack_roles.py``)."""
    env = os.environ.get("IMU_ONESEG_WS", "").strip()
    if env and (Path(env) / _WS_MARKER).is_file():
        return Path(env).resolve()
    here = Path(start).resolve() if start is not None else Path(__file__).resolve().parent
    for p in [here, *here.parents]:
        if (p / _WS_MARKER).is_file():
            return p
    return None


def default_home_position_path(script_dir: Path | None = None) -> Path:
    """Prefer workspace-root ``home_position_saved.txt``, else next to ``script_dir``."""
    ws = find_workspace_root(script_dir)
    if ws is not None:
        return ws / HOME_POSITION_FILENAME
    root = Path(script_dir) if script_dir is not None else Path(__file__).resolve().parent.parent
    return root / HOME_POSITION_FILENAME


def save_home_positions_rad(
    abs_home_enc_rad: np.ndarray | list[float],
    path: str | Path | None = None,
    *,
    motor_ids: list[int] | None = None,
    notes: str = "",
    script_dir: Path | None = None,
) -> Path:
    out = Path(path) if path else default_home_position_path(script_dir)
    enc = np.asarray(abs_home_enc_rad, dtype=np.float64).reshape(-1)
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines = [
        "# abs_home_enc (rad) — absolute Type 0x02 encoder at taut/home pose.",
        "# target_enc[i] = abs_home_enc[i] + rel_enc[i]",
        f"# saved_at_utc: {stamp}",
    ]
    if notes:
        lines.append(f"# notes: {notes}")
    if motor_ids is not None:
        lines.append(f"# motor_ids_hex: {', '.join(hex(int(m)) for m in motor_ids)}")
        lines.append("# per_motor_id_rad:")
        for i, mid in enumerate(motor_ids):
            if i < enc.size:
                lines.append(
                    f"#   {hex(int(mid))}: {float(enc[i]):.8f} rad "
                    f"({float(np.degrees(enc[i])):.4f} deg)"
                )
    lines.append(
        f"POSITION_TARGETS_RAD: {', '.join(f'{float(x):.8f}' for x in enc)}"
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


def load_home_positions_rad(
    path: str | Path | None = None,
    n_motors: int = NUM_MOTORS_DEFAULT,
    *,
    script_dir: Path | None = None,
) -> np.ndarray:
    home_path = Path(path) if path and str(path).strip() else default_home_position_path(script_dir)
    if not home_path.is_file():
        raise FileNotFoundError(
            f"Home position file not found: {home_path}\nRun zero_motors.py first."
        )
    text = home_path.read_text(encoding="utf-8")
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s.upper().startswith("POSITION_TARGETS_RAD:"):
            payload = s.split(":", 1)[1].strip()
            vals = [float(x.strip()) for x in payload.split(",") if x.strip()]
            enc = np.asarray(vals, dtype=np.float64)
            if enc.size != n_motors:
                raise ValueError(f"Home file has {enc.size} motors, expected {n_motors}")
            return enc
    floats: list[float] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        try:
            floats.append(float(s.split()[0]))
        except ValueError:
            continue
    if len(floats) == n_motors:
        return np.asarray(floats, dtype=np.float64)
    raise ValueError(f"Could not parse POSITION_TARGETS_RAD from {home_path}")
