"""
RS05 operation / 运控 mode — CAN packing per RS05UserManual.pdf §4.1.2 and §4.4.2.

  motor_controlmode(id, torque, MechPosition, speed, kp, kd)

Extended 29-bit ID (exCanIdInfo): mode=1, id=motor, data=uint16(torque).
8-byte payload (high byte first per field): position, speed, Kp, Kd.
"""

from __future__ import annotations

import numpy as np

pi = np.pi

COMM_TYPE_OPERATION = 0x01

T_MIN_NM = -5.5
T_MAX_NM = 5.5
P_MIN_RAD = -4.0 * pi
P_MAX_RAD = 4.0 * pi
V_MIN_RAD_S = -50.0
V_MAX_RAD_S = 50.0
KP_MIN = 0.0
KP_MAX = 500.0
KD_MIN = 0.0
KD_MAX = 5.0


def float_to_uint(x: float, x_min: float, x_max: float, bits: int = 16) -> int:
    """Same mapping as manual §4.4.2 float_to_uint."""
    span = float(x_max - x_min)
    if span <= 0:
        raise ValueError("x_max must exceed x_min.")
    x = float(np.clip(x, x_min, x_max))
    return int(round((x - x_min) * ((1 << bits) - 1) / span))


def uint_to_float(u: int, x_min: float, x_max: float, bits: int = 16) -> float:
    u = int(u) & ((1 << bits) - 1)
    return float(u) * (x_max - x_min) / ((1 << bits) - 1) + x_min


def build_operation_eid_bytes(motor_id: int, torque_nm: float) -> list[int]:
    """
    Four USB/CAN-ID bytes (big-endian uint32) for Teensy extractExtId.

    Layout: bit28-24 mode=0x01, bit23-8 torque uint16, bit7-0 motor id.
    """
    tau_u = float_to_uint(torque_nm, T_MIN_NM, T_MAX_NM, 16)
    eid = (COMM_TYPE_OPERATION << 24) | ((tau_u & 0xFFFF) << 8) | (int(motor_id) & 0xFF)
    return [(eid >> 24) & 0xFF, (eid >> 16) & 0xFF, (eid >> 8) & 0xFF, eid & 0xFF]


def pack_operation_payload_bytes(
    position_rad: float,
    speed_rad_s: float,
    kp: float,
    kd: float,
    *,
    p_min: float = P_MIN_RAD,
    p_max: float = P_MAX_RAD,
) -> list[int]:
    """Eight data bytes: MechPosition, speed, Kp, Kd (uint16 BE each)."""
    fields = (
        (position_rad, p_min, p_max),
        (speed_rad_s, V_MIN_RAD_S, V_MAX_RAD_S),
        (kp, KP_MIN, KP_MAX),
        (kd, KD_MIN, KD_MAX),
    )
    out: list[int] = []
    for val, lo, hi in fields:
        u = float_to_uint(val, lo, hi, 16)
        out.append((u >> 8) & 0xFF)
        out.append(u & 0xFF)
    return out


def build_operation_record(
    motor_id: int,
    torque_nm: float,
    position_rad: float,
    speed_rad_s: float,
    kp: float,
    kd: float,
    *,
    p_min: float = P_MIN_RAD,
    p_max: float = P_MAX_RAD,
) -> list[int]:
    """12-byte Teensy record: 4-byte extended ID + 8-byte payload."""
    return build_operation_eid_bytes(motor_id, torque_nm) + pack_operation_payload_bytes(
        position_rad, speed_rad_s, kp, kd, p_min=p_min, p_max=p_max
    )


def build_operation_stream(
    motor_ids,
    torques_nm,
    positions_rad,
    speeds_rad_s,
    kps,
    kds,
    position_p_limits: list[tuple[float, float]] | None = None,
) -> list[int]:
    """Concatenated 12-byte records for all motors.

    ``position_p_limits`` optional per-motor (p_min, p_max) for MechPosition uint16
    encoding. Default is ±4π for every motor (RS05 OCM wire range for PCC joints).
    """
    out: list[int] = []
    n = len(motor_ids)
    for i in range(n):
        if position_p_limits is not None:
            p_min, p_max = position_p_limits[i]
        else:
            p_min, p_max = P_MIN_RAD, P_MAX_RAD
        out.extend(
            build_operation_record(
                motor_ids[i],
                torques_nm[i],
                positions_rad[i],
                speeds_rad_s[i],
                kps[i],
                kds[i],
                p_min=p_min,
                p_max=p_max,
            )
        )
    return out
