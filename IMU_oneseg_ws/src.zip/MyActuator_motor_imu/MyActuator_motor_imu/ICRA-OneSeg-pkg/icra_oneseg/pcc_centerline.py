"""
Single-segment PCC centerline reconstruction from IMU quaternions.

All lengths are in millimetres; curvature kappa is in rad/mm.

Rest / home pose aligns the backbone with world **+Y** (same as OptiTrack:
X–Z = base plane, Y = elongation). Bend direction ``phi`` is measured in the
X–Z plane.
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np

Quaternion = tuple[float, float, float, float] | np.ndarray

# Rest backbone axis in the robot / Motive frame (column of R).
_REST_AXIS_INDEX = 1  # ê_y = [0, 1, 0]


def quat_normalize(q: Quaternion) -> np.ndarray:
    q = np.asarray(q, dtype=np.float64).reshape(4)
    n = np.linalg.norm(q)
    if n < 1e-12:
        raise ValueError("Quaternion norm is zero.")
    return q / n


def quat_conjugate(q: Quaternion) -> np.ndarray:
    w, x, y, z = quat_normalize(q)
    return np.array([w, -x, -y, -z], dtype=np.float64)


def quat_multiply(q_left: Quaternion, q_right: Quaternion) -> np.ndarray:
    """Hamilton product q_left ⊗ q_right (scalar-first w, x, y, z)."""
    w1, x1, y1, z1 = quat_normalize(q_left)
    w2, x2, y2, z2 = quat_normalize(q_right)
    return np.array(
        [
            w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
            w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
            w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
            w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
        ],
        dtype=np.float64,
    )


def quat_inverse(q: Quaternion) -> np.ndarray:
    return quat_conjugate(q)


def average_quaternions(quats: Sequence[Quaternion]) -> np.ndarray:
    """Average unit quaternions on the same hemisphere, then re-normalize."""
    if not quats:
        raise ValueError("Need at least one quaternion for averaging.")
    ref = quat_normalize(quats[0])
    acc = np.zeros(4, dtype=np.float64)
    for q in quats:
        v = quat_normalize(q)
        if float(np.dot(ref, v)) < 0.0:
            v = -v
        acc += v
    return quat_normalize(acc)


def quat_to_rotation_matrix(q: Quaternion) -> np.ndarray:
    w, x, y, z = quat_normalize(q)
    return np.array(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - w * z), 2.0 * (x * z + w * y)],
            [2.0 * (x * y + w * z), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - w * x)],
            [2.0 * (x * z - w * y), 2.0 * (y * z + w * x), 1.0 - 2.0 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def relative_orientation(q0: Quaternion, q: Quaternion) -> np.ndarray:
    """q_rel = q0^{-1} ⊗ q."""
    return quat_multiply(quat_inverse(q0), q)


def distal_disk_normal(q_rel: Quaternion) -> np.ndarray:
    """Rotated backbone axis: n = R(q_rel) @ [0, 1, 0]^T (rest along +Y)."""
    return quat_to_rotation_matrix(q_rel)[:, _REST_AXIS_INDEX]


def bending_parameters(n: np.ndarray, arc_length_mm: float) -> tuple[float, float, float]:
    """
    Return bending angle theta [rad], direction phi [rad], curvature kappa [rad/mm].

    ``theta`` is the angle of the distal normal away from +Y.
    ``phi`` is the bend azimuth in the X–Z base plane (``atan2(nz, nx)``).
    """
    if arc_length_mm <= 0.0:
        raise ValueError("arc_length_mm must be > 0.")

    n = np.asarray(n, dtype=np.float64).reshape(3)
    norm = np.linalg.norm(n)
    if norm > 0.0:
        n = n / norm

    nx, ny, nz = float(n[0]), float(n[1]), float(n[2])
    theta = float(np.arccos(np.clip(ny, -1.0, 1.0)))
    phi = float(np.arctan2(nz, nx))
    kappa = theta / arc_length_mm
    return theta, phi, kappa


def centerline_xyz(
    kappa: float,
    phi: float,
    arc_length_mm: float,
    num_points: int,
    *,
    kappa_zero_tol: float = 1e-9,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Discretize s in [0, L] and evaluate PCC centreline (x, y, z) in mm.

    Rest pose advances along **+Y**; bend displaces in the X–Z plane.
    """
    if num_points < 2:
        raise ValueError("num_points must be >= 2.")
    if arc_length_mm <= 0.0:
        raise ValueError("arc_length_mm must be > 0.")

    s = np.linspace(0.0, arc_length_mm, num_points, dtype=np.float64)
    if abs(kappa) < kappa_zero_tol:
        x = np.zeros_like(s)
        y = s.copy()
        z = np.zeros_like(s)
        return x, y, z

    ks = kappa * s
    radial = (1.0 - np.cos(ks)) / kappa
    x = radial * np.cos(phi)
    z = radial * np.sin(phi)
    y = np.sin(ks) / kappa
    return x, y, z


def reconstruct_centerline(
    q0: Quaternion,
    q: Quaternion,
    arc_length_mm: float,
    num_points: int,
) -> dict[str, np.ndarray | float]:
    """Full pipeline: q0, q -> centreline samples and bending parameters."""
    q_rel = relative_orientation(q0, q)
    n = distal_disk_normal(q_rel)
    theta, phi, kappa = bending_parameters(n, arc_length_mm)
    x, y, z = centerline_xyz(kappa, phi, arc_length_mm, num_points)
    return {
        "q_rel": q_rel,
        "n": n,
        "theta": theta,
        "phi": phi,
        "kappa": kappa,
        "x": x,
        "y": y,
        "z": z,
        "s": np.linspace(0.0, arc_length_mm, num_points, dtype=np.float64),
    }
