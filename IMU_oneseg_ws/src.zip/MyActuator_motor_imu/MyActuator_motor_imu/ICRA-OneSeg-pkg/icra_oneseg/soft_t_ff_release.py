"""Hold pose while linearly ramping OCM / hybrid feedforward torque."""

from __future__ import annotations

import time
from collections.abc import Callable, Sequence
from typing import Any

import numpy as np

BuildStreamFn = Callable[..., list[int]]


def ramp_t_ff_to_zero(
    ctrl: Any,
    hold_target: Sequence[float] | np.ndarray,
    *,
    t_ff_start: Sequence[float] | np.ndarray,
    duration_s: float,
    com_freq_hz: float,
    build_stream: BuildStreamFn,
) -> None:
    """
    Keep commanding *hold_target* while ``t_ff`` ramps from *t_ff_start* → 0.

    *build_stream* must accept ``(ctrl, hold_target, t_ff=...)``.
    """
    if duration_s <= 0:
        return
    start = np.asarray(t_ff_start, dtype=float).reshape(-1)
    hold = np.asarray(hold_target, dtype=float).reshape(-1)
    if not np.any(np.abs(start) > 1e-12):
        return

    n_steps = max(1, int(np.ceil(float(duration_s) * float(com_freq_hz))))
    print(
        f"Soft release: ramping t_ff {start.tolist()} → 0 over {duration_s:g} s "
        f"(holding pose)..."
    )
    t0 = time.perf_counter()
    for step in range(n_steps + 1):
        alpha = min(1.0, step / n_steps)
        t_ff = start * (1.0 - alpha)
        ctrl.communicator.set_data_to_send(build_stream(ctrl, hold, t_ff=t_ff))
        if step < n_steps:
            target_wake = t0 + (step + 1) * (float(duration_s) / n_steps)
            sleep_s = target_wake - time.perf_counter()
            if sleep_s > 0:
                time.sleep(sleep_s)


def ramp_t_ff_from_zero(
    ctrl: Any,
    hold_target: Sequence[float] | np.ndarray,
    *,
    t_ff_end: Sequence[float] | np.ndarray,
    duration_s: float,
    com_freq_hz: float,
    build_stream: BuildStreamFn,
) -> None:
    """
    Soft start: keep commanding *hold_target* while ``t_ff`` ramps
    from 0 → *t_ff_end*.

    *build_stream* must accept ``(ctrl, hold_target, t_ff=...)``.
    """
    if duration_s <= 0:
        return
    end = np.asarray(t_ff_end, dtype=float).reshape(-1)
    hold = np.asarray(hold_target, dtype=float).reshape(-1)
    if not np.any(np.abs(end) > 1e-12):
        return

    n_steps = max(1, int(np.ceil(float(duration_s) * float(com_freq_hz))))
    print(
        f"Soft start: ramping t_ff 0 → {end.tolist()} over {duration_s:g} s "
        f"(holding pose)..."
    )
    t0 = time.perf_counter()
    for step in range(n_steps + 1):
        alpha = min(1.0, step / n_steps)
        t_ff = end * alpha
        ctrl.communicator.set_data_to_send(build_stream(ctrl, hold, t_ff=t_ff))
        if step < n_steps:
            target_wake = t0 + (step + 1) * (float(duration_s) / n_steps)
            sleep_s = target_wake - time.perf_counter()
            if sleep_s > 0:
                time.sleep(sleep_s)
