'''
By: Eric weissman
9/8/2025

Helper class which builds CAN messages for robstride 03 motors (potentially other motors too)
Also provides some functions for simple forward and inverse kinematics for a leg
'''

import struct
from dataclasses import dataclass
import math
import numpy as np
from numpy import pi
from collections import deque
# from scipy.optimize import least_squares
import itertools
from .MotorSerialCommunicator import SerialCommunicator
import struct
import time

def clamp(x, lo, hi):
    return max(lo, min(hi, x))


host_id: int = 0xFD
l1 = .2
l2 = .2

######################################
# HElper functions for the class
######################################
def build_eid(cmd: int, host: int, motor: int):
    return [cmd, 0x00, host, motor]

def wrap_to_pi(a):
    return (a + np.pi) % (2*np.pi) - np.pi

def project_angle_to_bounds(a, lo, hi):
    """
    Shift angle a by 2π*k so it lands inside [lo, hi].
    Assumes hi > lo and (hi - lo) <= 2π.
    """
    aw = wrap_to_pi(a)
    two_pi = 2*np.pi
    # Smallest k such that aw + 2πk >= lo
    k_min = np.ceil((lo - aw) / two_pi)
    cand = aw + k_min * two_pi
    if cand > hi:
        cand -= two_pi
    return float(np.clip(cand, lo, hi))

def unwrap_angles(angle_list):
    if not angle_list:
        return []
    unwrapped = [angle_list[0]]
    for a in angle_list[1:]:
        prev = unwrapped[-1]
        diff = wrap_to_pi(a - prev)
        unwrapped.append(prev + diff)
    return unwrapped


class MotorMessages:
    def __init__(self,
                 ComsPort,
                 Coms_Freq,
                 Motor_ids,
                 InitialAnglesOffsets,
                 minAngles,
                 maxAngles,
                 MotorType,
                 baudrate=1_000_000,
                 log_Coms_freq = True
                 ):
        
        #coms variables
        self.ComsPort =  ComsPort
        self.Coms_Freq = Coms_Freq
        self.baudrate = baudrate

        
        self.Motor_ids = Motor_ids
        self.numMotors = len(self.Motor_ids)
        self.InitialAnglesOffsets = InitialAnglesOffsets
        
        self.maxAngles = maxAngles
        self.minAngles = minAngles

        #variable for parsing 0x02 CAN response
        self.prevAngle = np.zeros((self.numMotors,1)) #angle of last motor reading
        self.revCounter = np.zeros((self.numMotors,1)) #counter used to find number of turns motor rotor has made
        
        # self.InitialPos = MotorMessages.PlanarFK(InitialAnglesOffsets[1], InitialAnglesOffsets[2])

        self.ControlMode = None
        self.ControlModeOptions = { 'operation':0x00,
                                    'position':0x01,
                                    'velocity':0x02,
                                    'current':0x03,
                                    'CSP':0x05}
        
        #handle motor Types
        self.MotorType = MotorType
        if self.MotorType == "RS00":
            self.MotorMaxTorques = 14.
            self.MotorMaxVel = 33.
            self.MotorMaxCurrent = 16.
        elif self.MotorType== "RS03":
            self.MotorMaxTorques= 60.
            self.MotorMaxVel = 20.
            self.MotorMaxCurrent = 43.
        elif self.MotorType == "RS05":
            # RobStride RS05 user manual: peak torque 5.5 N·m, max phase current 11 A pk,
            # Type 2 feedback velocity span ±50 rad/s.
            self.MotorMaxTorques = 5.5
            self.MotorMaxVel = 50.0
            self.MotorMaxCurrent = 11.0
        else:
            raise Exception("Invalid Motor Types", self.MotorType)

        self.MotorState = 'Stopped'
        self.maxSpeed = self.MotorMaxVel #for Position mode only


        #variables for velocity estimate
        # for EMA
        self._vel_ema = [0.0] * self.numMotors
        # for windowed buffer (for least-squares)
        self._angle_window_size = 5  # tune: 3..11
        # store deques of (time, angle) per motor
        self._angle_windows = [deque(maxlen=self._angle_window_size) for _ in range(self.numMotors)]


        #create Serial Communicator Object
        self.communicator = SerialCommunicator(port=self.ComsPort,
                                  baudrate=self.baudrate,
                                  n_Bytes_to_arduino=12*self.numMotors,
                                  n_floats_from_arduino=12*self.numMotors,
                                  verbose=False,
                                  logFreq=log_Coms_freq,
                                  DesiredFreq=self.Coms_Freq,
                                  buffer_size=50,
                                  CSVPath=None)
        time.sleep(1)
        self.communicator.drainSerial() #clear any serial msgs

    def StopMotors(self):

        #stop all motion and cancle coms threads

        self.communicator.running = False # stop any coms threads

        #send stop msg
        msg = list(itertools.chain.from_iterable([MotorMessages.stop_motor_msg(motor_id = self.Motor_ids[i]) 
                                                  for i in range(self.numMotors)])) #combines all motor commands into 1 serial msg
        self.communicator.SingleWrite(msg)
        time.sleep(.1) #give time to allow motors to stop

        self.MotorState = 'Stopped'

    def SetControlMode(self, mode):
        #set control mode for all motors
        if(self.MotorState == 'Stopped'):
            if mode in self.ControlModeOptions:
                self.ControlMode = mode
                
                msg = list(itertools.chain.from_iterable([MotorMessages.set_control_mode_msg(motor_id = self.Motor_ids[i], mode =self.ControlModeOptions[mode])
                                                        for i in range(self.numMotors)]))
                self.communicator.SingleWrite(msg)
            else:
                raise ValueError("Selected Control Mode Not Found.")
        else:
            print("Could not set motor mode since motors are not stopped")

    def SetMaxSpeed(self, maxSpeed):
        #set max speed for all motors
        
        maxSpeed = self.clamp(maxSpeed, 0,self.MotorMaxVel, True)#clamp max speed to be within motor's capabilities
        self.maxSpeed = maxSpeed
        msg = list(itertools.chain.from_iterable([self.set_max_speed_msg(motor_id = self.Motor_ids[i], max_speed=maxSpeed)
                                                    for i in range(self.numMotors)]))
        self.communicator.SingleWrite(msg)

        if(self.MotorState != 'Stopped'):
            print("Warning: setting max speed while motor is enabled")

    def ZeroMotors(self):
        
        if(self.MotorState == 'Stopped'):
            msg = list(itertools.chain.from_iterable([MotorMessages.zero_motor_msg(motor_id = self.Motor_ids[i])
                                                       for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)

        else:
            print("Could not zero since motors are not stopped")

    def Set_Zero_sta_Mode(self, Zero_sta_mode):
        #set max speed for all motors
        if(self.MotorState == 'Stopped'):
            msg = list(itertools.chain.from_iterable([MotorMessages.set_Zero_sta_mode_msg(motor_id = self.Motor_ids[i], Zero_sta_mode = Zero_sta_mode) 
                                                      for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)

        else:
            print("Could not set zero_sta since motors are not stopped")

        # self.MotorController.Set_PP_Mode_PosRef_single([0.0, 0.0, 0.0]) #command motors to hold initial pose

    def SetMaxAccel(self, maxAccel):
        #set maxself.maxSpeed speed for all motors
        if(self.MotorState == 'Stopped'):
            
            msg = list(itertools.chain.from_iterable([MotorMessages.set_max_acc_msg(motor_id = self.Motor_ids[i], max_acc = maxAccel)
                                                       for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)
            
        else:
            print("Could not set max Accel since motors are not stopped")
    
    def SetMaxTorque(self, maxTorque):
        #set maxself.maxSpeed speed for all motors
        if(self.MotorState == 'Stopped'):
            
            msg = list(itertools.chain.from_iterable([self.set_max_Torque_msg(motor_id = self.Motor_ids[i], max_torque = maxTorque)
                                                       for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)
            
        else:
            print("Could not set max Accel since motors are not stopped")

    def SetCurrentLimit(self, limit_Current):

        limit_Current = clamp(limit_Current, 0,self.MotorMaxCurrent)

        if(self.MotorState == 'Stopped'):
            
            msg = list(itertools.chain.from_iterable([MotorMessages.set_limit_Current_msg(motor_id = self.Motor_ids[i], limit_Current = limit_Current) 
                                                      for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)

        else:
            print("Could not set max current since motors are not stopped")
    
    def Set_Loc_Kp(self, loc_kp):
        
        if(self.MotorState == 'Stopped'):
            
            msg = list(itertools.chain.from_iterable([MotorMessages.set_loc_kp_msg(motor_id = self.Motor_ids[i], loc_kp = loc_kp) 
                                                      for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)

        else:
            print("Could not set loc kp since motors are not stopped")

    def Set_Vel_Kp(self, vel_kp):
        
        if(self.MotorState == 'Stopped'):
            msg = list(itertools.chain.from_iterable([MotorMessages.set_vel_kp_msg(motor_id = self.Motor_ids[i], vel_kp = vel_kp) 
                                                      for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)

        else:
            print("Could not set vel kp since motors are not stopped")

    def Set_Vel_Ki(self, vel_ki):
        
        if(self.MotorState == 'Stopped'):
            msg = list(itertools.chain.from_iterable([MotorMessages.set_vel_ki_msg(motor_id = self.Motor_ids[i], vel_ki = vel_ki) 
                                                      for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)

        else:
            print("Could not set vel ki since motors are not stopped")

    def Set_vel_filter_gain(self, vel_filter_gain):
        
        if(self.MotorState == 'Stopped'):
            msg = list(itertools.chain.from_iterable([MotorMessages.set_vel_filter_gain_msg(motor_id = self.Motor_ids[i], vel_filter_gain = vel_filter_gain) 
                                                      for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)

        else:
            print("Could not set vel_filter_gain since motors are not stopped")

    def Set_Cur_Kp(self, cur_kp):
        if self.MotorState == 'Stopped':
            msg = list(itertools.chain.from_iterable(
                [self.set_cur_kp_msg(motor_id=self.Motor_ids[i], cur_kp=cur_kp) for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)
        else:
            print("Could not set cur_kp since motors are not stopped")

    def Set_Cur_Ki(self, cur_ki):
        if self.MotorState == 'Stopped':
            msg = list(itertools.chain.from_iterable(
                [self.set_cur_ki_msg(motor_id=self.Motor_ids[i], cur_ki=cur_ki) for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)
        else:
            print("Could not set cur_ki since motors are not stopped")

    def Set_Cur_Filt_Gain(self, cur_filt_gain):
        """RS05 index 0x7014 (cur_filt_gain). Lower → iq_ref follows setpoint faster (default ~0.1 in manual)."""
        if self.MotorState == 'Stopped':
            msg = list(itertools.chain.from_iterable(
                [self.set_cur_filt_gain_msg(motor_id=self.Motor_ids[i], cur_filt_gain=cur_filt_gain)
                 for i in range(self.numMotors)]))
            self.communicator.SingleWrite(msg)
        else:
            print("Could not set cur_filt_gain since motors are not stopped")

    def ApplyFirmwareVelocityHeadroom(self):
        """
        While **stopped**: set PP **vel_max** (0x7024) and CSP **limit_spd** (0x7017) to **MotorMaxVel**
        (50 rad/s for RS05 per manual). Clears low factory defaults (manual cites 10 rad/s default on
        vel_max) so trajectory speed limits are not left tight when you use current mode or switch modes.
        Call after **StopMotors**, typically after **SetControlMode**, before **StartMotors**.
        """
        if self.MotorState != 'Stopped':
            print("ApplyFirmwareVelocityHeadroom skipped (motors must be stopped).")
            return
        self.SetMaxSpeed(self.MotorMaxVel)
        self.Set_PP_Mode_SpeedRef(self.MotorMaxVel)

    def StartMotors(self):
        msg = list(itertools.chain.from_iterable([MotorMessages.start_motor_msg(motor_id = self.Motor_ids[i])
                                                   for i in range(self.numMotors)]))
        self.communicator.SingleWrite(msg)
        self.MotorState = 'Started'

    def Set_PP_Mode_SpeedRef(self, speed):
        ClampedSpeed = self.clamp(speed, 0, self.maxSpeed) #clamp max speed to be within motor's capabilities
        msg = list(itertools.chain.from_iterable([self.set_speed_ref_msg(motor_id = self.Motor_ids[i], speed = ClampedSpeed)
                                                   for i in range(self.numMotors)]))
        self.communicator.SingleWrite(msg)

    def Set_Velocity_Mode_SpdRef(self, speeds):
        """Write 0x700A (spd_ref); use in velocity mode per RS05 §4.3.3. `speeds` length must match numMotors."""
        if len(speeds) != self.numMotors:
            raise ValueError("speeds must have one entry per motor")
        msg = list(itertools.chain.from_iterable(
            [self.set_velocity_mode_spd_ref_msg(motor_id=self.Motor_ids[i], speed=speeds[i])
             for i in range(self.numMotors)]))
        self.communicator.SingleWrite(msg)

    def Set_Vel_Mode_AccRad(self, acc_rad_s2):
        """Write 0x7022 (acc_rad) for all motors; RS05 velocity-mode acceleration."""
        if np.isscalar(acc_rad_s2):
            accs = [float(acc_rad_s2)] * self.numMotors
        else:
            accs = list(acc_rad_s2)
            if len(accs) != self.numMotors:
                raise ValueError("acc_rad_s2 must be scalar or one value per motor")
        msg = list(itertools.chain.from_iterable(
            [self.set_vel_mode_acc_rad_msg(motor_id=self.Motor_ids[i], acc_rad_s2=accs[i])
             for i in range(self.numMotors)]))
        self.communicator.SingleWrite(msg)

    def Set_PP_Mode_PosRef_single(self, Angles, reply_timeout=None):
        #sets motor ref_loc for all motors (from list Angles)
        #check to make sure motors are in correct mode
        #clamps motor positions based on angle limits

        if self.ControlMode == 'position' or self.ControlMode == 'CSP':

            msg = list(itertools.chain.from_iterable(
                        [MotorMessages.set_position_ref_msg(motor_id = self.Motor_ids[i],
                                                        position = MotorMessages.clamp(Angles[i], self.minAngles[i], self.maxAngles[i])) 
                                                        for i in range(self.numMotors)]))
            return self.communicator.SingleWrite(msg, reply_timeout=reply_timeout)
        else:
            print('Control mode must be set to position before seting ref_loc')
        return None

    def Set_PP_Mode_PosRef_Threading(self, Angles):
        # sets motor ref_loc for all motors (from list Angles). 
        # Intended to be used with the serial communicator's threads for high speed updates to reference
        # check to make sure motors are in correct mode
        # clamps motor positions based on angle limits
        

        if (self.ControlMode == 'position' or self.ControlMode == 'CSP') and self.MotorState == 'Started' and self.communicator.running:
            
            msg = list(itertools.chain.from_iterable(
                        [MotorMessages.set_position_ref_msg(motor_id = self.Motor_ids[i],
                                                        position = MotorMessages.clamp(Angles[i], self.minAngles[i], self.maxAngles[i])) 
                                                        for i in range(self.numMotors)]))
            self.communicator.set_data_to_send(msg)
        else:
            print('Verify (1) control mode is set to position before seting ref_loc, (2) serial threads have started, and (3) motor has been started')

    def Set_Current_ref_single(self, Currents, reply_timeout=None):
        #sets motor ref_iq for all motors (from list Currents)
        #check to make sure motors are in correct mode

        if self.ControlMode == 'current':
            msg = list(itertools.chain.from_iterable(
                    [self.set_current_ref_msg(motor_id=self.Motor_ids[i], CurrentRef=Currents[i])
                    for i in range(self.numMotors)]))

            return self.communicator.SingleWrite(msg, reply_timeout=reply_timeout)
        else:
            print('Control mode must be set to current before seting ref_iq')
        return None

    def Set_Current_ref_Threading(self, Currents):
        # sets motor ref_iq for all motors (from list Currents)
        # Intended to be used with the serial communicator's threads for high speed updates to reference
        # check to make sure motors are in correct mode

        if self.ControlMode == 'current' and self.MotorState == 'Started' and self.communicator.running:
            msg = list(itertools.chain.from_iterable(
                    [self.set_current_ref_msg(motor_id=self.Motor_ids[i], CurrentRef=Currents[i])
                    for i in range(self.numMotors)]))

            self.communicator.set_data_to_send(msg)
        else:
            print('Verify (1) control mode is set to current before seting iq_ref, (2) serial threads have started, and (3) motors have been started')

    def getLatestAngles(self):
        Angles = [0.0]*self.numMotors
        msgBuffer = self.communicator.get_buffer() 
        if msgBuffer:
            latestRepsonse = list(msgBuffer[-1])
            for i in range(self.numMotors):
                Motor_i_response = latestRepsonse[i*12:12+i*12]
                try:
                    id, angle, vel, torque, temperature, msgType = self.ParseMotorResponse(
                        Motor_i_response, self.MotorType
                    )
                except:
                    raise Exception("full message:", latestRepsonse)
                Angles[i] = angle
        return(Angles)
    
    def getMotorState(self, MotorType=None):

        Angles = [0.0]*self.numMotors
        vels = [0.0]*self.numMotors
        torques= [0.0]*self.numMotors
        temps= [0.0]*self.numMotors
        mt = MotorType if MotorType is not None else self.MotorType

        msgBuffer = self.communicator.get_buffer() 
        
        if msgBuffer:
            latestResponse = list(msgBuffer[-1])
            for i in range(self.numMotors):
                Motor_i_response = latestResponse[i*12:12+i*12]
                
                try:

                    id, angle, vel, torque, temperature, msgType  = self.ParseMotorResponse(Motor_i_response, mt)

                except:

                    raise Exception("full message:", latestResponse)
                
                Angles[i] = angle
                vels[i] = vel
                torques[i] = torque
                temps[i] = temperature

        return(Angles, vels, torques, temps)

    def decode_telemetry_raw(self, raw, motor_type=None):
        """
        Parse one Teensy batch (sync + 12 bytes per motor) from read_framed_response / SingleWrite(..., reply_timeout=...).
        Returns list of ParseMotorResponse tuples, or None.
        """
        motor_type = motor_type or self.MotorType
        if raw is None or len(raw) != 12 * self.numMotors:
            return None
        rows = []
        for i in range(self.numMotors):
            chunk = list(raw[i * 12 : (i + 1) * 12])
            parsed = self.ParseMotorResponse(chunk, motor_type)
            if parsed is None:
                return None
            rows.append(parsed)
        return rows

    def format_telemetry_raw(self, raw, motor_type=None):
        text = self.decode_telemetry_raw(raw, motor_type)
        if not text:
            return None
        lines = ["Batched motor feedback (per-motor Type 0x02, via Teensy):"]
        for mid, ang, v, tq, temp, _mt in text:
            lines.append(
                f"  id={mid}: angle={ang:.5f} rad, vel={v:.4f} rad/s, torque={tq:.4f} N·m, temp={temp} °C"
            )
        return "\n".join(lines)

        
    ######################################################   
    ##   VVVVVVVVVVVVVV Helper Functions  VVVVVVVVVVVVVVV
    ######################################################
    @staticmethod
    def clamp(x, lo, hi, verbose = False):
        clip = max(lo, min(hi, x))
                
        if verbose and clip!= x:
            print("Warning: Angle clipped")

        return clip
    
    @staticmethod
    def start_motor_msg( motor_id: int):
        """Send 0x03 (start motor)."""
        eid = build_eid(0x03, host_id, motor_id)
        msg = eid+ [0x00] * 8
        return msg

    @staticmethod
    def stop_motor_msg(motor_id: int):
        """Send 0x04 (stop)."""
        eid = build_eid(0x04, host_id, motor_id)
        msg = eid+ [0x00] * 8
        return msg

    @staticmethod
    def zero_motor_msg(motor_id: int):
        """Send 0x06 (set current position to zero)."""
        eid = build_eid(0x06, host_id, motor_id)
        msg = eid+ [0x01] + [0x00] * 7
        return msg

    @staticmethod
    def set_control_mode_msg(motor_id: int, mode: int):
        """
        Send 0x12 write to index 0x7005 (run_mode), RS05 manual §4.1.15.
        Modes:
          0: operation mode
          1: position mode (PP)
          2: velocity mode
          3: current mode
          5: position mode (CSP)
        """
        eid = build_eid(0x12, host_id, motor_id)
        data = [0x05, 0x70, 0x00, 0x00, mode & 0xFF, 0x00, 0x00, 0x00]
        msg = eid+ data
        return msg

    def set_current_ref_msg(self, motor_id: int, CurrentRef: float):
        """
        Send 0x12 write to index 0x7006 (iq_ref), RS05: ±MotorMaxCurrent (±11 A).
        """
        CurrentRef = clamp(CurrentRef, -self.MotorMaxCurrent, self.MotorMaxCurrent)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", CurrentRef)  # little-endian float
        data = [0x06, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg
    
    @staticmethod
    def set_loc_kp_msg(motor_id: int, loc_kp: float):
        """
        Send 0x12 write-single-parameter to index 0x701E ().
 
        """
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", loc_kp)  # little-endian float
        data = [0x1E, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    @staticmethod
    def set_vel_ki_msg(motor_id: int, vel_ki: float):
        """
        Send 0x12 write-single-parameter to index 0x7020 ().
 
        """
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", vel_ki)  # little-endian float
        data = [0x20, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    @staticmethod
    def set_vel_kp_msg(motor_id: int, vel_kp: float):
        """
        Send 0x12 write-single-parameter to index 0x701F (Vel_max).
 
        """
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", vel_kp)  # little-endian float
        data = [0x1F, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg
    
    @staticmethod
    def set_vel_filter_gain_msg(motor_id: int, vel_filter_gain: float):
        """
        Send 0x12 write-single-parameter to index 0x7021 
 
        """
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", vel_filter_gain)  # little-endian float
        data = [0x21, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    def set_cur_kp_msg(self, motor_id: int, cur_kp: float):
        """RS05 0x7010 cur_kp (manual: 0..200)."""
        cur_kp = clamp(cur_kp, 0.0, 200.0)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", cur_kp)
        data = [0x10, 0x70, 0x00, 0x00] + list(fb)
        return eid + data

    def set_cur_ki_msg(self, motor_id: int, cur_ki: float):
        """RS05 0x7011 cur_ki (manual: 0..200)."""
        cur_ki = clamp(cur_ki, 0.0, 200.0)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", cur_ki)
        data = [0x11, 0x70, 0x00, 0x00] + list(fb)
        return eid + data

    @staticmethod
    def set_cur_filt_gain_msg(motor_id: int, cur_filt_gain: float):
        """RS05 0x7014 cur_filt_gain (0..1); low-pass on iq reference vs setpoint."""
        cur_filt_gain = clamp(cur_filt_gain, 0.0, 1.0)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", cur_filt_gain)
        data = [0x14, 0x70, 0x00, 0x00] + list(fb)
        return eid + data
    
    def set_max_speed_msg(self,motor_id: int, max_speed: float):
        """
        Send 0x12 write to index 0x7024 (vel_max), PP mode max speed (RS05 default 10 rad/s in manual).
        """
        max_speed = clamp(max_speed, 0.0, self.MotorMaxVel)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", max_speed)  # little-endian float
        data = [0x24, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    @staticmethod
    def set_max_acc_msg(motor_id: int, max_acc: float):
        """Send 0x12 write-single-parameter to index 0x7025 (acc_set)."""
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", max_acc)
        data = [0x25, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg
    
    def set_max_Torque_msg(self, motor_id: int, max_torque: float):
        """Send 0x12 write-single-parameter to index 0x700B."""
        max_torque = clamp(max_torque, 0, self.MotorMaxTorques)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", max_torque)
        data = [0x0B, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg
    
    @staticmethod
    def set_limit_Current_msg(motor_id: int, limit_Current: float):
        """Send 0x12 write to index 0x7018 (limit_cur), RS05: 0..11 A."""
        limit_Current = clamp(limit_Current, 0.0, 11.0)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", limit_Current)
        data = [0x18, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    @staticmethod
    def set_Zero_sta_mode_msg(motor_id: int, Zero_sta_mode: int):
        """Send 0x12 write to index 0x7029 (zero_sta)."""
        if Zero_sta_mode != 0x01 and Zero_sta_mode != 0x00:
            print("WARNING: Zero_sta_mode must be 0x01 or 0x00. Defaulted to 0x01")
            Zero_sta_mode=0x01

        eid = build_eid(0x12, host_id, motor_id)

        data = [0x29, 0x70, 0x00, 0x00, Zero_sta_mode, 0x00, 0x00, 0x00]
        msg = eid+ data
        return msg
    
    @staticmethod
    def set_position_ref_msg(motor_id: int, position: float):
        """
        Send 0x12 write-single-parameter to index 0x7016 (loc_ref).
        """
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", position)
        data = [0x16, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    def set_speed_ref_msg(self, motor_id: int, speed: float):
        """
        Send 0x12 write to index 0x7017 (limit_spd): CSP speed limit, RS05: 0..50 rad/s.
        """
        speed = clamp(speed, 0.0, self.MotorMaxVel)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", speed)
        data = [0x17, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    def set_velocity_mode_spd_ref_msg(self, motor_id: int, speed: float):
        """
        Send 0x12 write to index 0x700A (spd_ref), RS05 velocity-mode speed command: -50..50 rad/s.
        """
        speed = clamp(speed, -self.MotorMaxVel, self.MotorMaxVel)
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", speed)
        data = [0x0A, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    def set_vel_mode_acc_rad_msg(self, motor_id: int, acc_rad_s2: float):
        """Send 0x12 write to index 0x7022 (acc_rad), RS05 velocity-mode acceleration (rad/s²)."""
        eid = build_eid(0x12, host_id, motor_id)
        fb = struct.pack("<f", acc_rad_s2)
        data = [0x22, 0x70, 0x00, 0x00] + list(fb)
        msg = eid+ data
        return msg

    @staticmethod
    def read_position_msg(motor_id: int):
        """
        Send 0x11 read for index 0x7019 (mechPos).
        """
        eid = build_eid(0x11, host_id, motor_id)
        data = [0x19, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00] 
        msg = eid+ data
        return msg
    
    def FullLegFK(JointAngles, L1, L2, L3, L4):
        theta1 = JointAngles[0]  # ab/ad
        theta2 = JointAngles[1]  # hip
        theta3 = JointAngles[2]  # knee

        x = L4 * np.cos(theta1) - np.sin(theta1) * L2 * np.cos(theta2) + L3 * np.sin(theta1) * np.sin(theta2 + theta3)
        y = L4 * np.sin(theta1) + np.cos(theta1) * (L2 * np.cos(theta2) - L3 * np.sin(theta2 + theta3))
        z = L1 + L2 * np.sin(theta2) + L3 * np.cos(theta2 + theta3)
        return np.array([x, y, z], dtype=float)

    def FourLegIK(FootPositions):
        # For coordinate frame defs, see: https://www.ijstr.org/final-print/sep2017/Inverse-Kinematic-Analysis-Of-A-Quadruped-Robot.pdf
        #FootPositions is a 4x3 matrix, with each row representing the x,y,z targets positions, expressed in the body frame xm_ym_zm
        #L1 = length from ab/ad axis to the plane of the knee
        #L2 Thigh Length
        #L3 forelimbe length
        #L = length of  body in xm direction between knee axes
        #w = dist between ab motors
        #ALL UNITS IN M

        def SingleLegIK(FootPositions, legNum):
        # For coordinate frame defs, see: https://www.ijstr.org/final-print/sep2017/Inverse-Kinematic-Analysis-Of-A-Quadruped-Robot.pdf
        #FootPositions is a 3x1, (x,y,z) targets positions, expressed in the leg frame
        #L1 = length from ab/ad axis to the plane of the knee
        #L2 Thigh Length
        #L3 forelimbe length
        #ALL UNITS IN M    

            L1 =.12
            L2 =.19
            L3 =.21
            kneeeGearReduction = 19./20.

            x, y, z = FootPositions
            z=-z
            D = (x**2+y**2-L1**2+z**2-L2**2- L3**2) / (2*L2*L3)

            if legNum == 1 or legNum == 2:
                theta3 = np.arctan2(-np.sqrt(1-D**2),D)
            elif legNum == 3 or legNum == 4:
                theta3 = np.arctan2(np.sqrt(1-D**2),D)
            else:
                print("Invalid Leg Number")

            theta1 = -np.arctan2(-y,x) - np.arctan2(np.sqrt(x**2+y**2-L1**2),-L1) + np.pi
            theta2 = np.arctan2(z, np.sqrt(x**2+y**2-L1**2)) - np.arctan2(L3*np.sin(theta3),L2+L3*np.cos(theta3))

            return [theta1, theta2, theta3*kneeeGearReduction]
        L = .43
        w = .17

        theta_vals = [[0,0,0], [0,0,0], [0,0,0], [0,0,0]]

        #leg 1 (back right)
        FootPosition_footFrame = [-FootPositions[0][1]-w/2,
                                  FootPositions[0][2],
                                  FootPositions[0][0]+L/2]
        SingelLegtheta_vals = SingleLegIK(FootPosition_footFrame, 1)
        theta_vals[0] = [-SingelLegtheta_vals[0], SingelLegtheta_vals[1], SingelLegtheta_vals[2]]
        # print("Foot Frame: ", FootPosition_footFrame)
        #leg 2 (Front right)
        FootPosition_footFrame = [-FootPositions[1][1]-w/2,
                                  FootPositions[1][2],
                                  FootPositions[1][0]-L/2]
        SingelLegtheta_vals = SingleLegIK(FootPosition_footFrame, 2)
        theta_vals[1] = [SingelLegtheta_vals[0], SingelLegtheta_vals[1], SingelLegtheta_vals[2]]
        # print("Foot Frame: ", FootPosition_footFrame)

        #leg 3 (Front left)
        FootPosition_footFrame = [FootPositions[2][1]-w/2,
                                  FootPositions[2][2],
                                  -FootPositions[2][0]+L/2]
        SingelLegtheta_vals = SingleLegIK(FootPosition_footFrame, 3)
        theta_vals[2] = [-SingelLegtheta_vals[0], SingelLegtheta_vals[1], SingelLegtheta_vals[2]]

        #leg 4 (back left)
        FootPosition_footFrame = [FootPositions[3][1]-w/2,
                                  FootPositions[3][2],
                                  -FootPositions[3][0]-L/2]
        SingelLegtheta_vals = SingleLegIK(FootPosition_footFrame, 4)
        theta_vals[3] = [SingelLegtheta_vals[0], SingelLegtheta_vals[1], SingelLegtheta_vals[2]]

        return theta_vals

    def ParseMotorResponse(self, msg, MotorType = "RS03"):
        #this function is expecting msg to be 12 bytes long and to be a 0x02 response from a motor
        # Function will parse the message into the motor id, torque, angle, temp and velocity 
        if len(msg) == 12:
            

            if msg[0] == 0x02: #reply is general motor request
                
                MotorID = msg[1]
                data = msg[-10:]

                if MotorType == "RS03":

                    angle =struct.unpack('<f', bytes(data[:4]))[0]
                    vel_int = struct.unpack('>H', bytes(data[4:6]))[0]
                    vel = (vel_int / 65535.0) * (40.) - 20. #convert to float
                    torque_int = struct.unpack('>H', bytes(data[6:8]))[0]
                    torque = (torque_int / 65535.0) * (120.0) - 60. #convert to float
                    temperature = struct.unpack('>H', bytes(data[8:10]))[0]/10.

                elif MotorType == "RS00":
                    angle =struct.unpack('<f', bytes(data[:4]))[0]
                    vel_int = struct.unpack('>H', bytes(data[4:6]))[0]
                    vel = (vel_int / 65535.0) * (66.) - 33. #convert to float
                    torque_int = struct.unpack('>H', bytes(data[6:8]))[0]
                    torque = (torque_int / 65535.0) * (28.0) - 14. #convert to float
                    temperature = struct.unpack('>H', bytes(data[8:10]))[0]/10.

                elif MotorType == "RS05":
                    # Type 2 feedback, RS05 manual §4.1.3: vel ±50 rad/s, torque ±5.5 N·m (uint16 each)
                    angle = struct.unpack('<f', bytes(data[:4]))[0]
                    vel_int = struct.unpack('>H', bytes(data[4:6]))[0]
                    vel = (vel_int / 65535.0) * 100.0 - 50.0
                    torque_int = struct.unpack('>H', bytes(data[6:8]))[0]
                    torque = (torque_int / 65535.0) * 11.0 - 5.5
                    temperature = struct.unpack('>H', bytes(data[8:10]))[0] / 10.

                return [MotorID, angle, vel, torque, temperature, 0x02]
            elif msg[0] == 0x11: #reply is to angle request
                MotorID = msg[2]
                data = msg[-8:]
                if(data[0:2] == [0x19,0x70]):
                    angle = struct.unpack('<f', bytes(data[-4:]))[0]

                    vel=None
                    torque=None
                    temperature=None

                    return[MotorID, angle, vel, torque, temperature, 0x11]
                else:
                    print("Did not recognize parameter id")
            else:
                print("Did not recognize reply identifier")
                print(msg)
        else:
            print("Message should be 12 long")
        