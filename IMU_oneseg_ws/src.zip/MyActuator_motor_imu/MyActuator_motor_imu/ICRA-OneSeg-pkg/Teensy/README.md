# Teensy 3-motor + 3-IMU

Flash `Teensy_3motor_3IMU.ino` on a Teensy 4.1 (build machine needs
`Adafruit_BNO08x_Multi` + `FlexCAN_T4`; those libraries are not included here).

See the package `../README.md` for pin map, USB protocol, Absolute RV @ 400 Hz,
and the Python workflow.
