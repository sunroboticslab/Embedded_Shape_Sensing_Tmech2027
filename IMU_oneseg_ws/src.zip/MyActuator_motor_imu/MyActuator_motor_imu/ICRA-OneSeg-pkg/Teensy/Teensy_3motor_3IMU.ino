/*
 * Teensy_3motor_3IMU.ino  (ICRA-OneSeg-pkg)
 *
 * 3× RS05 CAN motors + 3× BNO085 absolute-orientation streams.
 * IMU path: Adafruit_BNO08x_Multi (400 Hz Absolute Rotation Vector).
 *
 * USB host protocol (2 Mbaud):
 *   Host  -> Teensy: [0xAA][36 B = 3 x 12-byte motor CAN frames]
 *   Teensy -> host:  [0xAA][36 B motor replies]
 *                    [48 B = 3 IMUs x (w,x,y,z) float32 LE]
 *
 * Motors (CAN1 @ 1 Mbps): 0x10, 0x11, 0x12
 *
 * BNO085 UART (P1 -> 3.3 V on every module):
 *   IMU1 Serial1  RX1 pin 0  <- SDA,  TX1 pin 1  -> SCL
 *   IMU2 Serial2  RX2 pin 7  <- SDA,  TX2 pin 8  -> SCL
 *   IMU3 Serial3  RX3 pin 15 <- SDA,  TX3 pin 14 -> SCL
 *
 * Requires Adafruit_BNO08x_Multi + FlexCAN_T4 on the Arduino libraries path
 * (not bundled in this package — flash on a machine that already has them).
 */

#include <FlexCAN_T4.h>
#include <string.h>
#include <Adafruit_BNO08x_Multi.h>

#ifndef BNO085_USE_GAME_RV
#define BNO085_USE_GAME_RV 0  // 0 = Absolute RV (default for this package)
#endif

#if BNO085_USE_GAME_RV
constexpr sh2_SensorId_t kImuReportId = SH2_GAME_ROTATION_VECTOR;
#else
constexpr sh2_SensorId_t kImuReportId = SH2_ROTATION_VECTOR;
#endif

constexpr uint32_t kPowerSettleMs = 4000;
constexpr uint32_t kBeginRetryDelayMs = 1000;
constexpr int kBeginMaxAttempts = 12;
constexpr uint32_t kPostBeginSettleMs = 500;
constexpr uint32_t kPostEnableSettleMs = 300;
constexpr uint32_t kStaleReenableMs = 2000;
constexpr uint32_t kReenableCooldownMs = 1000;
// 2500 us = 400 Hz Absolute RV.
constexpr uint32_t kReportIntervalUs = 2500;

FlexCAN_T4<CAN1, RX_SIZE_256, TX_SIZE_16> Can1;

const uint8_t syncByte = 0xAA;
const uint8_t MotorResponseID = 0x2;
const uint32_t host_id = 0xFD;

const uint16_t numMotors = 3;
const byte motorIds[numMotors] = {0x10, 0x11, 0x12};
const byte Can1_Ids[numMotors] = {0x10, 0x11, 0x12};

const uint16_t FrameSize = 12;
const uint16_t expectedBytes = FrameSize * numMotors;  // 36
const uint16_t numImus = 3;
const uint16_t quaternionBytesPerImu = 16;
const uint16_t quaternionBytes = quaternionBytesPerImu * numImus;  // 48
const uint16_t totalReplyBytes = expectedBytes + quaternionBytes;  // 84

byte DataBytes[expectedBytes];
byte ReplyBytes[expectedBytes];
float latestQuaternions[numImus][4];

CAN_message_t rxmsg;
bool MotorRepliesRecieved[numMotors];

uint8_t serial1RxBuffer[2048];
uint8_t serial2RxBuffer[2048];
uint8_t serial3RxBuffer[2048];

Adafruit_BNO08x_Multi bno1(-1);
Adafruit_BNO08x_Multi bno2(-1);
Adafruit_BNO08x_Multi bno3(-1);
Adafruit_BNO08x_Multi *const bnos[numImus] = {&bno1, &bno2, &bno3};
HardwareSerial *const imuPorts[numImus] = {&Serial1, &Serial2, &Serial3};

sh2_SensorValue_t sensorValue[numImus];
bool imuLive[numImus] = {};
uint32_t lastEventMs[numImus] = {};
uint32_t lastReenableMs[numImus] = {};

void sendCANMessage(uint32_t id, byte *data);
void canSniff(const CAN_message_t &msg);
void serviceImus(void);
void packQuaternions(float *out12);
bool setReports(size_t index);
bool bringUpOne(size_t index);
bool elementOf(const byte *list, byte element, uint16_t listLength);
uint32_t extractExtId(const uint8_t *b);

bool setReports(size_t index) {
  if (!bnos[index]->enableReport(kImuReportId, kReportIntervalUs)) {
    return false;
  }
  lastReenableMs[index] = millis();
  delay(kPostEnableSettleMs);
  serviceImus();
  return true;
}

bool bringUpOne(size_t index) {
  for (int attempt = 1; attempt <= kBeginMaxAttempts; ++attempt) {
    serviceImus();
    if (bnos[index]->begin_UART(imuPorts[index])) {
      delay(kPostBeginSettleMs);
      serviceImus();
      if (!setReports(index)) {
        imuLive[index] = false;
        return false;
      }
      imuLive[index] = true;
      lastEventMs[index] = millis();
      return true;
    }
    delay(kBeginRetryDelayMs);
  }
  imuLive[index] = false;
  return false;
}

void setup() {
  Serial.begin(2000000);
  while (!Serial) {
    ;
  }
  Serial.setTimeout(5);

  for (size_t i = 0; i < expectedBytes; ++i) {
    DataBytes[i] = 0x00;
    ReplyBytes[i] = 0x00;
  }
  for (size_t i = 0; i < numMotors; ++i) {
    MotorRepliesRecieved[i] = false;
  }
  for (size_t i = 0; i < numImus; ++i) {
    latestQuaternions[i][0] = 1.0f;
    latestQuaternions[i][1] = 0.0f;
    latestQuaternions[i][2] = 0.0f;
    latestQuaternions[i][3] = 0.0f;
    imuLive[i] = false;
  }

  Serial1.addMemoryForRead(serial1RxBuffer, sizeof(serial1RxBuffer));
  Serial2.addMemoryForRead(serial2RxBuffer, sizeof(serial2RxBuffer));
  Serial3.addMemoryForRead(serial3RxBuffer, sizeof(serial3RxBuffer));

  delay(kPowerSettleMs);

  for (size_t i = 0; i < numImus; ++i) {
    (void)bringUpOne(i);
  }

  Can1.begin();
  Can1.setBaudRate(1000000);
  Can1.setMaxMB(32);
  Can1.enableFIFO();
  Can1.enableFIFOInterrupt();
  Can1.onReceive(canSniff);
  delay(100);

  while (Can1.read(rxmsg)) {
    delay(1);
  }
}

void serviceImus(void) {
  const uint32_t nowMs = millis();
  for (size_t i = 0; i < numImus; ++i) {
    if (!imuLive[i]) {
      continue;
    }

    if (bnos[i]->wasReset()) {
      (void)bnos[i]->enableReport(kImuReportId, kReportIntervalUs);
      lastReenableMs[i] = nowMs;
      lastEventMs[i] = nowMs;
    }

    if ((nowMs - lastEventMs[i]) >= kStaleReenableMs &&
        (nowMs - lastReenableMs[i]) >= kReenableCooldownMs) {
      (void)bnos[i]->enableReport(kImuReportId, kReportIntervalUs);
      lastReenableMs[i] = nowMs;
      lastEventMs[i] = nowMs;
    }

    if (!bnos[i]->getSensorEvent(&sensorValue[i])) {
      continue;
    }
    if (sensorValue[i].sensorId != kImuReportId) {
      continue;
    }

    lastEventMs[i] = nowMs;
#if BNO085_USE_GAME_RV
    latestQuaternions[i][0] = sensorValue[i].un.gameRotationVector.real;
    latestQuaternions[i][1] = sensorValue[i].un.gameRotationVector.i;
    latestQuaternions[i][2] = sensorValue[i].un.gameRotationVector.j;
    latestQuaternions[i][3] = sensorValue[i].un.gameRotationVector.k;
#else
    latestQuaternions[i][0] = sensorValue[i].un.rotationVector.real;
    latestQuaternions[i][1] = sensorValue[i].un.rotationVector.i;
    latestQuaternions[i][2] = sensorValue[i].un.rotationVector.j;
    latestQuaternions[i][3] = sensorValue[i].un.rotationVector.k;
#endif
  }
}

void packQuaternions(float *out12) {
  for (size_t i = 0; i < numImus; ++i) {
    out12[i * 4 + 0] = latestQuaternions[i][0];
    out12[i * 4 + 1] = latestQuaternions[i][1];
    out12[i * 4 + 2] = latestQuaternions[i][2];
    out12[i * 4 + 3] = latestQuaternions[i][3];
  }
}

void loop() {
  Can1.events();
  serviceImus();

  while (Serial.available()) {
    int b = Serial.read();
    if (b < 0) {
      break;
    }
    if ((uint8_t)b != syncByte) {
      continue;
    }

    size_t n = Serial.readBytes(DataBytes, expectedBytes);
    if (n != expectedBytes) {
      continue;
    }

    if (DataBytes[0] != 0x00) {
      for (uint16_t i = 0; i < numMotors; ++i) {
        const uint8_t *parsed = &DataBytes[i * FrameSize];
        uint32_t extId = extractExtId(parsed);
        const uint8_t *payload = parsed + 4;
        sendCANMessage(extId, (byte *)payload);
        delayMicroseconds(1);
        Can1.events();
        serviceImus();
      }
    }
    break;
  }

  noInterrupts();
  bool all_Motors_replied = true;
  for (size_t i = 0; i < numMotors; i++) {
    if (!MotorRepliesRecieved[i]) {
      all_Motors_replied = false;
      break;
    }
  }
  interrupts();

  if (all_Motors_replied) {
    float quatPack[12];
    packQuaternions(quatPack);

    Serial.write(syncByte);
    noInterrupts();
    Serial.write(ReplyBytes, expectedBytes);
    Serial.write((uint8_t *)quatPack, quaternionBytes);
    for (size_t i = 0; i < numMotors; ++i) {
      MotorRepliesRecieved[i] = false;
    }
    interrupts();
  }
}

static inline bool sendCANBlocking(const CAN_message_t &msg, uint32_t timeout_us = 2000) {
  uint32_t start = micros();
  uint8_t motorID = (uint8_t)((msg.id >> 0) & 0xFF);

  if (elementOf(Can1_Ids, motorID, sizeof(Can1_Ids))) {
    while (!Can1.write(msg)) {
      Can1.events();
      serviceImus();
      if ((micros() - start) > timeout_us) {
        return false;
      }
    }
  }
  return true;
}

bool elementOf(const byte *list, byte element, uint16_t listLength) {
  for (uint16_t i = 0; i < listLength; i++) {
    if (list[i] == element) {
      return true;
    }
  }
  return false;
}

void sendCANMessage(uint32_t id, byte *data) {
  CAN_message_t msg;
  msg.flags.extended = 1;
  msg.id = id & 0x1FFFFFFF;
  msg.len = 8;
  for (int i = 0; i < 8; i++) {
    msg.buf[i] = data[i];
  }
  (void)sendCANBlocking(msg);
}

uint32_t extractExtId(const uint8_t *b) {
  return ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16) |
         ((uint32_t)b[2] << 8) | ((uint32_t)b[3] << 0);
}

void canSniff(const CAN_message_t &msg) {
  uint32_t id = msg.id;

  if ((uint8_t)((id >> 24) & 0xFF) != MotorResponseID) {
    return;
  }

  byte motorID = (uint8_t)((id >> 8) & 0xFF);
  int index = -1;
  for (uint16_t i = 0; i < numMotors; i++) {
    if (motorID == motorIds[i]) {
      index = i;
      break;
    }
  }
  if (index < 0) {
    return;
  }

  const int OFFSET_CMD = 0;
  const int OFFSET_ID = 1;
  const int OFFSET_FLOAT = 2;
  const int OFFSET_REMAIN = 6;

  ReplyBytes[index * FrameSize + OFFSET_CMD] = (uint8_t)((id >> 24) & 0xFF);
  ReplyBytes[index * FrameSize + OFFSET_ID] = (uint8_t)((id >> 8) & 0xFF);

  uint8_t tempResponseData[8] = {0};
  for (uint8_t i = 0; i < 8; i++) {
    tempResponseData[i] = (i < msg.len) ? msg.buf[i] : 0x00;
  }

  uint16_t raw = ((uint16_t)tempResponseData[0] << 8) | tempResponseData[1];
  float angle = ((float)raw / 65535.0f) * (8.0f * PI) - 4.0f * PI;

  uint8_t AngleBytes[4];
  memcpy(AngleBytes, &angle, sizeof(float));
  for (uint8_t b = 0; b < 4; b++) {
    ReplyBytes[index * FrameSize + OFFSET_FLOAT + b] = AngleBytes[b];
  }
  for (uint8_t b = 0; b < 6; b++) {
    ReplyBytes[index * FrameSize + OFFSET_REMAIN + b] = tempResponseData[2 + b];
  }

  MotorRepliesRecieved[index] = true;
}
