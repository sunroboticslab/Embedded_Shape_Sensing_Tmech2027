# MPC tip control — logic & dimensions

Integrated node: `MyActuator_motor_imu/mpc_tip_control.py`  
Launch: `ros2 launch MyActuator_motor_imu mpc_tip_control.launch.py`  
(uses NN-training `.venv` for torch/osqp; OptiTrack + MPC)  
Logs: `/root/DataCollection/IMU_oneseg_ws/mpc_log_YYYYMMDD_HHMMSS.csv` (override with `out_dir:=…`)

**Do not** `source NN_training/.venv/bin/activate`. Torch lives only in the MPC child process.

```bash
# Isolated (recommended): ROS overlay stays inside this script; your shell python is unchanged
bash /root/DataCollection/IMU_oneseg_ws/src/MyActuator_motor_imu/launch/run_mpc_tip_control.sh

# Same, extra args (longer hold helps LSTM history fill)
bash /root/DataCollection/IMU_oneseg_ws/src/MyActuator_motor_imu/launch/run_mpc_tip_control.sh hold_s:=15.0

# If ROS is already sourced in this terminal:
ros2 launch MyActuator_motor_imu mpc_tip_control.launch.py
```

Requires Teensy at `COM_PORT` (default `/dev/ttyACM0`).

---

## Real-time compute (handles 1–2 @ 400 Hz)

Budget ≈ **2.5 ms/tick**. **Keep control at 400 Hz** (Koopman / NN trained there). Raising the timer without re-identifying the discrete model changes closed-loop behavior.

| Path | Typical cost | Notes |
|------|-------------|--------|
| **LSTM stateful 1-step** (default) | **~0.2 ms** | Carry `(h,c)`; one full window only to bootstrap |
| LSTM full seq100 | ~1.5–3 ms | Set `LSTM_STATEFUL=False` only to compare |
| MLP | ~0.02 ms | Already ≪ budget |
| OSQP | ~0.08 ms | Dense `q`, polish off |
| CSV disk I/O | **0 in control** | `mpc_log_recorder` writes CSV from `/mpc_log` (async queue) |
| ROS / GC | low | Reused msgs, GC off, console 20 Hz |

MLP is compute-bound only by **I/O jitter**, not the net. After the RT I/O pass you should see mean/median ≈2.5 ms and max closer to 2.5–3.0 ms (fewer >3 ms spikes).

| Knob | Default | Notes |
|------|---------|--------|
| `LSTM_STATEFUL` | `True` | Main LSTM speedup |
| `CSV_FLUSH_EVERY` | `400` | Disk flush period (ticks); larger → less jitter |
| `PUBLISH_ERR_EVERY` | `4` | `/mpc_error` at 100 Hz |
| `LOG_CONSOLE_HZ` | `20` | ROS logging is expensive |
| `NN_DEVICE` / `MPC_NN_DEVICE` | `cpu` | Set `cuda` only if preferred |
| `TORCH_NUM_THREADS` / `MPC_TORCH_THREADS` | `2` | Enough for stateful; use 4 if full-seq |
| `COMPUTE_WARMUP_ITERS` | `80` | Dummy NN+OSQP before timer |
| `HOLD_S` | `15` | Calib 5 s + history fill |

Edit in `main()` or export env vars.

---

## Control handles (three Koopman models)


| Handle | State source         | Rate       | Ident               | Koopman `.npz`                                                   |
| ------ | -------------------- | ---------- | ------------------- | ---------------------------------------------------------------- |
| **1**  | LSTM reconstructed ŷ | **400 Hz** | ridge               | `…/LSTM/…/koop_d10_seed42_full_ridge/koopman_model.npz`           |
| **2**  | MLP reconstructed ŷ  | **400 Hz** | ridge               | `…/MLP/…/koop_d10_seed42_full_ridge/koopman_model.npz`           |
| **3**  | OptiTrack packed Y   | **100 Hz** | (OT-trained)        | `…/MLP/…/koop_d10_seed42_full_ridge/koopman_model_optitrack.npz` |


*(Former MLP@100 Hz handle removed.)*

Edit in `main()`:

```python
CONTROL_HANDLE = 2   # 1 | 2 | 3
HOLD_S = 15.0
NN_DEVICE = "cpu"
TORCH_NUM_THREADS = 4
```

**Rate policy:** motor COM + CSV always run at **400 Hz**. Handle 3 solves MPC every 4th tick (100 Hz). Handles 1/2 solve every tick.

---

## End-to-end control diagram

```mermaid
flowchart TB
    subgraph sensors [Sensors @ 400 Hz]
        MOT["Motors\nreal_enc ℝ³, trq ℝ³"]
        IMU["IMUs ×3\nwxyz"]
        OT["OptiTrack\nRB1…RB5"]
    end

    subgraph align [Hold: IMU mount]
        CAL["0–5 s: R_imu_in_rb\n(OT + IMU or saved .npz)"]
        FEAT["IMU_raw → RB-align → IMU3_aligned\nimu12 = IMU1+IMU2 only"]
    end

    subgraph state [Build shape state x ∈ ℝ¹⁶]
        H1["Handle 1: LSTM\nseq_len=100 → ŷ"]
        H2["Handle 2: MLP\nsingle-frame → ŷ"]
        H3["Handle 3: pack OptiTrack\noption e + xz in RB1"]
    end

    subgraph lift [Delay lift]
        Z["z = [xₖ, xₖ₋₁, …, xₖ₋d]\nd=10 → dim = 16×11 = 176"]
        N["Normalize\nxₙ=(x−μₓ)/σₓ"]
    end

    subgraph mpc [Dense linear MPC]
        REF["tip_ref.csv → (x,z)\nexpand to 4 tip channels"]
        QP["OSQP: min Σ ‖C z − y_ref‖²_Q + ‖u‖²_R\n|u| ≤ Δenc max"]
        U["u₀ ∈ ℝ³  (normalized Δenc)"]
    end

    subgraph act [Actuation]
        ACC["enc_rel ← enc_rel + Δenc_phys\n|enc_rel| ≤ 8"]
        ABS["target_abs = home + enc_rel"]
        OCM["OCM stream → Teensy"]
    end

    MOT --> H1 & H2
    IMU --> CAL --> FEAT --> H1 & H2
    OT --> CAL
    OT --> H3
    H1 & H2 & H3 --> N --> Z --> QP
    REF --> QP --> U --> ACC --> ABS --> OCM
```



---

## Hold → track timeline

```
connect → OCM with t_ff @ hold_abs (= home + base_rel)
       → HOLD_S = 10 s total:
            • 0–5 s  IMU mount calib (OptiTrack RB + raw IMU → R_imu_in_rb)
                     fallback: WS R_imu_in_rb.npz if live samples insufficient
            • 5–10 s fill LSTM/delay history with IMU after
                     RB-align → IMU3_aligned (matches locked NN imu12)
       → TRACK tip_ref.csv
       → tip ref done → ramp home + soft-release t_ff → exit launch
```

```
t = 0 ── CALIB 5 s ──┬── HOLD fill 5 s ──┬──── TRACK tip_ref ────→ home → exit
                     │                   │
  • estimate mounts  │  aligned IMU      │  advance ref_idx each
  • stay at hold_abs │  → NN history     │  control step
  • OptiTrack lock   │  delay buffer     │  accumulate Δenc → motors
```

`IMU_CALIBRATION_S = 5.0`, `HOLD_S = 10.0` in `main()` / class defaults.

**Online NN IMU path** (handles 1–2), same as training:

```text
IMU_raw → R_ideal = R_raw @ R_imu_in_rbᵀ  → under IMU3_aligned
NN uses IMU1 + IMU2 only   (imu12; IMU3 ≡ I → dropped)
```

NN input/output use train `x_mean`/`x_std`/`y_mean`/`y_std` (quat channels not z-scored).  
OptiTrack shape labels remain in **RB1**.

Tracking starts only after hold **and** `len(history) ≥ delay+1` (and LSTM `seq_len` if handle 1).

---

## State vector x (16-D, option e + xz)

All handles produce the **same** physical shape `x ∈ ℝ¹⁶` (`shape_option="e"`, `plane="xz"`):


| Index | Name         | Meaning                     |
| ----- | ------------ | --------------------------- |
| 0–1   | `pF_RB2_x/z` | RB2 in **RB1**              |
| 2–3   | `pF_RB3_x/z` | RB3 in RB1                  |
| 4–5   | `pF_RB4_x/z` | RB4 in RB1                  |
| 6–7   | `pF_RB5_x/z` | **Tip** in RB1              |
| 8–15  | `pB_`*       | local (= global on one-seg) |


**Tip channels for MPC:** indices `**[6, 7, 14, 15]`**.

---

## How each handle builds `x` and `z`

Common after `x`:

```
xₙ = (x − x_mean) / x_std          # from that handle's .npz
append xₙ to state_history @ control rate
z = [xₙ(k), xₙ(k−1), …, xₙ(k−d)]   # d=10 → z ∈ ℝ¹⁷⁶
```

---

### Handle 1 — LSTM ŷ @ 400 Hz → Koopman ridge

**Sensors → NN input** (after mount ready), matches `enc_trq_imu12`:


| Block              | Dim    | Source                  |
| ------------------ | ------ | ----------------------- |
| `enc_rel`          | 3      | `real_abs − home`       |
| `trq`              | 3      | motor torques           |
| `imu1`,`imu2` quat | 8      | RB-align → IMU3_aligned |
| **row**            | **14** | LSTM `in_dim`           |


1. Normalize row with NN `x_mean`/`x_std` → buffer of length `seq_len=100`.
2. Frozen LSTM → last step → denorm with `y_mean`/`y_std` → `**x = ŷ ∈ ℝ¹⁶`**.
3. Koopman history @ 400 Hz → `z ∈ ℝ¹⁷⁶` → MPC `N=20`.

---

### Handle 2 — MLP ŷ @ 400 Hz → Koopman ridge

**Sensors → NN input**, matches `enc_imu12_u`:


| Block              | Dim    | Source                            |
| ------------------ | ------ | --------------------------------- |
| `enc_rel`          | 3      | measured `real_abs − home`        |
| `imu1`,`imu2` quat | 8      | RB-align → IMU3_aligned           |
| `κ₁, κ₂`           | 2      | `kappa_from_rel_enc(enc_rel_cmd)` |
| `target_enc_rel`   | 3      | commanded `target_abs − home`     |
| **row**            | **16** | MLP `in_dim` (no torque)          |


1. Normalize latest row → MLP → denorm → `**x = ŷ`**.
2. History @ 400 Hz → MPC `N=20`.

---

### Handle 3 — OptiTrack Y @ 100 Hz → Koopman OT

**No NN.** Pack Motive RB1…RB5 into option-e xz (16-D) in RB1.  
Normalize with `koopman_model_optitrack.npz`; append every 4th tick; MPC `N=5`.

---

## Delay embedding z

```
z[k] = [ xₙ[k], xₙ[k−1], …, xₙ[k−d] ]   ∈ ℝ^(nx · (d+1))
d = 10, nx = 16 → dim(z) = 176
```


| Handle | Rate of `xₙ` | Wall-clock span of `z` | `.npz`                                     |
| ------ | ------------ | ---------------------- | ------------------------------------------ |
| 1      | 400 Hz       | ~25 ms                 | LSTM `…/full_ridge/koopman_model.npz`       |
| 2      | 400 Hz       | ~25 ms                 | MLP `…/full_ridge/koopman_model.npz`       |
| 3      | 100 Hz       | ~100 ms                | `…/full_ridge/koopman_model_optitrack.npz` |


---

## Tip reference (RB1)

File: `mpc_ref/tip_ref.csv` — columns **`x,z`** in **RB1** (same frame as Fig.5 tip cloud and NN/Koopman `pF_RB5_x/z`).

MPC reads `x,z` only (no axis swap). At 400 Hz the path is linearly upsampled ×4 so wall-clock speed matches a 100 Hz design.

`y_ref = [x, z, x, z]` for tip pF+pB, then z-scored with that `.npz` tip stats.

**Tip AABB ≠ κ-feasible.** Data collection commands `|κ|≤7.5`. Outer tip waypoints can need `|κ|≳8–12` from the cable map — then one κ channel saturates even though the tip looks in-distribution. Shrink/center the Fig.5 path or keep `|κ|` checks when designing `tip_ref`.

---

## Cost & constraints

```
min_U  Σ ‖ y_i − y_ref,i ‖²_Q  +  ‖ u_i ‖²_R
N = MPC_HORIZON
|u_phys| ≤ DELTA_U_MAX   (default 0.005 rad / step)   — Koopman step
|κ|      ≤ KAPPA_LIMIT   (default 7.5 1/m)            — same as data collection
```

**Actuation matches data collection** (no enc-rad limit):

```
Δenc from MPC → κ = lstsq(enc) → clip |κ|≤7.5 → enc = f(κ, home, slack)
```

same `target_abs_enc_from_kappa` as `random_data_collection`.

### Why tip∈workspace did not stop κ from hitting 7.5

| | Data collection | MPC (before fix) |
|--|--|--|
| Input | **κ** (clipped) | **Δenc** (Koopman) |
| Enc | `enc = f(κ)` | accumulate Δenc |
| Tip | result of κ | track tip_ref |

Tip in the cloud means *there exists* a κ≤7.5 that reaches it.  
MPC does **not** choose that κ — it chooses Δenc. Three cables / two κ leave a null space, so LSTSQ-κ from raw enc can exceed 7.5 even near a feasible tip.  

Clipping κ and remapping with `target_abs_enc_from_kappa` restores the same input model as collection. If κ still rides ±7.5 on outer waypoints, those tips sit on the **boundary** of the |κ|≤7.5 set (collected at max bend) — shrink the path slightly if you want headroom.

---

## Logging (always 400 Hz)

`mpc_log_*.csv` under workspace root: time, tip tar/pred/OT, motors, OT RB poses, full 16-D `pred_*` (OT tip on handle 3).

---

## Dimension cheat-sheet


| Symbol    | Dim                     | Notes                  |
| --------- | ----------------------- | ---------------------- |
| `x`       | 16                      | shape e+xz             |
| `z`       | 176                     | delay d=10             |
| `u`       | 3                       | Δenc                   |
| LSTM in   | **14**                  | enc+trq+imu12          |
| MLP in    | **16**                  | enc+imu12+κ+target_enc |
| A / B / C | 176×176 / 176×3 / 4×176 |                        |


---

## Tuning knobs (`main()`)


| Name                       | Default        | Role                                      |
| -------------------------- | -------------- | ----------------------------------------- |
| `CONTROL_HANDLE`           | 2              | 1 LSTM@400 / 2 MLP@400 / 3 OT@100         |
| `HOLD_S`                   | **10**         | Hold before track (first 5 s = IMU mount) |
| `IMU_CALIBRATION_S`        | **5**          | Mount window (class attr; matches NN)     |
| `MPC_HORIZON`              | `[20, 5]`      | Steps @ 400 / 100 Hz                      |
| `MPC_Q_TIP` / `MPC_R_DIAG` |                | Tip / Δenc weights                        |
| `DELTA_U_MAX`              | 0.005          | Per-step Δenc                             |
| `KAPPA_LIMIT`              | **7.5**        | only actuation limit (= data collection)  |
| `COM_PORT`                 | `/dev/ttyACM0` | Teensy                                    |


---

## How to run

```bash
cd /root/DataCollection/IMU_oneseg_ws
colcon build --packages-select MyActuator_motor_imu
source install/setup.bash
ros2 launch MyActuator_motor_imu mpc_tip_control.launch.py
```

