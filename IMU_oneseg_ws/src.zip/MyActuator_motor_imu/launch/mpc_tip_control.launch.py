#!/usr/bin/env python3
"""
MPC tip-tracking pipeline (IMU_oneseg_ws)
=========================================

Starts:

  • udp_optitrack_publisher
  • mpc_log_recorder   (CSV writer — async, off the control loop)
  • mpc_tip_control    (/motor + /mpc_log @ 400 Hz; no disk I/O by default)

Startup sequence::

  tension t_ff @ home → IMU calibrate (~5 s) → HOLD_S history fill → track tip_ref

CSV is written by **mpc_log_recorder** (subscribes to ``/mpc_log``), same idea as
splitting collection I/O from the motor loop — so flush stalls cannot delay MPC.

Edit CONTROL_HANDLE / COM / gains inside::

  MyActuator_motor_imu/mpc_tip_control.py  →  ``main()`` tunables

CSV default::

  /root/DataCollection/IMU_oneseg_ws/mpc_log_YYYYMMDD_HHMMSS.csv

Run::

  bash /root/DataCollection/IMU_oneseg_ws/src/MyActuator_motor_imu/launch/run_mpc_tip_control.sh

  # or, ROS already sourced:
  ros2 launch MyActuator_motor_imu mpc_tip_control.launch.py

Optional::

  ros2 launch MyActuator_motor_imu mpc_tip_control.launch.py out_dir:=/path/to/logs hold_s:=15.0
"""

import os
import sys

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, LogInfo, OpaqueFunction, TimerAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _find_ws_root(start: str) -> str:
    here = os.path.abspath(os.path.dirname(start))
    marker = "optitrack_roles.py"
    for env in ("IMU_ONESEG_WS",):
        raw = os.environ.get(env, "").strip()
        if raw and os.path.isfile(os.path.join(raw, marker)):
            return os.path.abspath(raw)
    for _ in range(12):
        if os.path.isfile(os.path.join(here, marker)):
            return here
        parent = os.path.dirname(here)
        if parent == here:
            break
        here = parent
    raise RuntimeError(
        "Could not find IMU_oneseg_ws root (optitrack_roles.py). "
        "Set IMU_ONESEG_WS=/root/DataCollection/IMU_oneseg_ws"
    )


WS_ROOT = _find_ws_root(__file__)
VENV_PYTHON = os.path.join(WS_ROOT, "NN_training", ".venv", "bin", "python")


def _nodes(context, *args, **kwargs):
    out_dir = os.path.abspath(
        LaunchConfiguration("out_dir").perform(context).strip() or WS_ROOT
    )
    hold_s = LaunchConfiguration("hold_s").perform(context).strip() or "10.0"
    os.makedirs(out_dir, exist_ok=True)

    optitrack_node = Node(
        package="optitrack_streaming",
        executable="udp_optitrack_publisher",
        name="udp_optitrack_publisher",
        output="screen",
    )

    # Recorder uses system/ROS python (csv only) — start BEFORE MPC so latched header is seen
    recorder = Node(
        package="MyActuator_motor_imu",
        executable="mpc_log_recorder",
        name="mpc_log_recorder",
        output="screen",
        parameters=[
            {"log_dir": out_dir},
            {"flush_every": 400},
            {"queue_size": 8000},
        ],
    )

    # Child-only interpreter: NN-training venv (torch + osqp).
    py = VENV_PYTHON if os.path.isfile(VENV_PYTHON) else sys.executable
    venv_dir = (
        os.path.dirname(os.path.dirname(VENV_PYTHON))
        if os.path.isfile(VENV_PYTHON)
        else ""
    )
    mpc_proc = ExecuteProcess(
        cmd=[
            py,
            "-m",
            "MyActuator_motor_imu.mpc_tip_control",
            "--ros-args",
            "-r",
            "__node:=mpc_tip_control",
            "-p",
            f"log_dir:={out_dir}",
            "-p",
            f"hold_s:={hold_s}",
        ],
        name="mpc_tip_control",
        output="screen",
        additional_env={
            "PYTHONPATH": os.environ.get("PYTHONPATH", ""),
            "VIRTUAL_ENV": venv_dir,
        },
    )
    # Small delay so recorder is spinning before MPC publishes the latched header
    mpc_delayed = TimerAction(period=0.5, actions=[mpc_proc])

    return [
        LogInfo(
            msg=(
                f"[mpc] OptiTrack + recorder + tip MPC | "
                f"python={py} | hold_s={hold_s} | "
                f"CSV via mpc_log_recorder → {out_dir}/mpc_log_*.csv"
            )
        ),
        optitrack_node,
        recorder,
        mpc_delayed,
    ]


def generate_launch_description():
    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "out_dir",
                default_value=WS_ROOT,
                description="Directory for mpc_log_*.csv (default: IMU_oneseg_ws root).",
            ),
            DeclareLaunchArgument(
                "hold_s",
                default_value="15.0",
                description="Home hold / IMU history warmup before tip tracking [s].",
            ),
            OpaqueFunction(function=_nodes),
        ]
    )
