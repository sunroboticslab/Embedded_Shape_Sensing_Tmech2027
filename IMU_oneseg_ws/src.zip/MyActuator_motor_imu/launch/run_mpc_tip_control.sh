#!/usr/bin/env bash
# Run MPC tip-control launch in an isolated process.
#
# - Sources ROS Humble + this workspace overlay only inside this script
#   (calling shell PYTHONPATH / venv / conda are not changed).
# - Does NOT ``source NN_training/.venv/bin/activate``.
#   The launch file starts the MPC node with that venv's python binary.
#
# Usage (from anywhere):
#   bash /root/DataCollection/IMU_oneseg_ws/src/MyActuator_motor_imu/launch/run_mpc_tip_control.sh
# Extra launch args are forwarded:
#   bash .../run_mpc_tip_control.sh out_dir:=/tmp/mpc hold_s:=10.0
set -eo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# launch/ → package → src → ws
WS="$(cd "${HERE}/../../.." && pwd)"
if [[ ! -f "${WS}/optitrack_roles.py" ]]; then
  echo "Could not find IMU_oneseg_ws root (optitrack_roles.py) from ${HERE}" >&2
  exit 1
fi

# Isolate overlay: do not persist into the parent shell (this is a new bash).
# ROS setup.bash may reference unset vars — allow that while sourcing.
set +u
# shellcheck disable=SC1091
source /opt/ros/humble/setup.bash
# shellcheck disable=SC1091
source "${WS}/install/setup.bash"
set -u

exec ros2 launch MyActuator_motor_imu mpc_tip_control.launch.py "$@"
